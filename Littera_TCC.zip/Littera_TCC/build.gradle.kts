// build.gradle.kts (raiz do projeto)
plugins {
    alias(libs.plugins.android.application) apply false
}

