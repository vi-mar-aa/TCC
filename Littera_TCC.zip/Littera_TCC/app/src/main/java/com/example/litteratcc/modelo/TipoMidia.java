package com.example.litteratcc.modelo;

public class TipoMidia {
    private int id_tpmidia;
    private String nome_tipo;

    public int getId_tpmidia() {
        return id_tpmidia;
    }

    public void setId_tpmidia(int id_tpmidia) {
        this.id_tpmidia = id_tpmidia;
    }

    public String getNome_tipo() {
        return nome_tipo;
    }

    public void setNome_tipo(String nome_tipo) {
        this.nome_tipo = nome_tipo;
    }
}
