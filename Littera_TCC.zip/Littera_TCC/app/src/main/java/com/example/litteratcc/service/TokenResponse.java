package com.example.litteratcc.service;

public class TokenResponse {
    public String token;
}
