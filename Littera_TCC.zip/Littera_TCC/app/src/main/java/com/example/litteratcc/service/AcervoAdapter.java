package com.example.litteratcc.service;

public class AcervoAdapter {
}
