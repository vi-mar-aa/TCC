package com.example.litteratcc.modelo;

public class MessageResponse {
    public String mensagem;
}

