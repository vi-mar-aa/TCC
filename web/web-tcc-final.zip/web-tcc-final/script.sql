USE master;
GO

IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'Littera') 
    DROP DATABASE Littera;

CREATE DATABASE Littera;
GO

EXEC sp_configure 'show advanced options', 1;
GO

RECONFIGURE;
GO

EXEC sp_configure 'Ad Hoc Distributed Queries', 1;
GO

RECONFIGURE;
GO

USE Littera;
GO

CREATE TABLE CargoFuncionario (
    id_cargo INT PRIMARY KEY IDENTITY,
    nome_cargo VARCHAR(100) NOT NULL
);
GO

CREATE TABLE Funcionario (
    id_funcionario INT PRIMARY KEY IDENTITY,
    id_cargo INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(14) UNIQUE NOT NULL,
    email VARCHAR(100) NOT NULL,
    telefone VARCHAR(20),
    senha VARCHAR(255) NOT NULL,
    status_conta VARCHAR(20) NOT NULL,
    FOREIGN KEY (id_cargo) REFERENCES CargoFuncionario(id_cargo),
    CONSTRAINT chk_func_status CHECK (status_conta IN ('ativo', 'banido'))
);
GO

CREATE TABLE Cliente (
    id_cliente INT PRIMARY KEY IDENTITY,
    nome VARCHAR(100) NOT NULL,
	username VARCHAR(40) NOT NULL,
    cpf VARCHAR(14) UNIQUE NOT NULL,
    email VARCHAR(100) NOT NULL,
    telefone VARCHAR(20),
    senha VARCHAR(255) NOT NULL,
    status_conta VARCHAR(20) NOT NULL,
	imagem_perfil VARBINARY(MAX),
    CONSTRAINT chk_cli_status CHECK (status_conta IN ('ativo', 'banido'))
);
GO

CREATE TABLE TipoMidia (
    id_tpmidia INT PRIMARY KEY IDENTITY,
    nome_tipo VARCHAR(50) NOT NULL
);
GO

CREATE TABLE Midia (
    id_midia INT PRIMARY KEY IDENTITY,
    id_funcionario INT NOT NULL,
    id_tpmidia INT NOT NULL,
    titulo VARCHAR(255) NOT NULL,
    sinopse VARCHAR(255) NOT NULL, 
    autor VARCHAR(100),
    editora VARCHAR(100),
    ano_publicacao VARCHAR(100),
    edicao VARCHAR(50),
    local_publicacao VARCHAR(100),
    numero_paginas INT,
    isbn VARCHAR(20),
    duracao VARCHAR(20),
    estudio VARCHAR(100),
    roteirista VARCHAR(100),
    disponibilidade VARCHAR(20) NOT NULL,
    genero VARCHAR(100),
    imagem VARBINARY(MAX),
	status_midia VARCHAR(20) DEFAULT 'publica',
    codigo_exemplar INT NOT NULL,
    FOREIGN KEY (id_funcionario) REFERENCES Funcionario(id_funcionario),
    FOREIGN KEY (id_tpmidia) REFERENCES TipoMidia(id_tpmidia),
    CONSTRAINT chk_disponibilidade CHECK (disponibilidade IN ('dispon�vel', 'emprestado')),
    CONSTRAINT chk_status_midia CHECK (status_midia IN ('publica', 'privada'))
);
GO


CREATE TABLE Reserva (
    id_reserva INT PRIMARY KEY IDENTITY,
    id_cliente INT NOT NULL,
    id_midia INT NOT NULL,
    data_reserva DATETIME NOT NULL default GETDATE(), 
    data_limite DATETIME NOT NULL,
    status_reserva VARCHAR(20) NOT NULL,
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente),
    FOREIGN KEY (id_midia) REFERENCES Midia(id_midia),
    CONSTRAINT chk_status_reserva CHECK (status_reserva IN ('ativa', 'expirada', 'cancelada', 'concluida'))
);
GO

CREATE TABLE Emprestimo (
    id_emprestimo INT PRIMARY KEY IDENTITY,
    id_cliente INT NOT NULL,
    id_funcionario INT NOT NULL,
    id_midia INT NOT NULL,
    id_reserva INT,
    data_emprestimo DATE NOT NULL,
    data_devolucao DATE NOT NULL,
    limite_renovacoes INT DEFAULT 2,
	status_emprestimo VARCHAR(20) NOT NULL DEFAULT 'emprestado',
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente),
    FOREIGN KEY (id_funcionario) REFERENCES Funcionario(id_funcionario),
    FOREIGN KEY (id_midia) REFERENCES Midia(id_midia),
    FOREIGN KEY (id_reserva) REFERENCES Reserva(id_reserva),
	CONSTRAINT chk_status_emprestimo CHECK (status_emprestimo IN ('atrasado','emprestado','renovado','devolvido'))
);
GO

CREATE TABLE Mensagem (
    id_mensagem INT PRIMARY KEY IDENTITY,
    id_cliente INT NOT NULL,
	titulo NVARCHAR(60) NOT NULL,
    conteudo NVARCHAR(255) NOT NULL,
    data_postagem DATETIME NOT NULL,
    visibilidade BIT DEFAULT 1 NOT NULL, -- 1 = publica, 0 = privada
	curtidas INT DEFAULT 0,
	id_pai INT, 
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente)
);

GO

CREATE TABLE Denuncia (
    id_denuncia INT PRIMARY KEY IDENTITY,
    id_funcionario INT,
    id_mensagem INT NOT NULL,
    id_cliente INT NOT NULL,
    data_denuncia DATETIME NOT NULL,
    motivo VARCHAR(255),
    status_denuncia VARCHAR(20) NOT NULL,
    acao_tomada VARCHAR(255),
    FOREIGN KEY (id_funcionario) REFERENCES Funcionario(id_funcionario),
    FOREIGN KEY (id_mensagem) REFERENCES Mensagem(id_mensagem),
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente),
    CONSTRAINT chk_denuncia_status_denuncia CHECK (status_denuncia IN ('pendente', 'resolvida'))
);
GO

CREATE TABLE ListaDeDesejos (
    id_cliente INT NOT NULL,
    id_midia INT NOT NULL,
    data_adicionada DATETIME NOT NULL DEFAULT GETDATE(),
    PRIMARY KEY (id_cliente, id_midia),
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente),
    FOREIGN KEY (id_midia) REFERENCES Midia(id_midia)
);
GO

CREATE TABLE Evento (
    id_evento INT PRIMARY KEY IDENTITY,
    titulo NVARCHAR(200) NOT NULL,
    data_inicio DATETIME NOT NULL,
    data_fim DATETIME NOT NULL,
    local_evento NVARCHAR(200) NOT NULL,
    status_evento VARCHAR(20) NOT NULL DEFAULT 'ativo',
    id_funcionario INT NOT NULL,
    FOREIGN KEY (id_funcionario) REFERENCES Funcionario(id_funcionario)
);
GO

CREATE TABLE Indicacao (
    id_indicacao INT PRIMARY KEY IDENTITY,
    id_cliente INT NOT NULL,
    titulo_ind VARCHAR(255) NOT NULL,
    autor_ind VARCHAR(120),
	data_indicacao DATETIME NOT NULL DEFAULT GETDATE(),
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente)
);
GO

CREATE TABLE Notificacao (
    id_notificacao INT PRIMARY KEY IDENTITY,
    id_cliente INT NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    mensagem VARCHAR(MAX) NOT NULL,
    data_criacao DATETIME NOT NULL DEFAULT GETDATE(),
    lida BIT DEFAULT 0,
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente)
);
GO

CREATE TABLE Parametros(
	id_parametros INT IDENTITY PRIMARY KEY,
	multa_dia DECIMAL(10,2)  NOT NULL, 
	prazo_devolucao_dias INT  NOT NULL, 
	limite_emprestimos INT  NOT NULL
);
GO
CREATE TABLE Curtida (
    id_curtida INT PRIMARY KEY IDENTITY,
    id_cliente INT NOT NULL,
    id_mensagem INT NOT NULL,
    data_curtida DATETIME DEFAULT GETDATE(),
    CONSTRAINT UQ_Curtida UNIQUE (id_cliente, id_mensagem), -- impede duplicado
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente),
    FOREIGN KEY (id_mensagem) REFERENCES Mensagem(id_mensagem)
);
GO
CREATE TRIGGER trg_Midia_AssignCodigo
ON Midia
INSTEAD OF INSERT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Midia (
        id_funcionario, id_tpmidia, titulo, sinopse, autor, editora, ano_publicacao,
        edicao, local_publicacao, numero_paginas, isbn, duracao, estudio, roteirista,
        disponibilidade, genero, imagem, codigo_exemplar
    )
    SELECT 
        i.id_funcionario, i.id_tpmidia, i.titulo, i.sinopse, i.autor, i.editora, i.ano_publicacao,
        i.edicao, i.local_publicacao, i.numero_paginas, i.isbn, i.duracao, i.estudio, i.roteirista,
        i.disponibilidade, i.genero, i.imagem,
        ISNULL((
            SELECT MAX(m.codigo_exemplar)
            FROM Midia m
            WHERE
              (
                (i.isbn IS NOT NULL AND i.isbn <> '' AND m.isbn = i.isbn) -- com ISBN
              )
              OR
              (
                (i.isbn IS NULL OR i.isbn = '')                           -- sem ISBN
                AND (m.isbn IS NULL OR m.isbn = '')
                AND m.titulo = i.titulo
                AND m.id_tpmidia = i.id_tpmidia
              )
        ),0) + 1 AS novo_codigo
    FROM inserted i;
END
GO


-- INSERTS COMPLETOS

INSERT INTO CargoFuncionario (nome_cargo) VALUES ('bibliotecario'), ('adm');
GO

INSERT INTO Funcionario (id_cargo, nome, cpf, email, telefone, senha, status_conta) VALUES
(1, 'Luiz Ricardo', '111.111.111-11', 'luiz.ricardo@email.com', '11999990001', 'senha123', 'ativo'),
(1, 'Henrique Bressan', '222.222.222-22', 'henrique.bressan@email.com', '11999990002', 'senha123', 'ativo'),
(2, 'Maria Vitoria', '333.333.333-33', 'maria.vitoria@email.com', '11999990003', 'senha123', 'ativo'),
(2, 'Luiz Pinheiro', '444.444.444-44', 'luiz.pinheiro@email.com', '11999990004', 'senha123', 'ativo'),
(1, 'Marcia X', '555.555.555-55', 'marcia.x@email.com', '11999990005', 'senha123', 'ativo');
GO

INSERT INTO Cliente (nome, username, cpf, email, telefone, senha, status_conta) VALUES 
('Gabriel Gon�alves', 'gabsfofinha', '666.666.666-66', 'gabriel.goncalves@email.com', '11999990006', 'abc123', 'banido'),
('Luiggi Alexandre', 'luiggiale', '777.777.777-77', 'luiggi.alexandre@email.com', '11999990007', 'senha456', 'ativo'),
('Pedro Dias', 'pedrodiass', '888.888.888-88', 'pedro.dias@email.com', '11999990008', 'senha789', 'ativo'),
('Rikelme Souza', 'rik1000grau', '999.999.999-99', 'rikelme.souza@email.com', '11999990009', '123senha', 'ativo'),
('Cau� Gon�alves', 'cauezinGon', '000.000.000-00', 'caue.goncalves@email.com', '11999990010', 'xyz987', 'ativo');

INSERT INTO TipoMidia (nome_tipo) VALUES ('livros'), ('filmes'), ('revistas'), ('e-book');
GO

INSERT INTO Midia (id_funcionario, id_tpmidia, titulo, sinopse, autor, editora, ano_publicacao, edicao, local_publicacao, numero_paginas, isbn, duracao, estudio, roteirista, disponibilidade, genero) VALUES
(1, 1, 'Mar Morto', '', 'Jorge Amado', 'Companhia das Letras', '1936', '1�', 'Salvador', 250, '9788535902773', NULL, NULL, NULL, 'dispon�vel', 'Romance'),
(2, 1, 'Vidas Secas', '', 'Graciliano Ramos', 'Record', '1938', '3�', 'Macei�', 200, '9788501042329', NULL, NULL, NULL, 'dispon�vel', 'Drama'),
(3, 2, 'O Auto da Compadecida', '', 'Ariano Suassuna', NULL, '2000', NULL, NULL, NULL, NULL, '1h40min', 'Globo Filmes', 'Guel Arraes', 'emprestado', 'Com�dia'),
(4, 3, 'Revista Superinteressante - Edi��o 402', '', NULL, 'Abril', '2022', NULL, 'S�o Paulo', 80, NULL, NULL, NULL, NULL, 'dispon�vel', 'Ci�ncia'),
(5, 4, '1984', '', 'George Orwell', 'Penguin', '1949', '2�', 'Londres', 328, '9780141036144', NULL, NULL, NULL, 'emprestado', 'Fic��o Cient��fica');
GO

INSERT INTO Reserva (id_cliente, id_midia, data_reserva, data_limite, status_reserva) VALUES 
(2, 1, '2025-06-14T14:00:00', '2025-06-17T14:00:00', 'ativa'),
(3, 2, '2025-06-15T14:00:00', '2025-06-18T14:00:00', 'ativa'),
(4, 3, '2025-06-13T14:00:00', '2025-06-16T14:00:00', 'expirada'),
(5, 4, '2025-06-16T14:00:00', '2025-06-19T14:00:00', 'ativa'),
(2, 5, '2025-06-17T14:00:00', '2025-06-20T14:00:00', 'cancelada');
GO

INSERT INTO Emprestimo (id_cliente, id_funcionario, id_midia, id_reserva, data_emprestimo, data_devolucao, limite_renovacoes) VALUES 
(2, 1, 1, 1, '2025-06-14', '2025-06-21', 1),
(3, 2, 2, 2, '2025-06-15', '2025-06-22', 0),
(4, 3, 3, 3, '2025-06-13', '2025-06-20', 2),
(5, 4, 5, 5, '2025-06-17', '2025-06-24', 0),
(3, 5, 4, 4, '2025-06-16', '2025-06-23', 1);
GO

INSERT INTO Mensagem (id_cliente, titulo, conteudo, data_postagem) VALUES 
(2, '', 'Seria �timo adicionarem "Dom Casmurro" � cole��o.', '2025-06-14T10:00:00'),
(3, '', 'Auto da Compadecida � uma obra-prima!', '2025-06-15T11:30:00'),
(4, '', 'Sugiro incluir "O Quinze" da Rachel de Queiroz.', '2025-06-16T12:45:00'),
(5, '', '"1984" deveria estar disponível tamb�m em �udio.', '2025-06-17T09:20:00'),
(3, '', 'A edi��o da Superinteressante de maio estava muito boa.', '2025-06-18T08:00:00');
GO

INSERT INTO Denuncia (id_funcionario, id_mensagem, id_cliente, data_denuncia, motivo, status_denuncia, acao_tomada) VALUES 
(1, 5, 2, '2025-06-18T14:00:00', 'Conte�do inadequado', 'resolvida', 'Mensagem ocultada'),
(2, 4, 3, '2025-06-17T13:00:00', 'Spam', 'pendente', NULL),
(3, 3, 4, '2025-06-16T11:00:00', 'Fora do t�pico', 'resolvida', 'Advert�ncia ao usu�rio'),
(4, 2, 5, '2025-06-15T10:30:00', 'Linguagem ofensiva', 'pendente', NULL),
(5, 1, 3, '2025-06-14T09:45:00', 'Duplicado', 'resolvida', 'Mensagem removida');
GO

INSERT INTO ListaDeDesejos (id_cliente, id_midia) VALUES 
(2, 1),
(3, 2),
(4, 3),
(5, 4),
(3, 5);
GO

INSERT INTO Evento (titulo, data_inicio, data_fim, local_evento, id_funcionario) VALUES
('Clube do Livro - Jorge Amado', '2025-09-10T19:00:00', '2025-09-10T21:00:00', 'Sala de leitura 1', 1),
('Exibi��o de Filme - O Auto da Compadecida', '2025-09-15T20:00:00', '2025-09-15T22:00:00', 'Audit�rio Principal', 2),
('Palestra: A Literatura Nordestina', '2025-09-20T18:00:00', '2025-09-20T20:00:00', 'Sala 2', 3),
('Semana de Ci�ncia e Conhecimento', '2025-09-25T09:00:00', '2025-09-25T17:00:00', 'Audit�rio B', 4),
('Encontro de e-Books - Discuss�es Modernas', '2025-10-02T17:00:00', '2025-10-02T19:00:00', 'Online', 5);
GO

INSERT INTO Indicacao (id_cliente, titulo_ind, autor_ind) VALUES
(2, 'Dom Casmurro', 'Machado de Assis'),
(3, 'O Quinze', 'Rachel de Queiroz'),
(4, 'Grande Sert�o: Veredas', 'Jo�o Guimar�es Rosa'),
(5, 'Mem�rias P�stumas de Br�s Cubas', 'Machado de Assis'),
(2, 'Capit�es da Areia', 'Jorge Amado');
GO

INSERT INTO Notificacao (id_cliente, titulo, mensagem) VALUES
(2, 'Lembrete de Devolu��o', 'Voc� tem um livro para devolver at� 21/06.'),
(3, 'Reserva Ativa', 'Sua reserva do livro "Vidas Secas" est� dispon�vel at� 18/06.'),
(1, 'Nova Den�ncia', 'Uma den�ncia foi atribu�da para sua an�lise.'),
(4, 'Evento Hoje', 'N�o esque�a: Palestra sobre Literatura Nordestina �s 18h.'),
(5, 'Indica��o Recebida', 'Sua indica��o de "O Quinze" est� em an�lise.');
GO

INSERT INTO Parametros (multa_dia, prazo_devolucao_dias, limite_emprestimos) VALUES 
(2.00, 14, 3);
GO

UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\Users\vitor\OneDrive\Documentos\SQL Server Management Studio\imagensTCC\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 1;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\Users\vitor\OneDrive\Documentos\SQL Server Management Studio\imagensTCC\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 2;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\Users\vitor\OneDrive\Documentos\SQL Server Management Studio\imagensTCC\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 3;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\Users\vitor\OneDrive\Documentos\SQL Server Management Studio\imagensTCC\\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 4;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\Users\vitor\OneDrive\Documentos\SQL Server Management Studio\imagensTCC\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 5;
GO
UPDATE Cliente
SET imagem_perfil = (
    SELECT * FROM OPENROWSET(BULK N'C:\Users\vitor\OneDrive\Documentos\SQL Server Management Studio\imagensTCC\bressan.jpg', SINGLE_BLOB) AS img
)
WHERE id_cliente = 1;
GO
UPDATE Cliente
SET imagem_perfil = (
    SELECT * FROM OPENROWSET(BULK N'C:\Users\vitor\OneDrive\Documentos\SQL Server Management Studio\imagensTCC\bressan.jpg', SINGLE_BLOB) AS img
)
WHERE id_cliente = 2;
GO
UPDATE Cliente
SET imagem_perfil = (
    SELECT * FROM OPENROWSET(BULK N'C:\Users\vitor\OneDrive\Documentos\SQL Server Management Studio\imagensTCC\bressan.jpg', SINGLE_BLOB) AS img
)
WHERE id_cliente = 3;
GO
UPDATE Cliente
SET imagem_perfil = (
    SELECT * FROM OPENROWSET(BULK N'C:\Users\vitor\OneDrive\Documentos\SQL Server Management Studio\imagensTCC\bressan.jpg', SINGLE_BLOB) AS img
)
WHERE id_cliente = 4;
GO
UPDATE Cliente
SET imagem_perfil = (
    SELECT * FROM OPENROWSET(BULK N'C:\Users\vitor\OneDrive\Documentos\SQL Server Management Studio\imagensTCC\bressan.jpg', SINGLE_BLOB) AS img
)
WHERE id_cliente = 5;
SELECT DISTINCT genero FROM Midia WHERE genero IS NOT NULL AND genero <> ''
GO
-- Midias
INSERT INTO Midia (id_funcionario, id_tpmidia, titulo, sinopse, autor, editora, ano_publicacao, disponibilidade, genero) VALUES
(1, 1, 'Dom Casmurro', 'Cl�ssico romance psicol�gico.', 'Machado de Assis', 'Principis', '1899', 'dispon�vel', 'Romance'),
(2, 1, 'Amor nos Tempos do C�lera', 'Hist�ria de amor marcada pelo tempo.', 'Gabriel Garc�a M�rquez', 'Record', '1985', 'dispon�vel', 'Romance'),
(3, 1, 'Capit�es da Areia', 'Romance social baiano.', 'Jorge Amado', 'Companhia das Letras', '1937', 'dispon�vel', 'Romance'),
(4, 1, 'Orgulho e Preconceito', 'Obra de Jane Austen.', 'Jane Austen', 'Penguin', '1813', 'dispon�vel', 'Romance'),
(5, 1, 'Grande Sert�o: Veredas', 'Obra-prima de Guimar�es Rosa.', 'Guimar�es Rosa', 'Nova Fronteira', '1956', 'dispon�vel', 'Romance'),
(1, 1, 'A Moreninha', 'Primeira novela rom�ntica brasileira.', 'Joaquim Manuel de Macedo', '�tica', '1844', 'dispon�vel', 'Novela'),
(2, 1, 'Senhora', 'Cl�ssico rom�ntico.', 'Jos� de Alencar', 'Principis', '1875', 'dispon�vel', 'Novela'),
(3, 1, 'Iracema', 'S�mbolo do romantismo indianista.', 'Jos� de Alencar', 'Saraiva', '1865', 'dispon�vel', 'Novela'),
(4, 1, 'Luc�ola', 'Obra urbana do romantismo.', 'Jos� de Alencar', '�tica', '1862', 'dispon�vel', 'Novela'),
(5, 1, 'O Mulato', 'Primeira obra naturalista brasileira.', 'Alu�sio Azevedo', 'Principis', '1881', 'dispon�vel', 'Novela'),
(1, 1, 'A Cartomante', 'Cl�ssico conto realista.', 'Machado de Assis', 'L&PM', '1884', 'dispon�vel', 'Conto'),
(2, 1, 'O Alienista', 'S�tira social.', 'Machado de Assis', 'Companhia das Letras', '1882', 'dispon�vel', 'Conto'),
(3, 1, 'O Espelho', 'Reflex�o sobre identidade.', 'Machado de Assis', 'Principis', '1882', 'dispon�vel', 'Conto'),
(4, 1, 'O Capote', 'Cl�ssico russo.', 'Nikolai G�gol', 'Penguin', '1842', 'dispon�vel', 'Conto'),
(5, 1, 'O Gato Preto', 'Terror psicol�gico.', 'Edgar Allan Poe', 'Darkside', '1843', 'dispon�vel', 'Conto'),
(1, 1, 'A Cigarra e a Formiga', 'Cl�ssica f�bula.', 'La Fontaine', 'Companhia das Letrinhas', '1668', 'dispon�vel', 'F�bula'),
(2, 1, 'A Raposa e as Uvas', 'F�bula sobre desejo.', 'Esopo', '�tica', '500', 'dispon�vel', 'F�bula'),
(3, 1, 'O Le�o e o Rato', 'F�bula sobre gratid�o.', 'Esopo', 'Saraiva', '500', 'dispon�vel', 'F�bula'),
(4, 1, 'A Lebre e a Tartaruga', 'Persist�ncia vence.', 'Esopo', '�tica', '500', 'dispon�vel', 'F�bula'),
(5, 1, 'F�bulas de Esopo', 'Colet�nea cl�ssica.', 'Esopo', 'Dom�nio P�blico', '2001', 'dispon�vel', 'F�bula'),
(1, 1, 'O Senhor dos An�is', 'Trilogia �pica de fantasia.', 'J.R.R. Tolkien', 'Martins Fontes', '1954', 'dispon�vel', 'Fantasia'),
(2, 1, 'Harry Potter e a Pedra Filosofal', 'Primeiro livro da saga.', 'J.K. Rowling', 'Rocco', '1997', 'dispon�vel', 'Fantasia'),
(3, 1, 'O Hobbit', 'Aventura fant�stica.', 'J.R.R. Tolkien', 'HarperCollins', '1937', 'dispon�vel', 'Fantasia'),
(4, 1, 'As Cr�nicas de N�rnia', 'Mundo m�gico de N�rnia.', 'C.S. Lewis', 'HarperCollins', '1950', 'dispon�vel', 'Fantasia'),
(5, 1, 'Eragon', 'Drag�es e magia.', 'Christopher Paolini', 'Rocco', '2003', 'dispon�vel', 'Fantasia'),
(1, 1, 'Funda��o', 'Imp�rio gal�ctico em colapso.', 'Isaac Asimov', 'Aleph', '1951', 'dispon�vel', 'Fic��o Cient�fica'),
(2, 1, 'Neuromancer', 'Cyberpunk cl�ssico.', 'William Gibson', 'Aleph', '1984', 'dispon�vel', 'Fic��o Cient�fica'),
(3, 1, 'Eu, Rob�', 'Contos sobre rob�tica.', 'Isaac Asimov', 'Aleph', '1950', 'dispon�vel', 'Fic��o Cient�fica'),
(4, 1, '2001: Uma Odisseia no Espa�o', 'Cl�ssico de Arthur C. Clarke.', 'Arthur C. Clarke', 'Aleph', '1968', 'dispon�vel', 'Fic��o Cient�fica'),
(5, 1, 'Duna', 'Planeta deserto e intrigas pol�ticas.', 'Frank Herbert', 'Aleph', '1965', 'dispon�vel', 'Fic��o Cient�fica'),
(1, 1, '1984', 'Sociedade vigiada pelo Grande Irm�o.', 'George Orwell', 'Companhia Editora Nacional', '1949', 'dispon�vel', 'Distopia'),
(2, 1, 'Admir�vel Mundo Novo', 'Sociedade futurista controlada.', 'Aldous Huxley', 'Globo', '1932', 'dispon�vel', 'Distopia'),
(3, 1, 'Fahrenheit 451', 'Livros proibidos.', 'Ray Bradbury', 'Biblioteca Azul', '1953', 'dispon�vel', 'Distopia'),
(4, 1, 'Jogos Vorazes', 'Competi��o mortal televisiva.', 'Suzanne Collins', 'Rocco', '2008', 'dispon�vel', 'Distopia'),
(5, 1, 'Laranja Mec�nica', 'Juventude violenta e controle social.', 'Anthony Burgess', 'Aleph', '1962', 'dispon�vel', 'Distopia'),
(1, 1, 'Utopia', 'Sociedade perfeita idealizada.', 'Thomas More', 'Principis', '1516', 'dispon�vel', 'Utopia'),
(2, 1, 'A Cidade do Sol', 'Sociedade justa e ideal.', 'Tommaso Campanella', 'Martins Fontes', '1602', 'dispon�vel', 'Utopia'),
(3, 1, 'Looking Backward', 'Vis�o ut�pica do futuro.', 'Edward Bellamy', 'Penguin', '1888', 'dispon�vel', 'Utopia'),
(4, 1, 'Walden Two', 'Comunidade ut�pica behaviorista.', 'B.F. Skinner', 'Macmillan', '1948', 'dispon�vel', 'Utopia'),
(5, 1, 'News from Nowhere', 'Vis�o ut�pica socialista.', 'William Morris', 'Routledge', '1890', 'dispon�vel', 'Utopia'),
(1, 1, 'Dr�cula', 'Cl�ssico de vampiro.', 'Bram Stoker', 'Principis', '1897', 'dispon�vel', 'Terror'),
(2, 1, 'Frankenstein', 'Cria��o que ganha vida.', 'Mary Shelley', 'Penguin', '1818', 'dispon�vel', 'Terror'),
(3, 1, 'O Iluminado', 'Hotel amaldi�oado.', 'Stephen King', 'Suma', '1977', 'dispon�vel', 'Terror'),
(4, 1, 'It: A Coisa', 'For�a maligna em Derry.', 'Stephen King', 'Suma', '1986', 'dispon�vel', 'Terror'),
(5, 1, 'O Exorcista', 'Possess�o demon�aca.', 'William Peter Blatty', 'Harper & Row', '1971', 'dispon�vel', 'Terror'),
(1, 1, 'O Sil�ncio dos Inocentes', 'Serial killer Hannibal Lecter.', 'Thomas Harris', 'Record', '1988', 'dispon�vel', 'Suspense'),
(2, 1, 'Garota Exemplar', 'Desaparecimento misterioso.', 'Gillian Flynn', 'Intr�nseca', '2012', 'dispon�vel', 'Suspense'),
(3, 1, 'A Garota no Trem', 'Suspense psicol�gico.', 'Paula Hawkins', 'Record', '2015', 'dispon�vel', 'Suspense'),
(4, 1, 'O Colecionador', 'Homem sequestra jovem.', 'John Fowles', 'Companhia das Letras', '1963', 'dispon�vel', 'Suspense'),
(5, 1, 'Antes de Dormir', 'Mulher sem mem�ria di�ria.', 'S.J. Watson', 'Record', '2011', 'dispon�vel', 'Suspense'),
(1, 1, 'Sherlock Holmes: Um Estudo em Vermelho', 'Primeira aventura de Holmes e Watson.', 'Arthur Conan Doyle', 'Principis', '1887', 'dispon�vel', 'Policial'),
(2, 1, 'Assassinato no Expresso do Oriente', 'Mist�rio resolvido por Poirot.', 'Agatha Christie', 'HarperCollins', '1934', 'dispon�vel', 'Policial'),
(3, 1, 'O Falc�o Malt�s', 'Caso noir cl�ssico.', 'Dashiell Hammett', 'Companhia das Letras', '1930', 'dispon�vel', 'Policial'),
(4, 1, 'Os Homens que N�o Amavam as Mulheres', 'Investiga��o jornal�stica e policial.', 'Stieg Larsson', 'Companhia das Letras', '2005', 'dispon�vel', 'Policial'),
(5, 1, 'A Sangue Frio', 'Investiga��o de assassinato real.', 'Truman Capote', 'Random House', '1966', 'dispon�vel', 'Policial'),
(1, 1, 'A Ilha do Tesouro', 'Ca�a ao tesouro pirata.', 'Robert Louis Stevenson', 'Penguin', '1883', 'dispon�vel', 'Aventura'),
(2, 1, 'As Aventuras de Tom Sawyer', 'Juventude travessa �s margens do Mississippi.', 'Mark Twain', 'Penguin', '1876', 'dispon�vel', 'Aventura'),
(3, 1, 'Robinson Cruso�', 'N�ufrago em ilha deserta.', 'Daniel Defoe', 'Penguin', '1719', 'dispon�vel', 'Aventura'),
(4, 1, 'Os Tr�s Mosqueteiros', 'Cl�ssico de capa e espada.', 'Alexandre Dumas', 'Martins Fontes', '1844', 'dispon�vel', 'Aventura'),
(5, 1, 'Viagem ao Centro da Terra', 'Expedi��o subterr�nea fant�stica.', 'J�lio Verne', 'Principis', '1864', 'dispon�vel', 'Aventura'),
(1, 1, 'A �ltima Li��o', 'Reflex�es de vida.', 'Randy Pausch', 'Editora Agir', '2008', 'dispon�vel', 'Biografia'),
(2, 1, 'Longa Caminhada at� a Liberdade', 'Autobiografia de Nelson Mandela.', 'Nelson Mandela', 'Companhia das Letras', '1994', 'dispon�vel', 'Biografia'),
(3, 1, 'Minha Vida em Dois Mundos', 'Relato de Chico Xavier.', 'Chico Xavier', 'FEB', '1974', 'dispon�vel', 'Biografia'),
(4, 1, 'Steve Jobs', 'Biografia autorizada.', 'Walter Isaacson', 'Companhia das Letras', '2011', 'dispon�vel', 'Biografia'),
(5, 1, 'Eu Sou Malala', 'Hist�ria de coragem e educa��o.', 'Malala Yousafzai', 'Companhia das Letras', '2013', 'dispon�vel', 'Biografia'),
(1, 1, 'O Di�rio de Anne Frank', 'Relato do Holocausto.', 'Anne Frank', 'Record', '1947', 'dispon�vel', 'Di�rio'),
(2, 1, 'Di�rio de um Banana', 'Cr�nicas de um jovem atrapalhado.', 'Jeff Kinney', 'V&R', '2007', 'dispon�vel', 'Di�rio'),
(3, 1, 'Querido Di�rio Ot�rio', 'S�rie infantojuvenil de humor.', 'Jim Benton', 'Fundamento', '2004', 'dispon�vel', 'Di�rio'),
(4, 1, 'Di�rio de Zlata', 'Viv�ncias da guerra na B�snia.', 'Zlata Filipovic', 'Companhia das Letras', '1993', 'dispon�vel', 'Di�rio'),
(5, 1, 'Di�rio �ntimo', 'Reflex�es e ang�stias pessoais.', 'Lima Barreto', 'Penguin', '1903', 'dispon�vel', 'Di�rio'),
(1, 1, 'A Interpreta��o dos Sonhos', 'Obra seminal de Freud.', 'Sigmund Freud', 'Imago', '1900', 'dispon�vel', 'Ensaio'),
(2, 1, 'O Segundo Sexo', 'Fundamento do feminismo.', 'Simone de Beauvoir', 'Nova Fronteira', '1949', 'dispon�vel', 'Ensaio'),
(3, 1, 'A Rep�blica', 'Discuss�o sobre pol�tica e justi�a.', 'Plat�o', 'Principis', '380 BC', 'dispon�vel', 'Ensaio'),
(4, 1, 'A Desobedi�ncia Civil', 'Reflex�o sobre resist�ncia pol�tica.', 'Henry David Thoreau', 'Principis', '1849', 'dispon�vel', 'Ensaio'),
(5, 1, 'Medita��es', 'Pensamentos do imperador romano.', 'Marco Aur�lio', 'Penguin', '180', 'dispon�vel', 'Ensaio'),
(1, 1, 'A Origem das Esp�cies - Artigo Acad�mico', 'Resumo cient�fico das ideias de Darwin.', 'Charles Darwin', 'Nature', '1859', 'dispon�vel', 'Artigo'),
(2, 1, 'Computing Machinery and Intelligence', 'Artigo sobre intelig�ncia artificial.', 'Alan Turing', 'Mind Journal', '1950', 'dispon�vel', 'Artigo'),
(3, 1, 'A Teoria da Relatividade Restrita', 'Primeira formula��o por Einstein.', 'Albert Einstein', 'Annalen der Physik', '1905', 'dispon�vel', 'Artigo'),
(4, 1, 'O Que � Literatura?', 'Reflex�o existencial.', 'Jean-Paul Sartre', 'Critique', '1947', 'dispon�vel', 'Artigo'),
(5, 1, 'A �tica Protestante e o Esp�rito do Capitalismo', 'Artigo precursor de Weber.', 'Max Weber', 'Archiv f�r Sozialwissenschaft', '1904', 'dispon�vel', 'Artigo'),
(1, 1, 'Para Gostar de Ler - Cr�nicas', 'Colet�nea brasileira.', 'Luis Fernando Verissimo', '�tica', '1981', 'dispon�vel', 'Cr�nica'),
(2, 1, 'A Vida que Ningu�m V�', 'Cr�nicas cotidianas.', 'Eliane Brum', 'Arquip�lago', '2006', 'dispon�vel', 'Cr�nica'),
(3, 1, 'Com�dias da Vida Privada', 'Humor e ironia do cotidiano.', 'Luis Fernando Verissimo', 'Objetiva', '1994', 'dispon�vel', 'Cr�nica'),
(4, 1, 'Cem Cr�nicas Escolhidas', 'Colet�nea de Rubem Braga.', 'Rubem Braga', 'Record', '1992', 'dispon�vel', 'Cr�nica'),
(5, 1, 'Cr�nicas para Ler na Escola', 'Sele��o de textos para jovens.', 'Carlos Drummond de Andrade', 'Record', '2000', 'dispon�vel', 'Cr�nica'),
(1, 1, 'Rota 66', 'Hist�ria da viol�ncia policial no Brasil.', 'Caco Barcellos', 'Companhia das Letras', '1992', 'dispon�vel', 'Reportagem'),
(2, 1, 'Holocausto Brasileiro', 'Abusos em Barbacena.', 'Daniela Arbex', 'Gera��o Editorial', '2013', 'dispon�vel', 'Reportagem'),
(3, 1, 'Abusado', 'Hist�ria do tr�fico no Rio.', 'Caco Barcellos', 'Companhia das Letras', '2003', 'dispon�vel', 'Reportagem'),
(4, 1, 'A Ditadura Envergonhada', 'Investiga��o jornal�stica.', 'Elio Gaspari', 'Companhia das Letras', '2002', 'dispon�vel', 'Reportagem'),
(5, 1, 'Os Sert�es', 'Relato de Canudos.', 'Euclides da Cunha', 'Principis', '1902', 'dispon�vel', 'Reportagem'),
(1, 1, 'Revista National Geographic - Edi��o Amaz�nia', 'Explora��o cient�fica e cultural.', 'V�rios Autores', 'National Geographic Society', '2020', 'dispon�vel', 'Revista'),
(2, 1, 'Revista Superinteressante - Intelig�ncia Artificial', 'Especial sobre IA.', 'Editora Abril', 'Abril', '2019', 'dispon�vel', 'Revista'),
(3, 1, 'Revista Piau� - Edi��o Pol�tica', 'An�lises contempor�neas.', 'V�rios Autores', 'Piau�', '2018', 'dispon�vel', 'Revista'),
(4, 1, 'Revista Scientific American - Cosmologia', 'Avan�os sobre o universo.', 'V�rios Autores', 'Scientific American', '2021', 'dispon�vel', 'Revista'),
(5, 1, 'Revista Quatro Rodas - Carros El�tricos', 'Tend�ncias da ind�stria automotiva.', 'Editora Abril', 'Abril', '2022', 'dispon�vel', 'Revista'),
(1, 1, 'Jornal Folha de S. Paulo - Edi��o de 1985', 'Diretas J� e pol�tica nacional.', 'Folha de S. Paulo', 'Folha', '1985', 'dispon�vel', 'Peri�dico'),
(2, 1, 'The New York Times - 11/09/2001', 'Cobertura do atentado.', 'NYT', 'NYT', '2001', 'dispon�vel', 'Peri�dico'),
(3, 1, 'Le Monde - Maio de 1968', 'Movimentos estudantis franceses.', 'Le Monde', 'Le Monde', '1968', 'dispon�vel', 'Peri�dico'),
(4, 1, 'The Guardian - Brexit Referendum', 'Sa�da do Reino Unido da UE.', 'The Guardian', 'Guardian', '2016', 'dispon�vel', 'Peri�dico'),
(5, 1, 'Estad�o - Copa do Mundo 1970', 'Cobertura da sele��o tricampe�.', 'O Estado de S. Paulo', 'Estad�o', '1970', 'dispon�vel', 'Peri�dico'),
(1, 1, 'Os Lus�adas', 'Poema �pico sobre as navega��es.', 'Lu�s de Cam�es', 'Principis', '1572', 'dispon�vel', 'Poesia'),
(2, 1, 'Cantos', 'Obra po�tica simbolista.', 'Ezra Pound', 'Penguin', '1925', 'dispon�vel', 'Poesia'),
(3, 1, 'A Rosa do Povo', 'Poesia engajada brasileira.', 'Carlos Drummond de Andrade', 'Record', '1945', 'dispon�vel', 'Poesia'),
(4, 1, 'Folhas de Relva', 'Poemas de liberdade.', 'Walt Whitman', 'Penguin', '1855', 'dispon�vel', 'Poesia'),
(5, 1, 'Alguma Poesia', 'Obra inicial de Drummond.', 'Carlos Drummond de Andrade', 'Companhia das Letras', '1930', 'dispon�vel', 'Poesia'),
(1, 1, 'O Auto da Compadecida', 'Pe�a c�mica popular.', 'Ariano Suassuna', 'Nova Fronteira', '1955', 'dispon�vel', 'Com�dia'),
(2, 1, 'As R�s', 'Com�dia grega cl�ssica.', 'Arist�fanes', 'Penguin', '405 BC', 'dispon�vel', 'Com�dia'),
(3, 1, 'A Megera Domada', 'Com�dia rom�ntica.', 'William Shakespeare', 'Principis', '1592', 'dispon�vel', 'Com�dia'),
(4, 1, 'As Alegres Comadres de Windsor', 'Humor popular shakespeariano.', 'William Shakespeare', 'Penguin', '1602', 'dispon�vel', 'Com�dia'),
(5, 1, 'O Doente Imagin�rio', 'S�tira social.', 'Moli�re', 'Penguin', '1673', 'dispon�vel', 'Com�dia'),
(1, 1, 'Uma Breve Hist�ria do Tempo', 'Explica��o do universo.', 'Stephen Hawking', 'Intr�nseca', '1988', 'dispon�vel', 'Ci�ncia'),
(2, 1, 'O Gene Ego�sta', 'Evolu��o sob nova �tica.', 'Richard Dawkins', 'Companhia das Letras', '1976', 'dispon�vel', 'Ci�ncia'),
(3, 1, 'Cosmos', 'Explora��o do universo.', 'Carl Sagan', 'Companhia das Letras', '1980', 'dispon�vel', 'Ci�ncia'),
(4, 1, 'Princ�pios Matem�ticos da Filosofia Natural', 'Obra de Newton.', 'Isaac Newton', 'Principis', '1687', 'dispon�vel', 'Ci�ncia'),
(5, 1, 'A Estrutura das Revolu��es Cient�ficas', 'Mudan�as de paradigmas.', 'Thomas Kuhn', 'Perspectiva', '1962', 'dispon�vel', 'Ci�ncia'),
(1, 1, 'Hamlet', 'Trag�dia shakespeariana.', 'William Shakespeare', 'Penguin', '1603', 'dispon�vel', 'Drama'),
(2, 1, 'Romeu e Julieta', 'Drama rom�ntico cl�ssico.', 'William Shakespeare', 'Principis', '1597', 'dispon�vel', 'Drama'),
(3, 1, '�dipo Rei', 'Trag�dia grega.', 'S�focles', 'Penguin', '429 BC', 'dispon�vel', 'Drama'),
(4, 1, 'Esperando Godot', 'Pe�a do absurdo.', 'Samuel Beckett', 'Companhia das Letras', '1952', 'dispon�vel', 'Drama'),
(5, 1, 'Vestido de Noiva', 'Marco do teatro moderno brasileiro.', 'Nelson Rodrigues', 'Nova Fronteira', '1943', 'dispon�vel', 'Drama'),
(1, 1, 'O Pequeno Pr�ncipe', 'F�bula filos�fica moderna.', 'Antoine de Saint-Exup�ry', 'Agir', '1943', 'dispon�vel', 'Outros'),
(2, 1, 'Sapiens: Uma Breve Hist�ria da Humanidade', 'An�lise da evolu��o humana.', 'Yuval Noah Harari', 'Companhia das Letras', '2011', 'dispon�vel', 'Outros'),
(3, 1, '1984 - Edi��o Ilustrada', 'Nova edi��o do cl�ssico.', 'George Orwell', 'Companhia das Letras', '2016', 'dispon�vel', 'Outros'),
(4, 1, 'A Arte da Guerra', 'Estrat�gia e filosofia.', 'Sun Tzu', 'Principis', '500 BC', 'dispon�vel', 'Outros'),
(5, 1, 'O Livro dos Esp�ritos', 'Obra b�sica do espiritismo.', 'Allan Kardec', 'FEB', '1857', 'dispon�vel', 'Outros');
go

-- Reservas adicionais
INSERT INTO Reserva (id_cliente, id_midia, data_reserva, data_limite, status_reserva) VALUES
(2, 6, GETDATE(), DATEADD(DAY, 3, GETDATE()), 'ativa'),
(3, 7, GETDATE(), DATEADD(DAY, 3, GETDATE()), 'ativa'),
(4, 8, GETDATE(), DATEADD(DAY, 3, GETDATE()), 'ativa'),
(5, 9, GETDATE(), DATEADD(DAY, 3, GETDATE()), 'ativa'),
(2, 10, GETDATE(), DATEADD(DAY, 3, GETDATE()), 'ativa');
go
-- Emprestimos adicionais
INSERT INTO Emprestimo (id_cliente, id_funcionario, id_midia, data_emprestimo, data_devolucao) VALUES
(2, 1, 6, GETDATE(), DATEADD(DAY, 7, GETDATE())),
(3, 2, 7, GETDATE(), DATEADD(DAY, 7, GETDATE())),
(4, 3, 8, GETDATE(), DATEADD(DAY, 7, GETDATE())),
(5, 4, 9, GETDATE(), DATEADD(DAY, 7, GETDATE())),
(3, 5, 10, GETDATE(), DATEADD(DAY, 7, GETDATE()));
go
-- Mensagens extras
INSERT INTO Mensagem (id_cliente, titulo, conteudo, data_postagem) VALUES
(2, 'Sugest�o', 'Gostaria de ver mais t�tulos de fantasia.', GETDATE()),
(3, 'Coment�rio', 'Excelente sele��o de revistas cient�ficas!', GETDATE()),
(1, 'Coment�rio', 'Achei esse livro muito bom!', GETDATE()),
(2, 'Coment�rio', 'Prefiro a adapta��o do filme.', GETDATE()),
(3, 'D�vida', 'Algu�m recomenda outra obra do mesmo autor?', GETDATE());
go
-- Den�ncias extras
INSERT INTO Denuncia (id_funcionario, id_mensagem, id_cliente, data_denuncia, motivo, status_denuncia) VALUES
(1, 1, 2, '2025-09-01', 'Conte�do inadequado', 'pendente'),
(2, 2, 3, '2025-09-02', 'Spam', 'resolvida'),
(3, 3, 4, '2025-09-03', 'Fora do t�pico', 'pendente'),
(4, 4, 5, '2025-09-04', 'Duplicado', 'resolvida'),
(5, 5, 2, '2025-09-05', 'Linguagem ofensiva', 'pendente'),
(1, 2, 3, '2025-09-06', 'Conte�do inadequado', 'resolvida'),
(2, 3, 4, '2025-09-07', 'Linguagem ofensiva', 'pendente'),
(3, 4, 5, '2025-09-08', 'Spam', 'resolvida'),
(4, 5, 2, '2025-09-09', 'Conte�do inadequado', 'pendente'),
(5, 1, 3, '2025-09-10', 'Duplicado', 'resolvida');
go
-- Eventos extras
INSERT INTO Evento (titulo, data_inicio, data_fim, local_evento, id_funcionario) VALUES
('Clube do Livro - Fantasia', '2025-09-15T18:00:00', '2025-09-15T20:00:00', 'Sala 1', 1),
('Exibi��o de Filme - Terror', '2025-09-16T19:00:00', '2025-09-16T21:00:00', 'Audit�rio Principal', 2),
('Palestra - Literatura Contempor�nea', '2025-09-17T17:00:00', '2025-09-17T19:00:00', 'Sala 2', 3),
('Workshop de Escrita Criativa', '2025-09-18T14:00:00', '2025-09-18T16:00:00', 'Sala 3', 4),
('Debate: Fic��o Cient�fica', '2025-09-19T18:00:00', '2025-09-19T20:00:00', 'Online', 5),
('Oficina de Poesia', '2025-09-20T10:00:00', '2025-09-20T12:00:00', 'Sala 4', 1),
('Encontro de Autores', '2025-09-21T15:00:00', '2025-09-21T17:00:00', 'Audit�rio B', 2),
('Semin�rio de Hist�ria', '2025-09-22T09:00:00', '2025-09-22T11:00:00', 'Sala 5', 3),
('Mesa Redonda - Jornalismo', '2025-09-23T16:00:00', '2025-09-23T18:00:00', 'Online', 4),
('Clube de Leitura Infantil', '2025-09-24T10:00:00', '2025-09-24T12:00:00', 'Sala 6', 5);
go
-- Indica��es extras
INSERT INTO Indicacao (id_cliente, titulo_ind, autor_ind) VALUES
(2, 'O Pequeno Pr�ncipe', 'Antoine de Saint-Exup�ry'),
(3, '1984', 'George Orwell'),
(4, 'Dom Casmurro', 'Machado de Assis'),
(5, 'Vidas Secas', 'Graciliano Ramos'),
(2, 'A Revolu��o dos Bichos', 'George Orwell'),
(3, 'O Auto da Compadecida', 'Ariano Suassuna'),
(4, 'Capit�es da Areia', 'Jorge Amado'),
(5, 'Mem�rias P�stumas de Br�s Cubas', 'Machado de Assis'),
(2, 'Grande Sert�o: Veredas', 'Jo�o Guimar�es Rosa'),
(3, 'O Quinze', 'Rachel de Queiroz');
go
-- Notifica��es extras
INSERT INTO Notificacao (id_cliente, titulo, mensagem) VALUES
(2, 'Lembrete de Devolu��o', 'Voc� tem um livro para devolver at� 25/09.'),
(3, 'Reserva Ativa', 'Sua reserva de "1984" est� dispon�vel at� 26/09.'),
(4, 'Evento Hoje', 'N�o esque�a: Palestra de Literatura �s 17h.'),
(5, 'Nova Den�ncia', 'Uma den�ncia foi atribu�da para sua an�lise.'),
(2, 'Indica��o Aceita', 'Sua indica��o de "O Pequeno Pr�ncipe" foi aprovada.'),
(3, 'Renova��o', 'Seu empr�stimo de "1984" foi renovado por mais 7 dias.'),
(4, 'Reserva Expirada', 'Sua reserva de "Dom Casmurro" expirou.'),
(5, 'Mensagem Recebida', 'Voc� recebeu uma nova mensagem no f�rum.'),
(2, 'Evento Cancelado', 'O evento "Clube do Livro" foi cancelado.'),
(3, 'Notifica��o Especial', 'Confira as novidades da semana na biblioteca.');
go
-- Funcionarios extras
INSERT INTO Funcionario (id_cargo, nome, cpf, email, telefone, senha, status_conta) VALUES
(1, 'Carlos Henrique', '666.666.666-66', 'carlos.henrique@email.com', '11999990011', 'senha123', 'ativo'),
(2, 'Fernanda Lima', '777.777.777-77', 'fernanda.lima@email.com', '11999990012', 'senha123', 'ativo'),
(1, 'Roberto Soares', '888.888.888-88', 'roberto.soares@email.com', '11999990013', 'senha123', 'ativo'),
(2, 'Patricia Gomes', '999.999.999-99', 'patricia.gomes@email.com', '11999990014', 'senha123', 'ativo'),
(1, 'Thiago Almeida', '000.000.000-01', 'thiago.almeida@email.com', '11999990015', 'senha123', 'ativo');
go
-- Funcionarios extras
INSERT INTO Cliente (nome, username, cpf, email, telefone, senha, status_conta) VALUES
('Ana Clara', 'anaclara12', '111.111.111-12', 'ana.clara@email.com', '11999990016', 'senha123', 'ativo'),
('Bruno Santos', 'brunos', '222.222.222-23', 'bruno.santos@email.com', '11999990017', 'senha123', 'ativo'),
('Camila Ribeiro', 'camilar', '333.333.333-34', 'camila.ribeiro@email.com', '11999990018', 'senha123', 'ativo'),
('Diego Martins', 'diegom', '444.444.444-45', 'diego.martins@email.com', '11999990019', 'senha123', 'ativo'),
('Elisa Fernandes', 'elisaf', '555.555.555-56', 'elisa.fernandes@email.com', '11999990020', 'senha123', 'ativo');



/*
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 1;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 2;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 3;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 4;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 5;


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 6;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 7;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 8;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 9;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 10;



UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 11;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 12;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 13;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 14;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 15;



UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 16;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 17;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 18;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 19;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 20;


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 21;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 22;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 23;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 24;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 25;

UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 26;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 27;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 28;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 29;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 30;


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 31;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 32;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 33;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 34;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 35;


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 36;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 37;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 38;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 39;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 40;


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 41;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 42;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 43;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 44;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 45;


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 46;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 47;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 48;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 49;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 50;


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 51;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 52;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 53;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 54;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 55;



UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 56;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 57;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 58;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 59;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 60;


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 61;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 62;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 63;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 64;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 65;


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 66;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 67;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 68;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 69;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 70;


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 71;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 72;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 73;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 74;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 75;


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 76;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 77;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 78;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 79;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 80;


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 81;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 82;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 83;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 84;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 85;

UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 86;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 87;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 88;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 89;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 90;

UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 91;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 92;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 93;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 94;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 95;

UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 96;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 97;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 98;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 99;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 100;

UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 101;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 102;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 103;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 104;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 105;

UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 106;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 107;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 108;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 109;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 110;

UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 111;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 112;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 113;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 114;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 115;

UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 116;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 117;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 118;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 119;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 120;

UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 121;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 122;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 123;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 124;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 125;

UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\MarMorto-JorgeAmado.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 126;
GO


UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\VidasSecas-GracilianoRamos.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 127;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\AutoDaCompadecida-ArianoSuassuna.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 128;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\SuperInteressante_402.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 129;
GO
UPDATE Midia
SET imagem = (
    SELECT * FROM OPENROWSET(BULK N'C:\xampp\htdocs\web-tcc-final\DB\imagens\1984-GeorgeOrwell.jpg', SINGLE_BLOB) AS img
)
WHERE id_midia = 130;
*/

/*Select * from Midia

SELECT id_midia, DATALENGTH(imagem) AS tamanho_em_bytes
FROM Midia
WHERE id_midia = 2;

SELECT imagem FROM Midia WHERE id_midia = 1

select * from Funcionario --ADICIONAR
select * from Cliente --ADICIONAR
select * from Midia
select * from Reserva
select * from Emprestimo
select * from Mensagem
select * from Denuncia
select * from Evento
select * from Indicacao 
select * from Notificacao
*/