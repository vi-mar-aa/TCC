<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('Método não permitido');
}

$email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
$code = preg_replace('/\D/', '', $_POST['code'] ?? ''); // Remove não-números

if (!$email || strlen($code) !== 6) {
    die('Dados inválidos');
}

// Verificar se existe sessão de recuperação
if (!isset($_SESSION['recovery_email']) || !isset($_SESSION['recovery_code']) || !isset($_SESSION['recovery_time'])) {
    die('Sessão expirada. Solicite um novo código.');
}

// Verificar se o email confere
if ($_SESSION['recovery_email'] !== $email) {
    die('Email não confere com a solicitação.');
}

// Verificar se o código não expirou (15 minutos)
$timeLimit = 15 * 60; // 15 minutos em segundos
if (time() - $_SESSION['recovery_time'] > $timeLimit) {
    // Limpar sessão expirada
    unset($_SESSION['recovery_email']);
    unset($_SESSION['recovery_code']);
    unset($_SESSION['recovery_time']);
    die('Código expirado. Solicite um novo código.');
}

// Verificar se o código está correto
if ($_SESSION['recovery_code'] !== $code) {
    die('Código equivocado. Verifique e tente novamente.');
}

// Código válido! Gerar token de redefinição de senha
$resetToken = bin2hex(random_bytes(32));

// Salvar token na sessão (em produção, salve no banco de dados)
$_SESSION['reset_token'] = $resetToken;
$_SESSION['reset_email'] = $email;
$_SESSION['reset_time'] = time();

// Limpar dados do código
unset($_SESSION['recovery_email']);
unset($_SESSION['recovery_code']);
unset($_SESSION['recovery_time']);

// Log da verificação bem-sucedida
error_log("Código verificado com sucesso para: $email em " . date('Y-m-d H:i:s'));

echo "Código válido! Token: $resetToken";

exit;
?>