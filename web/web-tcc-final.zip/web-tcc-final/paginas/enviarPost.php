<?php

session_start();


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$titulo = $_POST['titulo'];
	$conteudo = $_POST['conteudo'];
	$fk_cliente = $_SESSION['id_cli'];
	
    //$serverName = "LAB02H-00";
	$serverName ="LAB21T-Prof\SQLEXPRESS";
    $database = "Littera";
    $username = "sa";
    $password = "etesp";

    try {
        $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		
	$stmt = $conn->prepare("insert into Mensagem (id_cliente,titulo,conteudo,data_postagem) values (:id_cli,:titulo,:conteudo,getdate())");

		$stmt->bindParam(':id_cli', $fk_cliente);
		$stmt->bindParam(':titulo', $titulo);
		$stmt->bindParam(':conteudo', $conteudo);
        $stmt->execute();

        echo "<script>alert('post feito com sucesso!'); window.location.href='forum.php';</script>";
		
    } catch (PDOException $e) {
        echo "Erro no envio: " . $e->getMessage();
    }
}
?>
