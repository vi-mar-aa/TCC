<?php
session_start();

if ($_SERVER['REQUEST_METHOD']=='POST') {
    
    $email = $_POST['email'];
	$cpf = $_POST['cpf'];
    $nova_senha = $_POST['nova_senha'];
	

//$serverName = "LAB02H-00"; // ou IP do servidor SQL
$serverName ="LAB21T-14\SQLEXPRESS";
$database = "Littera";
$username = "sa";
$password = "etesp";

try {
    // Conexão usando PDO com driver sqlsrv
    $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Preparar a chamada da procedure
    $stmt = $conn->prepare("EXEC sp_ClienteResetarSenhaViaCpfEmail @email = :email, @cpf = :cpf, @nova_senha = :nova_senha");
    $stmt->bindParam(':email', $email);
	$stmt->bindParam(':cpf', $cpf);
    $stmt->bindParam(':nova_senha', $nova_senha);
    $stmt->execute();
	echo "<script>alert('Alterações feitas com sucesso!'); window.location.href='Login.html';</script>";
		
    } catch (PDOException $e) {
        echo "Erro no cadastro: " . $e->getMessage();
    }
}


?>