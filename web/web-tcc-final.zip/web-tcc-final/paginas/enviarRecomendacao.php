<?php

session_start();


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$titulo_ind = $_POST['titulo_ind'];
	$autor_ind = $_POST['autor_ind'];
	$fk_cliente = $_SESSION['id_cli'];
	
    //$serverName = "LAB02H-00";
	$serverName ="LAB21T-Prof\SQLEXPRESS";
    $database = "Littera";
    $username = "sa";
    $password = "etesp";

    try {
        $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		
	$stmt = $conn->prepare("insert into Indicacao (id_cliente,titulo_ind,autor_ind,data_indicacao) values (:id_cli,:titulo_ind,:autor_ind,getdate())");

		$stmt->bindParam(':id_cli', $fk_cliente);
		$stmt->bindParam(':titulo_ind', $titulo_ind);
		$stmt->bindParam(':autor_ind', $autor_ind);
        $stmt->execute();

        echo "<script>alert('indicação enviada com sucesso!'); window.location.href='Home.html';</script>";
		
    } catch (PDOException $e) {
        echo "Erro no envio: " . $e->getMessage();
    }
}
?>
