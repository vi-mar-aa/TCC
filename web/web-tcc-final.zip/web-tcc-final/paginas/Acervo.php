<?php
session_start();

$filtro = isset($_GET['filtro']) ? $_GET['filtro'] : '';

$anoSelecionado = isset($_GET['anos']) && $_GET['anos'] !== ''
    ? array_map('trim', explode(',', $_GET['anos']))
    : [];

$generosSelecionados = isset($_GET['generos']) && $_GET['generos'] !== ''
    ? explode(',', $_GET['generos'])
    : [];

// Dados da conexão
$serverName ="LAB21T-Prof\SQLEXPRESS";
$database = "Littera";
$username = "sa";
$password = "etesp";

try {
    $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($filtro != "") {
        // Se houver filtro, usa stored procedure
        $stmt = $conn->prepare("EXEC sp_AcervoBuscar :filtro");
        $stmt->bindParam(':filtro', $filtro);
    } else {
        // Monta SQL dinâmico seguro
        $sql = "SELECT id_midia, titulo, autor, imagem FROM Midia WHERE id_tpmidia IN (1, 3, 4)";
$params = [];
    if (in_array('Anterior', $anoSelecionado) || in_array('outros', $generosSelecionados)) {
        // Nenhum filtro adicional se 'Anterior' ou 'outros' estiver selecionado
    } else {

        // ✅ Caso o usuário selecione ANO e GÊNERO ao mesmo tempo
        if (!empty($anoSelecionado) && !empty($generosSelecionados)) {
            $placeholdersAno = implode(',', array_fill(0, count($anoSelecionado), '?'));
            $placeholdersGenero = implode(',', array_fill(0, count($generosSelecionados), '?'));
            $sql .= " AND ano_publicacao IN ($placeholdersAno) OR genero IN ($placeholdersGenero)";
            $params = array_merge($params, $anoSelecionado, $generosSelecionados);
        }

        // ✅ Caso selecione apenas ANO
        elseif (!empty($anoSelecionado)) {
            $placeholders = implode(',', array_fill(0, count($anoSelecionado), '?'));
            $sql .= " AND ano_publicacao IN ($placeholders)";
            $params = array_merge($params, $anoSelecionado);
        }

        // ✅ Caso selecione apenas GÊNERO
        elseif (!empty($generosSelecionados)) {
            $placeholders = implode(',', array_fill(0, count($generosSelecionados), '?'));
            $sql .= " AND genero IN ($placeholders)";
            $params = array_merge($params, $generosSelecionados);
        }
    }

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
}
        if (!empty($anoSelecionado)) {
            // Executa bind dos valores
            $stmt->execute($anoSelecionado);
        } else if (!empty($generosSelecionados)) {
            // Executa bind dos valores
            $stmt->execute($generosSelecionados);
        } else {
            $stmt->execute();
        }	
	
    $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo "Erro na conexão ou execução: " . $e->getMessage();
}
?>



<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Acervo - Littera</title>
    <link rel="stylesheet" href="../CSS/acervo.css">
    <link rel="stylesheet" href="../CSS/button.css">
    <script type="text/javascript" src="../paginas/js/abreAbas.js" defer></script>
    <script src="../paginas/js/modoEscuroGeral.js" defer></script>
</head>
<style>
    footer {
        width: 100%;
        height: auto;
        display: flex;
        margin-top: 10vw;
        align-items: center;
        justify-content: center;
        flex-direction: row;
        background: linear-gradient(to left, #d7c9fdd0, #6f59ac);

    }

    #footerLogo img,
    #footerLumen img {
        width: 70%;
        height: 100%;
        object-fit: contain;
    }

    #footerLumen img {
        width: 53%;
    }

    #footerTexto {
        width: 30%;
        justify-content: center;
        text-align: center;
        font-size: 2vw;
        font-family: "Roboto", sans-serif;
        color: #573280;
        width: 60%;
        display: flex;
        align-items: center;
    }

    #footerLumen,
    #footerLogo {
        width: 21%;
        display: flex;
        flex-direction: column;
        font-size: 22px;
        color: #573280;
        font-family: "Roboto", sans-serif;
        align-items: center;
        padding: 1%;
    }

    footer {
        margin-top: 0%;
        background: linear-gradient(to bottom, white, #A293CD);
    }

    #footerLogo img {
        width: 90%;
    }

    #footerLumen {
        font-size: 9px;
    }

    .button {
        color: #573280;
        border-color: #573280;
        background: #FEFEFF;
        background: linear-gradient(0deg, rgba(254, 254, 255, 0.5) 17%, rgba(155, 140, 219, 0.2) 100%);
        width: 30%;
        height: 10%;
    }

    .button .separator {
        background-color: #573280;

    }

    .textContent {
        font-size: 0.5em;
    }
</style>

<body>

    <div class="container">
        <aside class="sidebar">
            <div class="logo">
                <a href="Index.html"><img src="../paginas/imagens/logoLittera.png" alt=""></a>
            </div>
            <div class="fltro-grupo">
                <div class="fltro-titulo">Gênero Textual</div>
                <div class="fltro-opcoes">
                   <label><input type="checkbox" name="generoLivro[]" value="Artigo" <?= in_array('Artigo', $generosSelecionados) ? 'checked' : '' ?>> Artigos</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Revista" <?= in_array('Revista', $generosSelecionados) ? 'checked' : '' ?>> Revistas</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Didático" <?= in_array('Didático', $generosSelecionados) ? 'checked' : '' ?>> Didáticos</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Poesia" <?= in_array('Poesia', $generosSelecionados) ? 'checked' : '' ?>> Poesia</label>
                   <label><input type="checkbox" name="generoLivro[]" value="Romance" <?= in_array('Romance', $generosSelecionados) ? 'checked' : '' ?>> Romance</label>
                   <label><input type="checkbox" name="generoLivro[]" value="Novela" <?= in_array('Novela', $generosSelecionados) ? 'checked' : '' ?>> Novela</label>
                   <label><input type="checkbox" name="generoLivro[]" value="Conto" <?= in_array('Conto', $generosSelecionados) ? 'checked' : '' ?>> Conto</label>
                   <label><input type="checkbox" name="generoLivro[]" value="Fábula" <?= in_array('Fábula', $generosSelecionados) ? 'checked' : '' ?>> Fábula</label>
                   <label><input type="checkbox" name="generoLivro[]" value="Fantasia" <?= in_array('Fantasia', $generosSelecionados) ? 'checked' : '' ?>> Fantasia</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Ficção Científica" <?= in_array('Ficção Científica', $generosSelecionados) ? 'checked' : '' ?>> Ficção científica</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Distopia" <?= in_array('Distopia', $generosSelecionados) ? 'checked' : '' ?>> Distopia</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Utopia" <?= in_array('Utopia', $generosSelecionados) ? 'checked' : '' ?>> Utopia</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Terror" <?= in_array('Terror', $generosSelecionados) ? 'checked' : '' ?>> Terror</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Suspense" <?= in_array('Suspense', $generosSelecionados) ? 'checked' : '' ?>> Suspense</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Biografia" <?= in_array('Biografia', $generosSelecionados) ? 'checked' : '' ?>> Biografia</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Policial" <?= in_array('Policial', $generosSelecionados) ? 'checked' : '' ?>> Policial</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Periodico" <?= in_array('Periodico', $generosSelecionados) ? 'checked' : '' ?>> Periódico</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Aventura" <?= in_array('Aventura', $generosSelecionados) ? 'checked' : '' ?>> Aventura</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Diario" <?= in_array('Diario', $generosSelecionados) ? 'checked' : '' ?>> Diário</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Ensaio" <?= in_array('Ensaio', $generosSelecionados) ? 'checked' : '' ?>> Ensaio</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Crônica" <?= in_array('Crônica', $generosSelecionados) ? 'checked' : '' ?>> Crônica</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Ciência" <?= in_array('Ciência', $generosSelecionados) ? 'checked' : '' ?>> Ciência</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Drama" <?= in_array('Drama', $generosSelecionados) ? 'checked' : '' ?>> Drama</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Comédia" <?= in_array('Comédia', $generosSelecionados) ? 'checked' : '' ?>> Comédia</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Manuais" <?= in_array('Manuais', $generosSelecionados) ? 'checked' : '' ?>> Manuais</label>
				   <label><input type="checkbox" name="generoLivro[]" value="Crônicas" <?= in_array('Crônicas', $generosSelecionados) ? 'checked' : '' ?>> Crônicas</label>
				   <label><input type="checkbox" name="generoLivro[]" value="outros" <?= in_array('outros', $generosSelecionados) ? 'checked' : '' ?>> Outros</label>

                </div>
            </div>
            <div class="fltro-grupo">
                <div class="fltro-titulo">Ano</div>
                <div class="fltro-opcoes" onClick="chkAno();">
                    <label><input type="checkbox" name="ano[]" value="2025" <?= in_array('2025', $anoSelecionado) ? 'checked' : '' ?>> 2025</label>
					<label><input type="checkbox" name="ano[]" value="2024" <?= in_array('2024', $anoSelecionado) ? 'checked' : '' ?>> 2024</label>
					<label><input type="checkbox" name="ano[]" value="2023" <?= in_array('2023', $anoSelecionado) ? 'checked' : '' ?>> 2023</label>
					<label><input type="checkbox" name="ano[]" value="2022" <?= in_array('2022', $anoSelecionado) ? 'checked' : '' ?>> 2022</label>
					<label><input type="checkbox" name="ano[]" value="2021" <?= in_array('2021', $anoSelecionado) ? 'checked' : '' ?>> 2021</label>
					<label><input type="checkbox" name="ano[]" value="2020" <?= in_array('2020', $anoSelecionado) ? 'checked' : '' ?>> 2020</label>
					<label><input type="checkbox" name="ano[]" value="Anterior" <?= in_array('Anterior', $anoSelecionado) ? 'checked' : '' ?>> Anterior</label>

                </div>
            </div>
        </aside>
        <main class="conteudo-principal">
            <img src="../paginas/imagens/logoLittera.png" alt="" class="logomobile">
            <div class="barra-pesquisa-container" style="display: flex;">
			
			
                <input class="barra-pesquisa" type="text" name="pesquisa" id="pesquisa"  placeholder="Pesquisar..."/>
                <span onClick="minhafunc();" class="icon-pesquisa"  style="cursor:pointer;">
				<svg xmlns="http://www.w3.org/2000/svg" width="28" height="30"viewBox="0 0 33 32" fill="none">
                        <path
                            d="M14.8446 24.408C12.9072 24.408 11.0133 23.8335 9.40238 22.7571C7.79147 21.6808 6.53592 20.1509 5.79449 18.3609C5.05307 16.571 4.85908 14.6014 5.23706 12.7012C5.61503 10.801 6.54799 9.0555 7.91796 7.68554C9.28793 6.31557 11.0334 5.38261 12.9336 5.00463C14.8338 4.62666 16.8034 4.82065 18.5933 5.56207C20.3833 6.30349 21.9132 7.55905 22.9896 9.16996C24.0659 10.7809 24.6404 12.6748 24.6404 14.6122C24.6404 15.8986 24.3871 17.1724 23.8948 18.3609C23.4025 19.5494 22.6809 20.6293 21.7713 21.5389C20.8617 22.4485 19.7818 23.1701 18.5933 23.6624C17.4049 24.1546 16.131 24.408 14.8446 24.408ZM14.8446 6.78078C13.3009 6.78078 11.7918 7.23856 10.5082 8.09623C9.22458 8.9539 8.22414 10.1729 7.63337 11.5992C7.04259 13.0254 6.88802 14.5949 7.18919 16.109C7.49037 17.6231 8.23376 19.0139 9.32537 20.1055C10.417 21.1971 11.8078 21.9405 13.3219 22.2416C14.836 22.5428 16.4054 22.3882 17.8316 21.7975C19.2579 21.2067 20.4769 20.2063 21.3346 18.9227C22.1923 17.6391 22.6501 16.13 22.6501 14.5862C22.6501 12.5161 21.8277 10.5307 20.3639 9.06693C18.9001 7.60313 16.9148 6.78078 14.8446 6.78078Z"
                            fill="#573280" />
                        <path
                            d="M26.8524 27.5957C26.7242 27.5963 26.5972 27.5713 26.4788 27.5221C26.3604 27.473 26.253 27.4007 26.1629 27.3095L20.7902 21.9367C20.6178 21.7518 20.524 21.5071 20.5285 21.2544C20.5329 21.0016 20.6353 20.7604 20.8141 20.5817C20.9929 20.4029 21.234 20.3005 21.4868 20.2961C21.7396 20.2916 21.9842 20.3854 22.1691 20.5578L27.5419 25.9305C27.7246 26.1134 27.8272 26.3614 27.8272 26.62C27.8272 26.8785 27.7246 27.1265 27.5419 27.3095C27.4518 27.4007 27.3444 27.473 27.226 27.5221C27.1076 27.5713 26.9806 27.5963 26.8524 27.5957Z"
                            fill="#573280" />
                    </svg></span>
            </div>
            <div class="tabs">
                <div class="tab active" onclick="clicarLivro()" id="tabLivro0">Livros</div>
                <div class="tab" onclick="clicarAudio()" id="tabAudio0">Audiovisual</div>

            </div>
            <div id="sumario"
                style="height: auto; background: radial-gradient(rgba(228, 219, 255, 1) 1%,rgba(183, 163, 250,0.5) 49%,rgba(94, 84, 142,0.95) 93%,rgba(72, 57, 125,0.91) 100%); background-size: 250% 250%; background-position: 220% 230%;">
                <div style=" background: linear-gradient(130deg, rgba(228, 219, 255, 1) 0%, rgba(184, 164, 249, 0.5) 70%, rgba(94, 84, 142, 0.95) 115%);
                             display: flex; width:100%;  align-items: center; border-radius: 10px 10px 0px 0px; " onclick="sum()" class="conteudo">
                    <p>
                        Gênero Textual
                    </p>
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 48 48" style="margin-left: 49%; margin-right:10px; " id="icon_seta2_acervo">
                        <g fill="none" stroke="#573280" stroke-linecap="round" stroke-width="4">
                            <path stroke-linejoin="round" d="M40 28L24 40L8 28" />
                            <path d="M8 10H40" />
                            <path d="M8 18H40" />
                        </g>
                    </svg>
                </div>


                <div class="div_Checkboxs"
                    style="background-size: 250% 250%; background-position: 220% 230%; display: flex;">
                    <div id="div_chk1">
					<label id="top" style="visibility: visible;"><input id="chk0" type="checkbox" name="generoLivro[]" value="Artigo" <?= in_array('Artigo', $generosSelecionados) ? 'checked' : '' ?>> Artigos</label>
					<label id="top2" style="visibility: visible;"><input id="chk1" type="checkbox" name="generoLivro[]" value="Revista" <?= in_array('Revista', $generosSelecionados) ? 'checked' : '' ?>> Revistas</label>
					<label id="top3" style="visibility: visible;"><input id="chk2" type="checkbox" name="generoLivro[]" value="Didático" <?= in_array('Didático', $generosSelecionados) ? 'checked' : '' ?>> Didáticos</label>
					<label id="top4" style="visibility: visible;"><input id="chk3" type="checkbox" name="generoLivro[]" value="Poesia" <?= in_array('Poesia', $generosSelecionados) ? 'checked' : '' ?>> Poesia</label>
					<label id="top5" style="visibility: visible;"><input id="chk4" type="checkbox" name="generoLivro[]" value="Romance" <?= in_array('Romance', $generosSelecionados) ? 'checked' : '' ?>> Romance</label>
					<label id="top6" style="visibility: visible;"><input id="chk5" type="checkbox" name="generoLivro[]" value="Novela" <?= in_array('Novela', $generosSelecionados) ? 'checked' : '' ?>> Novela</label>
					<label id="top7" style="visibility: visible;"><input id="chk6" type="checkbox" name="generoLivro[]" value="Conto" <?= in_array('Conto', $generosSelecionados) ? 'checked' : '' ?>> Conto</label>
					<label id="top8" style="visibility: visible;"><input id="chk7" type="checkbox" name="generoLivro[]" value="Fábula" <?= in_array('Fábula', $generosSelecionados) ? 'checked' : '' ?>> Fábula</label>
					<label id="top9" style="visibility: visible;"><input id="chk8" type="checkbox" name="generoLivro[]" value="Fantasia" <?= in_array('Fantasia', $generosSelecionados) ? 'checked' : '' ?>> Fantasia</label>
					<label id="top10" style="visibility: visible;"><input id="chk9" type="checkbox" name="generoLivro[]" value="Ficção científica" <?= in_array('Ficção científica', $generosSelecionados) ? 'checked' : '' ?>> Ficção científica</label>
					<label id="top11" style="visibility: visible;"><input id="chk10" type="checkbox" name="generoLivro[]" value="Ensaio" <?= in_array('Ensaio', $generosSelecionados) ? 'checked' : '' ?>> Ensaio</label>
					<label id="top12" style="visibility: visible;"><input id="chk11" type="checkbox" name="generoLivro[]" value="Artigo" <?= in_array('Artigo', $generosSelecionados) ? 'checked' : '' ?>> Artigo</label>
					<label id="top13" style="visibility: visible;"><input id="chk12" type="checkbox" name="generoLivro[]" value="Crônica" <?= in_array('Crônica', $generosSelecionados) ? 'checked' : '' ?>> Crônica</label>
					<label id="top14" style="visibility: visible;"><input id="chk13" type="checkbox" name="generoLivro[]" value="Revista" <?= in_array('Revista', $generosSelecionados) ? 'checked' : '' ?>> Revista</label>
					<label id="top15" style="visibility: visible;"><input id="chk14" type="checkbox" name="generoLivro[]" value="Ciência" <?= in_array('Ciência', $generosSelecionados) ? 'checked' : '' ?>> Ciência</label>
                    </div>
                    <div id="div_chk2">
                    <label id="top16" style="visibility: visible;"><input id="chk15" type="checkbox" name="generoLivro[]" value="Drama" <?= in_array('Drama', $generosSelecionados) ? 'checked' : '' ?>> Drama</label>
					<label id="top17" style="visibility: visible;"><input id="chk16" type="checkbox" name="generoLivro[]" value="Comédia" <?= in_array('Comédia', $generosSelecionados) ? 'checked' : '' ?>> Comédia</label>
					<label id="top18" style="visibility: visible;"><input id="chk17" type="checkbox" name="generoLivro[]" value="Manuais" <?= in_array('Manuais', $generosSelecionados) ? 'checked' : '' ?>> Manuais</label>
					<label id="top19" style="visibility: visible;"><input id="chk18" type="checkbox" name="generoLivro[]" value="Crônica" <?= in_array('Crônica', $generosSelecionados) ? 'checked' : '' ?>> Crônicas</label>
					<label id="top20" style="visibility: visible;"><input id="chk19" type="checkbox" name="generoLivro[]" value="Distopia" <?= in_array('Distopia', $generosSelecionados) ? 'checked' : '' ?>> Distopia</label>
					<label id="top21" style="visibility: visible;"><input id="chk20" type="checkbox" name="generoLivro[]" value="Utopia" <?= in_array('Utopia', $generosSelecionados) ? 'checked' : '' ?>> Utopia</label>
					<label id="top22" style="visibility: visible;"><input id="chk21" type="checkbox" name="generoLivro[]" value="Terror" <?= in_array('Terror', $generosSelecionados) ? 'checked' : '' ?>> Terror</label>
					<label id="top23" style="visibility: visible;"><input id="chk22" type="checkbox" name="generoLivro[]" value="Suspense" <?= in_array('Suspense', $generosSelecionados) ? 'checked' : '' ?>> Suspense</label>
					<label id="top24" style="visibility: visible;"><input id="chk23" type="checkbox" name="generoLivro[]" value="Biografia" <?= in_array('Biografia', $generosSelecionados) ? 'checked' : '' ?>> Biografia</label>
					<label id="top25" style="visibility: visible;"><input id="chk24" type="checkbox" name="generoLivro[]" value="Policial" <?= in_array('Policial', $generosSelecionados) ? 'checked' : '' ?>> Policial</label>
					<label id="top26" style="visibility: visible;"><input id="chk25" type="checkbox" name="generoLivro[]" value="Periódico" <?= in_array('Periódico', $generosSelecionados) ? 'checked' : '' ?>> Periódico</label>
					<label id="top27" style="visibility: visible;"><input id="chk26" type="checkbox" name="generoLivro[]" value="Aventura" <?= in_array('Aventura', $generosSelecionados) ? 'checked' : '' ?>> Aventura</label>
					<label id="top28" style="visibility: visible;"><input id="chk27" type="checkbox" name="generoLivro[]" value="Diário" <?= in_array('Diário', $generosSelecionados) ? 'checked' : '' ?>> Diário</label>
					<label id="top29" style="visibility: visible;"><input id="chk28" type="checkbox" name="generoLivro[]" value="outros" <?= in_array('outros', $generosSelecionados) ? 'checked' : '' ?>> Outros</label>
                    </div>
                </div>
            </div>
            <div id="sumario2"
                style="height: auto; background: radial-gradient(rgba(228, 219, 255, 1) 1%,rgba(183, 163, 250,0.5) 49%,rgba(94, 84, 142,0.95) 93%,rgba(72, 57, 125,0.91) 100%); background-size: 250% 250%; background-position: 220% 230%;">

                <div style="background: #E4DBFF;
background: linear-gradient(130deg, rgba(228, 219, 255, 1) 0%, rgba(184, 164, 249, 0.5) 70%, rgba(94, 84, 142, 0.95) 115%); display: flex; width:100%;  align-items: center; border-radius: 10px 10px 0px 0px;" onclick="sum2()">
                    <p>
                        Ano
                    </p>
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 48 48" style="margin-left: 77%; " id="icon_seta_acervo">
                        <g fill="none" stroke="#573280" stroke-linecap="round" stroke-width="4">
                            <path stroke-linejoin="round" d="M40 28L24 40L8 28" />
                            <path d="M8 10H40" />
                            <path d="M8 18H40" />
                        </g>
                    </svg>
                </div>


                <div class="div_Checkboxs1" style="display: flex;">
                    <div id="div1_chk1">
                    <label id="topp" style="visibility: visible;"><input id="1chk1" type="checkbox" name="ano[]" value="2025" <?= in_array('2025', $anoSelecionado) ? 'checked' : '' ?>>2025</label>
                    <label id="topp2" style="visibility: visible;"><input id="1chk2" type="checkbox" name="ano[]" value="2024" <?= in_array('2024', $anoSelecionado) ? 'checked' : '' ?>>2024</label>
                    <label id="topp3" style="visibility: visible;"><input id="1chk3" type="checkbox" name="ano[]" value="2023" <?= in_array('2023', $anoSelecionado) ? 'checked' : '' ?>>2023</label>
                    <label id="topp4" style="visibility: visible;"><input id="1chk4" type="checkbox" name="ano[]" value="2022" <?= in_array('2022', $anoSelecionado) ? 'checked' : '' ?>>2022</label>
                    <label id="topp5" style="visibility: visible;"><input id="1chk5" type="checkbox" name="ano[]" value="2021" <?= in_array('2021', $anoSelecionado) ? 'checked' : '' ?>>2021</label>
                </div>
                <div id="div1_chk2">
                    <label id="topp6" style="visibility: visible;"><input id="1chk6" type="checkbox" name="ano[]" value="2020" <?= in_array('2020', $anoSelecionado) ? 'checked' : '' ?>>2020</label>
                    <label id="topp7" style="visibility: visible;"><input id="1chk7" type="checkbox" name="ano[]" value="2019" <?= in_array('2019', $anoSelecionado) ? 'checked' : '' ?>>2019</label>
                    <label id="topp8" style="visibility: visible;"><input id="1chk8" type="checkbox" name="ano[]" value="2018" <?= in_array('2018', $anoSelecionado) ? 'checked' : '' ?>>2018</label>
                    <label id="topp9" style="visibility: visible;"><input id="1chk9" type="checkbox" name="ano[]" value="Anterior" <?= in_array('Anterior', $anoSelecionado) ? 'checked' : '' ?>>Anterior</label>
                </div>
            </div>
    </div>

    <div class="acervo-content" style="background: rgb(240, 236, 255);">
        <div class="coluna-cards">

            <?php foreach ($produtos as $produto): ?>
                <div class="acervo-card" alt="" style="border: #573280 solid 2px; text-align:center; overflow: hidden;">
                    <!--<?php echo '<img src="' . 'exibirImagem.php?id=' . '' . $produto['id_midia'] . '' . '"alt="" style="width: 100%; display: block;>' ?>-->
                    <!-- <?php echo '<img src="exibirImagem.php?id=' . $produto['id_midia'] . '"alt="">'; ?> -->	
                    <?php echo '<img src="exibirImagem.php?id=' . $produto['id_midia'] . '"alt="">'; ?>


                    <div id="infoMidia" class="infoMidia" style=" background-color: #F0ECFF; padding: 20px 16px; width: 100%; display: flex; flex-direction: column; flex-grow: 1; justify-content: space-between;">
                        <div class="titulo"><?php echo $produto['titulo']; ?></div>
                        <div class="autor"><?php echo $produto['autor']; ?></div>
                        <div class="info-link"><?php echo '<a href="' . 'Info' . '.php?id=' . '' . $produto['id_midia'] . '' . '">' . '+Informações' . ' </a>'; ?></div>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        
    </div>

    </main>
    </div>

<script defer>
document.addEventListener("DOMContentLoaded", () => {
    // Sincroniza checkboxes com mesmo value e atualiza o filtro
    const allBoxes = Array.from(document.querySelectorAll('input[name="ano[]"], input[name="generoLivro[]"]'));

    function syncAndUpdate(e) {
        const el = e.target;
        // Sincroniza checkboxes com mesmo name e value
        if (el.name === 'generoLivro[]') {
            document.querySelectorAll('input[name="generoLivro[]"]').forEach(other => {
                if (other !== el && other.value === el.value) other.checked = el.checked;
            });
        } else if (el.name === 'ano[]') {
            document.querySelectorAll('input[name="ano[]"]').forEach(other => {
                if (other !== el && other.value === el.value) other.checked = el.checked;
            });
        }

        // Depois de sincronizar, atualiza a URL
        atualizarFiltro();
    }

    allBoxes.forEach(chk => chk.addEventListener('change', syncAndUpdate));

    function atualizarFiltro() {
        // Coleta os anos selecionados (trim e deduplica)
        const anosSelecionados = Array.from(document.querySelectorAll('input[name="ano[]"]:checked'))
            .map(chk => String(chk.value).trim())
            .filter(Boolean);
        const anosUnicos = [...new Set(anosSelecionados)];

        // Coleta os gêneros selecionados (trim e deduplica)
        const generosSelecionados = Array.from(document.querySelectorAll('input[name="generoLivro[]"]:checked'))
            .map(chk => String(chk.value).trim())
            .filter(Boolean);
        const generosUnicos = [...new Set(generosSelecionados)];

        // Campo de pesquisa (opcional)
        const filtro = document.getElementById('pesquisa')?.value?.trim() || '';

        // Monta a URL usando URLSearchParams e só inclui parâmetros com valor
        const params = new URLSearchParams();
        if (filtro) params.set('filtro', filtro);
        if (anosUnicos.length) params.set('anos', anosUnicos.join(','));
        if (generosUnicos.length) params.set('generos', generosUnicos.join(','));

        const url = 'Acervo.php' + (params.toString() ? '?' + params.toString() : '');

        // Atualiza imediatamente
        window.location.href = url;
    }
});
</script>



    <script>
	
	
	
	
	       function minhafunc() {
    const x = document.getElementById('pesquisa').value;
    window.location.href = 'Acervo.php?filtro=' + encodeURIComponent(x);
}
	

        var sumarioVisivel = false;

        function sum() {
            document.getElementById("icon_seta2_acervo").style.rotate = "0deg";

            if (sumarioVisivel === false) {
                // Mostrar elementos
                document.getElementById("icon_seta2_acervo").style.rotate = "-180deg";
                for (var i = 1; i <= 29; i++) {
                    var label;
                    if (i === 1) {
                        label = document.getElementById('top');
                    } else {
                        label = document.getElementById('top' + i);
                    }
                    var input = document.getElementById('chk' + (i - 1));
                    if (label) {
                        label.style.display = "flex";
                        label.style.fontSize = "2.8vw";
                    }
                    if (input) {
                        input.style.display = "block";
                        input.style.width = "35px";
                        input.style.height = "35px";
                        input.style.outline = "1px solid #000";
                        input.style.borderRadius = "3px";
                        input.style.background = "#fff";
                        input.style.margin = "auto 10px";
                        input.style.marginBottom = "20px";
                    }
                }
                var divChk1 = document.getElementById('div_chk1');
                var divChk2 = document.getElementById('div_chk2');
                if (divChk1 && divChk2) {
                    divChk1.style.margin = "15px 15px";
                    divChk2.style.margin = "15px 15px";


                }
                sumarioVisivel = true;
            } else {
                // Esconder elementos
                for (var i = 1; i <= 29; i++) {
                    var label;
                    if (i === 1) {
                        label = document.getElementById('top');
                    } else {
                        label = document.getElementById('top' + i);
                    }
                    var input = document.getElementById('chk' + (i - 1));
                    if (label) {
                        label.style.display = "none";
                    }
                    if (input) {
                        input.style.display = "none";
                    }
                }
                var divChk1 = document.getElementById('div_chk1');
                var divChk2 = document.getElementById('div_chk2');
                if (divChk1 && divChk2) {
                    divChk1.style.margin = "";
                    divChk2.style.margin = "";
                }
                sumarioVisivel = false;
            }
        }

        var sumario2Visivel = false;

        function sum2() {
            document.getElementById("icon_seta_acervo").style.rotate = "0deg";
            if (sumario2Visivel === false) {
                document.getElementById("icon_seta_acervo").style.rotate = "-180deg";
                for (var i = 1; i <= 29; i++) {
                    var label;
                    if (i === 1) {
                        label = document.getElementById('topp');
                    } else {
                        label = document.getElementById('topp' + i);
                    }
                    if (label) {
                        label.style.display = "flex";
                        label.style.fontSize = "2.8vw";
                        var input = label.querySelector('input[type="checkbox"]');
                        if (input) {
                            input.style.display = "block";
                            input.style.width = "35px";
                            input.style.height = "35px";
                            input.style.outline = "1px solid #000";
                            input.style.borderRadius = "3px";
                            input.style.background = "#fff";
                            input.style.margin = "auto 10px";
                            input.style.marginBottom = "20px";
                        }
                    }
                }
                var divChk1 = document.getElementById('div1_chk1');
                var divChk2 = document.getElementById('div1_chk2');
                if (divChk1 && divChk2) {
                    divChk1.style.margin = "15px 15px";
                    divChk2.style.margin = "15px 75px";
                }
                sumario2Visivel = true;
            } else {
                for (var i = 1; i <= 29; i++) {
                    var label;
                    if (i === 1) {
                        label = document.getElementById('topp');
                    } else {
                        label = document.getElementById('topp' + i);
                    }
                    if (label) {
                        label.style.display = "none";
                        var input = label.querySelector('input[type="checkbox"]');
                        if (input) {
                            input.style.display = "none";
                        }
                    }
                }
                var divChk1 = document.getElementById('div1_chk1');
                var divChk2 = document.getElementById('div1_chk2');
                if (divChk1 && divChk2) {
                    divChk1.style.margin = "";
                    divChk2.style.margin = "";
                }
                sumario2Visivel = false;
            }
        }
    </script>

</body>

</html>