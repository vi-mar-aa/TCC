
var body = document.querySelector("body")
window.addEventListener("DOMContentLoaded", () => {
	const body = document.body;
	const modo = localStorage.getItem("modo"); // lê o modo salvo
	if (modo === "escuro") {
		body.classList.add("modoEscuro");
		aplicarModoEscuro();
	} else {
		body.classList.remove("modoEscuro");
		aplicarModoClaro();
	}


});
window.addEventListener('resize', function () {
	// Só ativa se for menor que 800px
	if (window.innerWidth < 600) {
		if (document.body.classList.contains("modoEscuro")) {
			aplicarModoEscuro();
		} else {
			aplicarModoClaro();
		}
	} else {
		return;
	}
});


// Função para alternar entre modos
function mudarModo() {
	const body = document.body;
	const modoAtual = body.classList.contains("modoEscuro") ? "escuro" : "claro";
	if (modoAtual === "escuro") {
		body.classList.remove("modoEscuro");
		localStorage.setItem("modo", "claro");
		aplicarModoClaro();
	} else {
		body.classList.add("modoEscuro");
		localStorage.setItem("modo", "escuro");
		aplicarModoEscuro();
	}
}

// Aplica o modo claro dependendo da página
function aplicarModoClaro() {
	const path = window.location.pathname.toLowerCase();

	if (path.includes("acervo.php") || path.includes("acervoaudio.php")) {
		acervoModoClaro();
	} else if (path.includes("index.html") || path.endsWith("/paginas/")) {
		indexModoClaro();
	} else if (path.includes("cadastro.html")) {
		cadastroModoClaro();
	} else if (path.includes("login.html")) {
		loginModoClaro();
	} else if (path.includes("erroforum.html")) {
		erroforumModoClaro();
	} else if (path.includes("home.html")) {
		homeModoClaro();
	} else if (path.includes("recsenha.html")) {
		loginModoClaro();
	} else if (path.includes("recsenhaa.html")) {
		recSenhaaModoClaro();
	} else if (path.includes("editperfil.php")) {
		editPerfilModoClaro();
	} else if (path.includes("forum.php")) {
		forumModoClaro();
	} else if (path.includes("eventos.php")){
		eventosModoClaro();
	}else if (path.includes("comment.php")){
		commentModoClaro()
	}
}

// Aplica o modo escuro dependendo da página
function aplicarModoEscuro() {
	const path = window.location.pathname.toLowerCase();

	if (path.includes("acervo.php") || path.includes("acervoaudio.php")) {
		acervoModoEscuro();
	} else if (path.includes("index.html") || path.endsWith("/paginas/")) {
		indexModoEscuro();
	} else if (path.includes("cadastro.html")) {
		cadastroModoEscuro();
	} else if (path.includes("login.html")) {
		loginModoEscuro();
	} else if (path.includes("erroforum.html")) {
		erroforumModoEscuro();
	} else if (path.includes("home.html")) {
		homeModoEscuro();
	} else if (path.includes("recsenha.html")) {
		loginModoEscuro();
	} else if (path.includes("recsenhaa.html")) {
		recSenhaaModoEscuro();
	} else if (path.includes("editperfil.php")) {
		editPerfilModoEscuro();
	} else if (path.includes("forum.php")) {
		forumModoEscuro();
	} else if (path.includes("eventos.php")) {
		eventosModoEscuro();
	}else if (path.includes("comment.php")){
		commentModoEscuro()
	}
}

//===================================================================================
//funções para mudança grafica de paginas especificas (ordenado por ordem alfabetica)
//===================================================================================
//a
function acervoModoClaro() {
	var logo1 = document.querySelectorAll("img")[0];
	var inputPesquisa = document.querySelector(".barra-pesquisa");
	var icons = document.querySelectorAll("path");
	// usar pathname em lowercase como no modo escuro
	var pathname = window.location.pathname.toLowerCase();
	if (pathname.includes("acervo.php")) {
		var tabAtiva = document.querySelectorAll(".tab")[0];
		var tabInativa = document.querySelectorAll(".tab")[1];
	} else {
		var tabAtiva = document.querySelectorAll(".tab")[1];
		var tabInativa = document.querySelectorAll(".tab")[0];
	}
	var acervoCards = document.querySelectorAll(".acervo-card");
	var acervoContent = document.querySelector(".acervo-content");
	var filtroTitulo = document.querySelectorAll(".fltro-titulo");
	var filtroOpcoes = document.querySelectorAll(".fltro-opcoes");
	var infoMidias = document.querySelectorAll(".infoMidia");
	var labels = document.querySelectorAll(".fltro-opcoes label");
	const sumario1 = document.getElementById('sumario') || document.querySelector('.sumario');
	const sumario2 = document.getElementById('sumario2') || document.querySelector('.sumario2');
	const divCheckboxs = document.querySelectorAll('.div_Checkboxs, .div_Checkboxs1');

	body.classList.remove("modoEscuro");
	body.style.backgroundColor = "#ffff";
	body.style.color = "#000"
	// logo1.setAttribute("src", "imagens/logoLittera.png");
	inputPesquisa.style.background = "linear-gradient(0deg, rgba(254, 254, 255, 0.5) 17%, rgba(155, 140, 219, 0.2) 100%)"; 
	inputPesquisa.style.color = "#000";
	inputPesquisa.style.border = "1px solid #2F2259";
	acervoContent.style.background = "linear-gradient(0deg, rgba(254, 254, 255, 0.5) 17%, rgba(155, 140, 219, 0.2) 100%)";
	acervoContent.style.color = "#000";
	tabAtiva.style.background = "linear-gradient(to top, rgb(240, 236, 255) 10%, rgb(72, 57, 125) 480%)";
	tabAtiva.style.color = "#2F2259";
	tabInativa.style.color = "#000";
	logo1.setAttribute("src", "imagens/logoLittera.png");
	
acervoCards.forEach(function(card) {
	card.style.background = "#fff";
});
infoMidias.forEach(function(div) {
	div.style.backgroundColor = "#F0ECFF"; // ou qualquer cor desejada
});

	for (var i = 0; i < icons.length; i++) {
		if (i <= 1) {
			icons[i].style.fill = "#000";
		}
	}
	for (var i = 0; i < filtroTitulo.length; i++) {
		filtroTitulo[i].style.background = "linear-gradient(130deg, rgba(228, 219, 255, 1) 0%, rgba(184, 164, 249, 0.5) 70%, rgba(94, 84, 142, 0.95) 115%)";
		filtroTitulo[i].style.color = "#2F2259";
		filtroOpcoes[i].style.background = "#F0ECFF";
		filtroOpcoes[i].style.color = "#000";
	}
	for (var i = 0; i < labels.length; i++) {
		labels[i].style.color = "#000";
	}

	if (sumario1) {
		// aplicar ao container e às suas seções internas
		sumario1.style.background = "linear-gradient(130deg, rgba(228, 219, 255, 1) 0%, rgba(184, 164, 249, 0.5) 70%, rgba(94, 84, 142, 0.95) 115%)";
		for (var i = 0; i < sumario1.querySelectorAll('div').length; i++) {
			if (i < sumario1.querySelectorAll('div').length - 2) {
				sumario1.querySelectorAll('div')[i].style.background = "linear-gradient(130deg, rgba(228, 219, 255, 1) 0%, rgba(184, 164, 249, 0.5) 70%, rgba(94, 84, 142, 0.95) 115%)";
			}
		}
		sumario1.querySelector("p").style.color = "#2F2259";
		for (var i = 0; i < sumario1.querySelectorAll("path").length; i++) {
			sumario1.querySelectorAll("path")[i].style.stroke = "#2f2259";
		}
	}

	if (sumario2) {
		// aplicar ao container e às suas seções internas
		sumario2.style.background = "linear-gradient(130deg, rgba(228, 219, 255, 1) 0%, rgba(184, 164, 249, 0.5) 70%, rgba(94, 84, 142, 0.95) 115%)";
		for (var i = 0; i < sumario2.querySelectorAll('div').length; i++) {
			if (i < sumario2.querySelectorAll('div').length - 2) {
				sumario2.querySelectorAll('div')[i].style.background = "linear-gradient(130deg, rgba(228, 219, 255, 1) 0%, rgba(184, 164, 249, 0.5) 70%, rgba(94, 84, 142, 0.95) 115%)";
			}
		}
		sumario2.querySelector("p").style.color = "#2F2259";
		for (var i = 0; i < sumario2.querySelectorAll("path").length; i++) {
			sumario2.querySelectorAll("path")[i].style.stroke = "#2f2259";
		}
	}

	// aplicar também aos containers que guardam os checkboxes
	divCheckboxs.forEach(function (el) {
		el.querySelectorAll('label').forEach(function (lab) {
			lab.style.color = '#000';
		});
	});

}
function acervoModoEscuro() {

	var logo1 = document.querySelectorAll("img")[0];
	var inputPesquisa = document.querySelector(".barra-pesquisa");
	var icons = document.querySelectorAll("path");
	// usar pathname em lowercase para detectar corretamente Acervo.php vs AcervoAudio.php
	var pathname = window.location.pathname.toLowerCase();
	if (pathname.includes("acervo.php")) {
		var tabAtiva = document.querySelectorAll(".tab")[0];
		var tabInativa = document.querySelectorAll(".tab")[1];
	} else {
		var tabAtiva = document.querySelectorAll(".tab")[1];
		var tabInativa = document.querySelectorAll(".tab")[0];
	}
	var acervoCards = document.querySelectorAll(".acervo-card");
	var acervoContent = document.querySelector(".acervo-content");
	var filtroTitulo = document.querySelectorAll(".fltro-titulo");
	var filtroOpcoes = document.querySelectorAll(".fltro-opcoes");
	var infoMidias = document.querySelectorAll(".infoMidia");
	var labels = document.querySelectorAll(".fltro-opcoes label");
	var logoMobile = document.querySelector(".logomobile");
	// Seletores mais robustos: IDs e classes
	const sumario1 = document.getElementById('sumario') || document.querySelector('.sumario');
	const sumario2 = document.getElementById('sumario2') || document.querySelector('.sumario2');
	const divCheckboxs = document.querySelectorAll('.div_Checkboxs, .div_Checkboxs1');

	body.classList.add("modoEscuro");
	body.style.backgroundColor = "#070512";
	body.style.color = "#f0f8ff"
	logo1.setAttribute("src", "imagens/logoEscWeb.png");
	inputPesquisa.style.background = "#070512";
	inputPesquisa.style.color = "#f0f8ff";
	inputPesquisa.style.border = "1px solid #c9baff";
	acervoContent.style.background = "#12101fff";
	acervoContent.style.color = "#f0f8ff";
	tabAtiva.style.background = "linear-gradient(23deg, rgb(29, 21, 60) 8%, rgb(48, 37, 89) 32%, rgb(72, 57, 125) 59%, rgb(94, 84, 142) 80%, rgb(122, 106, 200) 100%) ";
	tabAtiva.style.color = "#f0f8ff";
	tabInativa.style.color = "#c9baff";
	logoMobile.setAttribute("src", "imagens/logoEscWeb.png")

acervoCards.forEach(function(card) {
	card.style.background = "rgb(18, 16, 31)";
});
infoMidias.forEach(function(div) {
	div.style.backgroundColor = "#1a132f"; // exemplo escuro
});
	for (var i = 0; i < icons.length; i++) {
		if (i <= 1) {
			icons[i].style.fill = "#c9baff";
		}
	}
	for (var i = 0; i < filtroTitulo.length; i++) {
		filtroTitulo[i].style.background = "linear-gradient(23deg, rgb(29, 21, 60) 8%, rgb(48, 37, 89) 32%, rgb(72, 57, 125) 59%, rgb(94, 84, 142) 80%, rgb(122, 106, 200) 100%)";
		filtroTitulo[i].style.color = "#f0f8ff";
		filtroOpcoes[i].style.background = "#12101fff";
		filtroOpcoes[i].style.color = "#f0f8ff";
	}
	for (var i = 0; i < labels.length; i++) {
		labels[i].style.color = "#f0f8ff";
	}


	if (sumario1) {
		// aplicar ao container e às suas seções internas
		sumario1.style.background = 'linear-gradient(23deg, rgb(29, 21, 60) 8%, rgb(48, 37, 89) 32%, rgb(72, 57, 125) 59%, rgb(94, 84, 142) 80%, rgb(122, 106, 200) 100%)';
		for (var i = 0; i < sumario1.querySelectorAll('div').length; i++) {
			if (i < sumario1.querySelectorAll('div').length - 2) {
				sumario1.querySelectorAll('div')[i].style.background = 'linear-gradient(23deg, rgb(29, 21, 60) 8%, rgb(48, 37, 89) 32%, rgb(72, 57, 125) 59%, rgb(94, 84, 142) 80%, rgb(122, 106, 200) 100%)';
			}
		}
		sumario1.querySelector("p").style.color = "#c9baff";
		for (var i = 0; i < sumario1.querySelectorAll("path").length; i++) {
			sumario1.querySelectorAll("path")[i].style.stroke = "#c9baff";
		}
	}

	if (sumario2) {
		// aplicar ao container e às suas seções internas
		sumario2.style.background = 'linear-gradient(23deg, rgb(29, 21, 60) 8%, rgb(48, 37, 89) 32%, rgb(72, 57, 125) 59%, rgb(94, 84, 142) 80%, rgb(122, 106, 200) 100%)';
		for (var i = 0; i < sumario2.querySelectorAll('div').length; i++) {
			if (i < sumario2.querySelectorAll('div').length - 2) {
				sumario2.querySelectorAll('div')[i].style.background = 'linear-gradient(23deg, rgb(29, 21, 60) 8%, rgb(48, 37, 89) 32%, rgb(72, 57, 125) 59%, rgb(94, 84, 142) 80%, rgb(122, 106, 200) 100%)';
			}
		}
		sumario2.querySelector("p").style.color = "#c9baff";
		for (var i = 0; i < sumario2.querySelectorAll("path").length; i++) {
			sumario2.querySelectorAll("path")[i].style.stroke = "#c9baff";
		}
	}

	// aplicar também aos containers que guardam os checkboxes
	divCheckboxs.forEach(function (el) {
		el.querySelectorAll('label').forEach(function (lab) {
			lab.style.color = '#f0f8ff';
		});
	});


}
//c
function cadastroModoClaro() {
	var logo1 = document.querySelectorAll("img")[0];
	var labels = document.querySelectorAll("label");
	var divMensagem = document.getElementById("mensagem");
	var h1 = document.querySelectorAll("h1");
	var p = document.querySelectorAll("p");
	var inputs = document.querySelectorAll("input");
	var botaoCad = document.getElementById("botaoCad");
	var info = document.getElementById("informacoes");

	logo1.setAttribute("src", "imagens/logoLittera.png");
	body.classList.remove("modoEscuro");
	body.style.backgroundColor = "#ffff";
	body.style.color = "#000";
	divMensagem.style.background = "linear-gradient(to bottom,  rgb(240, 236, 255) 0%, rgb(194, 186, 255) 100%)";
	botaoCad.style.background = "linear-gradient(to top, #ffffff, #ebe7ff)";
	botaoCad.style.border = "1px solid #2F2259";
	botaoCad.style.color = "#2F2259";
	info.style.background = "#ffff"
	if (window.innerWidth < 600) {
		info.style.borderRadius = "0px"
	}
	for (var i = 0; i < labels.length; i++) {
		labels[i].style.color = "#000";
	}
	for (var i = 0; i < h1.length; i++) {
		h1[i].style.color = "#2F2259";
	}
	for (var i = 0; i < p.length; i++) {
		p[i].style.color = "#000";
	}
	for (var i = 0; i < inputs.length; i++) {
		inputs[i].style.background = "#fff";
		inputs[i].style.color = "#000";
		inputs[i].style.border = "1px solid #2F2259";
	}
}
function cadastroModoEscuro() {
	var logo1 = document.querySelectorAll("img")[0];
	var labels = document.querySelectorAll("label");
	var divMensagem = document.getElementById("mensagem");
	var h1 = document.querySelectorAll("h1");
	var p = document.querySelectorAll("p");
	var inputs = document.querySelectorAll("input");
	var botaoCad = document.getElementById("botaoCad");
	var info = document.getElementById("informacoes");

	logo1.setAttribute("src", "imagens/logoEscWeb.png");
	body.classList.add("modoEscuro");
	body.style.backgroundColor = "#070512";
	body.style.color = "#f0f8ff";
	divMensagem.style.background = "linear-gradient(to bottom,  rgb(48, 37, 89) 0%, rgb(72, 57, 125) 100%)";
	botaoCad.style.background = "transparent";
	botaoCad.style.border = "1px solid #c9baff";
	botaoCad.style.color = "#c9baff";
	info.style.background = "#12101fff"
	body.style.height = `${document.innerHeigth}px`
	if (window.innerWidth < 600) {
		info.style.borderRadius = "0px"

	}
	labels.forEach(label => {
		label.style.color = "#f0f8ff";
	});

	h1.forEach(titulo => {
		titulo.style.color = "#C9BAFF";
	});

	p.forEach(paragrafo => {
		paragrafo.style.color = "#f0f8ff";
	});

	inputs.forEach(input => {
		input.style.background = "#12101fff";
		input.style.color = "#f0f8ff";
		input.style.border = "1px solid #c9baff";
	});

}

function commentModoClaro(){

}

function commentModoEscuro(){
	var forumCards = document.querySelectorAll(".forum-card")
	var textsCards = document.querySelectorAll(".forum-card-text")
	var forumActions = document.querySelectorAll(".forum-card-actions")
	var forumCardTitles = document.querySelectorAll(".forum-card-title");
	var paths = document.querySelectorAll("path")
	body.classList.add("modoEscuro");
	body.style.background = "#000"
	body.style.color = "#f0f8ff"
	body.style.margin = "0"
	

	forumCards.forEach((element, i) => {
		element.style.background = "#12101fff";
		textsCards[i].style.color = "#f0f8ff";
		forumActions[i].style.background = "#12101fff";
		forumActions[i].style.color = "#f0f8ff";
		if (forumCardTitles[i]) forumCardTitles[i].style.color = "#c9baff";
	});
	paths.forEach(function (path) {
		path.style.fill = "#c9baff";
		path.style.stroke = "#c9baff"
	});
}
//e
function editPerfilModoClaro() {
	var logo1 = document.querySelectorAll("img")[0];
	var paths = document.querySelectorAll("path")
	var formContainer = document.querySelector(".form-container")
	var b = document.querySelectorAll("b")
	var labels = document.querySelectorAll("label")
	var inputs = document.querySelectorAll("input");
	var p = document.querySelectorAll("p");
	var button = document.querySelectorAll("button")
	var borda = [document.querySelector(".button-outline").querySelector("div"), document.querySelector(".button-primary").querySelector("div")]

	logo1.setAttribute("src", "imagens/logoLittera.png");
	body.classList.remove("modoEscuro");
	body.style.backgroundImage = "url(../paginas/imagens/HomeBackground.png)"
	formContainer.style.background = "#ffffff";
	for (var i = 0; i < button.length; i++) {
		button[i].style.background = "linear-gradient(0deg, rgba(254, 254, 255, 0.5) 17%, rgba(155, 140, 219, 0.2) 100%)";
		button[i].style.border = "1px solid #2F2259"
	}
	for (var i = 0; i < borda.length; i++) {
		borda[i].style.borderLeft = "1px solid #2F2259"
	}
	for (var i = 0; i < b.length; i++) {
		b[i].style.color = "#2F2259"
	}
	for (var i = 0; i < p.length; i++) {
		p[i].style.color = "#000"
	}
	for (var i = 0; i < labels.length; i++) {
		labels[i].style.color = "#000"
	}
	for (var i = 0; i < inputs.length; i++) {
		inputs[i].style.background = "#fff";
		inputs[i].style.color = "#000";
		inputs[i].style.border = "1px solid #2F2259";

	}
	for (var i = 0; i < paths.length; i++) {
		paths[i].style.fill = "#2F2259"
		paths[i].style.stroke = "#2F2259"

	}

}
function editPerfilModoEscuro() {
	var logo1 = document.querySelectorAll("img")[0];
	var paths = document.querySelectorAll("path")
	var formContainer = document.querySelector(".form-container")
	var b = document.querySelectorAll("b")
	var labels = document.querySelectorAll("label")
	var inputs = document.querySelectorAll("input");
	var p = document.querySelectorAll("p");
	var button = document.querySelectorAll("button")
	var borda = [document.querySelector(".button-outline").querySelector("div"), document.querySelector(".button-primary").querySelector("div")]

	logo1.setAttribute("src", "imagens/logoEscWeb.png");
	body.classList.add("modoEscuro");
	body.style.backgroundImage = "url(../paginas/imagens/backgroundErroForumDark.png)"
	formContainer.style.background = "#12101fff"

	for (var i = 0; i < button.length; i++) {
		button[i].style.background = "linear-gradient(23deg, rgb(29, 21, 60) 8%, rgb(48, 37, 89) 32%, rgb(72, 57, 125) 59%, rgb(94, 84, 142) 80%, rgb(122, 106, 200) 100%) "
		button[i].style.border = "1px solid #C9BAFF"
	}

	for (var i = 0; i < borda.length; i++) {
		borda[i].style.borderLeft = "1px solid #C9BAFF"
	}

	for (var i = 0; i < b.length; i++) {
		b[i].style.color = "#f0f8ff"
	}
	for (var i = 0; i < p.length; i++) {
		p[i].style.color = "#f0f8ff"
	}
	for (var i = 0; i < labels.length; i++) {
		labels[i].style.color = "#f0f8ff"
	}
	for (var i = 0; i < inputs.length; i++) {
		inputs[i].style.background = "#12101fff";
		inputs[i].style.color = "#f0f8ff";
		inputs[i].style.border = "1px solid #c9baffff";
	}
	for (var i = 0; i < paths.length; i++) {
		paths[i].style.fill = "#c9baff"
		paths[i].style.stroke = "#c9baff"

	}
}
function erroforumModoClaro() {
	var logo1 = document.querySelectorAll("img")[0];
	var caixaHome = document.querySelector(".caixaHome");
	var p = document.querySelectorAll("p");
	var btn = document.querySelectorAll(".button")
	var spt = document.querySelectorAll(".separator")
	var txtCont = document.querySelectorAll(".textContent")
	var pathMenu = document.querySelectorAll("path")

	body.classList.remove("modoEscuro");
	body.style.backgroundImage = "url(../paginas/imagens/HomeBackground.png)"
	body.style.color = "#000"
	logo1.setAttribute("src", "imagens/logoLittera.png");
	caixaHome.style.background = "rgba(255, 255, 255, 0.40)";

	for (var i = 0; i < p.length; i++) {
		p[i].style.color = "#000"
	}
	for (var i = 0; i < btn.length; i++) {
		btn[i].style.background = "linear-gradient(0deg, rgba(254, 254, 255, 0.5) 17%, rgba(155, 140, 219, 0.2) 100%)";
		btn[i].style.border = "1px solid #2F2259"
		spt[i].style.background = "#2f2259"
		txtCont[i].style.color = "#2f2259"
		pathMenu[i].style.fill = "#2f2259"
	}
	pathMenu[1].style.fill = "#2f2259"
}
function erroforumModoEscuro() {
	var logo1 = document.querySelectorAll("img")[0];
	var caixaHome = document.querySelector(".caixaHome");
	var p = document.querySelectorAll("p");
	var btn = document.querySelectorAll(".button")
	var spt = document.querySelectorAll(".separator")
	var txtCont = document.querySelectorAll(".textContent")
	var pathMenu = document.querySelectorAll("path")



	logo1.setAttribute("src", "imagens/logoEscWeb.png");
	body.classList.add("modoEscuro");
	body.style.backgroundImage = "url(../paginas/imagens/backgroundErroForumDark.png)"
	caixaHome.style.background = "#12101fff"
	for (var i = 0; i < p.length; i++) {
		p[i].style.color = "#F0ECFF"
	}
	for (var i = 0; i < btn.length; i++) {
		btn[i].style.background = "linear-gradient(23deg, rgb(29, 21, 60) 8%, rgb(48, 37, 89) 32%, rgb(72, 57, 125) 59%, rgb(94, 84, 142) 80%, rgb(122, 106, 200) 100%) "
		btn[i].style.border = "1px solid #C9BAFF"
		spt[i].style.background = "#c9baff"
		txtCont[i].style.color = "#c9baff"
		pathMenu[i].style.fill = "#c9baff";

	}
	pathMenu[1].style.fill = "#c9baff"

}
function eventosModoClaro(){
	var logo1 = document.querySelectorAll("img")[0];
	var titulo = document.querySelector(".titulo")
	logo1.setAttribute("src", "imagens/logoLittera.png");
	body.classList.remove("modoEscuro");
	body.style.backgroundImage = "url(../paginas/imagens/HomeBackground.png)";
	body.style.color = "#000"
	titulo.style.color = "#2F2259";
}

function eventosModoEscuro(){
	var logo1 = document.querySelectorAll("img")[0];
	var titulo = document.querySelector(".titulo")
	logo1.setAttribute("src", "imagens/logoEscWeb.png");
	body.classList.add("modoEscuro");
	body.style.background = "linear-gradient(95deg,#070512 30%, #1D153C 100%)";
	body.style.color = "#f0f8ff";
	titulo.style.color = "#C9BAFF";

}
//f
function forumModoClaro() {
	var pop_ups = [document.getElementById("pop_up"), document.getElementById("pop_up2"), document.getElementById("pop_denuncia")];
	var tituloPopUp = document.getElementById("pop_up").querySelector("p")
	var buttons = document.querySelectorAll("button")
	var buttonsSave2 = document.querySelectorAll(".button-save2");
	var btn = document.querySelectorAll(".button")
	var spt = document.querySelectorAll(".separator")
	var txtCont = document.querySelectorAll(".textContent")
	var paths = document.querySelectorAll("path")
	var contForum = document.querySelector(".conteudoForum")
	var forumCards = document.querySelectorAll(".forum-card")
	var textsCards = document.querySelectorAll(".forum-card-text")
	var forumActions = document.querySelectorAll(".forum-card-actions")
	var forumCardTitles = document.querySelectorAll(".forum-card-title");
	var tituloForum = document.getElementById("tituloForum")
	var inputPesquisa = document.getElementById("pesquisa");
	var forumBusca = document.querySelector(".forum-busca");
	var meuPlace = document.getElementById("meuPlace")
	var meuPlace2 = document.getElementById("meuPlace2")
	var textDenuncia = document.getElementById("textDenuncia")
	var textbtnSave2 = document.querySelectorAll(".textbtnSave2")
	var active = document.querySelector(".active")
	const style = document.createElement('style');

	body.classList.remove("modoEscuro");
	body.style.background = "#fff";
	body.style.color = "#000"
	buttonsSave2.style.background = "#2F2259"
	forumBusca.style.background = "rgba(255, 255, 255, 0.90)"
	tituloPopUp.style.color = "#2F2259"
	contForum.style.background = "rgba(255, 255, 255, 0.90)"
	tituloForum.style.color = "#2F2259"
	inputPesquisa.style.background = "#fff"
	inputPesquisa.style.color = "#000"
	meuPlace.style.color = "#2F2259"
	meuPlace2.style.color = "#000"
	textDenuncia.style.color = "#2F2259"

	style.innerHTML = `
  	#meuPlace::placeholder {
    	color: #21173fff;
 	 }
	#meuPlace2::placeholder {
    	color: #6c7379ff;
 	 }`;

	document.head.appendChild(style);
	btn.forEach((element, i) => {
		element.style.background = "trasparent";
		element.style.border = "1px solid #2f2259";
		element.style.color = "#2f2259";
		if (spt[i]) spt[i].style.background = "#2f2259";
		if (txtCont[i]) txtCont[i].style.color = "#2f2259";
	});

	buttons.forEach(element => {
		element.style.color = "#2f2259";
		element.style.border = "1px solid #2f2259";
		element.style.background = "transparent";
	});
	active.style.background = "linear-gradient(to top, rgb(240, 236, 255) 10%, rgb(72, 57, 125) 480%)";
	textbtnSave2.forEach(element => {
		element.style.color = "#2f2259";
	})

	forumCards.forEach((element, i) => {
		if (!element) return;
		element.style.background = "rgba(255, 255, 255, 0.90)";
		if (textsCards[i]) textsCards[i].style.color = "#000";
		if (forumActions[i]) {
			forumActions[i].style.background = "rgba(255, 255, 255, 0.90)";
			forumActions[i].style.color = "#2F2259";
		}
		if (forumCardTitles[i]) forumCardTitles[i].style.color = "#2F2259";
	});
	paths.forEach(function (path) {
		path.style.fill = "#2f2259";
		path.style.stroke = "#2f2559";
	});
	pop_ups.forEach(function (pop_up) {
		pop_up.style.background = "rgb(255, 255, 255)";
	});
	forumActions.forEach(function (card) {
		var spans = card.querySelectorAll("span");
		spans.forEach(function (span) {
			span.style.color = "#2F2259";
		});
	});


}

function forumModoEscuro() {
	var pop_ups = [document.getElementById("pop_up"), document.getElementById("pop_up2"), document.getElementById("pop_denuncia")];
	var tituloPopUp = document.getElementById("pop_up").querySelector("p")
	var buttons = document.querySelectorAll("button")
	var btn = document.querySelectorAll(".button")
	var spt = document.querySelectorAll(".separator")
	var txtCont = document.querySelectorAll(".textContent")
	var paths = document.querySelectorAll("path")
	var contForum = document.querySelector(".conteudoForum")
	var forumCards = document.querySelectorAll(".forum-card")
	var textsCards = document.querySelectorAll(".forum-card-text")
	var forumActions = document.querySelectorAll(".forum-card-actions")
	var forumCardTitles = document.querySelectorAll(".forum-card-title");
	var tituloForum = document.getElementById("tituloForum")
	var inputPesquisa = document.getElementById("pesquisa");
	var forumBusca = document.querySelector(".forum-busca");
	var meuPlace = document.getElementById("meuPlace")
	var meuPlace2 = document.getElementById("meuPlace2")
	var textDenuncia = document.getElementById("textDenuncia")
	var textbtnSave2 = document.querySelectorAll(".textbtnSave2")
	var active = document.querySelector(".active")
	const style = document.createElement('style');

	body.classList.add("modoEscuro");
	body.style.background = "#000"
	body.style.color = "#f0f8ff"
	body.style.margin = "0"
	forumBusca.style.background = "#12101fff"
	tituloPopUp.style.color = "#C9BAFF"
	contForum.style.background = "#12101fff"
	tituloForum.style.color = "#c9baff"
	inputPesquisa.style.background = "#12101fff"
	inputPesquisa.style.color = "#f0f8ff"
	meuPlace.style.color = "#c9baff"
	meuPlace2.style.color = "#f0f8ff"
	textDenuncia.style.color = "#c9baff"


	style.innerHTML = `
  	#meuPlace::placeholder {
    	color: #7367a1ff;
 	 }
	#meuPlace2::placeholder {
    	color: #aab3bbff;
 	 }`;

	document.head.appendChild(style);
	btn.forEach((element, i) => {
		element.style.background = "rgba(255, 255, 255, 0.0)";
		element.style.border = "1px solid #C9BAFF";
		element.style.color = "#C9BAFF";
		if (spt[i]) spt[i].style.background = "#C9BAFF";
		if (txtCont[i]) txtCont[i].style.color = "#C9BAFF";
	});

	buttons.forEach(element => {
		element.style.color = "#C9BAFF";
		element.style.border = "1px solid #C9BAFF";
		element.style.background = "transparent";
	});

	textbtnSave2.forEach(element => {
		element.style.color = "#C9BAFF";
	})

	forumCards.forEach((element, i) => {
		element.style.background = "#12101fff";
		textsCards[i].style.color = "#f0f8ff";
		forumActions[i].style.background = "#12101fff";
		forumActions[i].style.color = "#f0f8ff";
		if (forumCardTitles[i]) forumCardTitles[i].style.color = "#c9baff";
	});
	paths.forEach(function (path) {
		path.style.fill = "#c9baff";
		path.style.stroke = "#c9baff"
	});
	pop_ups.forEach(function (pop_up) {
		pop_up.style.background = "#12101fff"
	})
	forumActions.forEach(function (card) {
		var spans = card.querySelectorAll("span");
		spans.forEach(function (span) {
			span.style.color = "#f0f8ff"; // aqui você muda a cor do texto
		});
	});
	active.style.background = "linear-gradient(23deg,#1D153C 8%, #302559 32%, #48397D 59%, #5E548E 80% , #7A6AC8 100% )";
}
//h
function homeModoClaro() {
	var pop_up = document.getElementById("pop_up");
	var logo1 = document.querySelectorAll("img")[0];
	var nav = document.querySelector("nav");
	var navItens = document.querySelectorAll(".navItem")
	var caixasHome = document.querySelectorAll(".caixaHome")
	var btn = document.querySelectorAll(".button")
	var spt = document.querySelectorAll(".separator")
	var txtCont = document.querySelectorAll(".textContent")
	var paths = document.querySelectorAll("path")
	var a = document.querySelectorAll("a");
	body.classList.remove("modoEscuro");
	body.style.backgroundImage = "url(../paginas/imagens/backgroundHome.png)"
	body.style.color = "#000"
	body.style.backdropFilter = " brightness(1)"
	logo1.setAttribute("src", "imagens/logoLittera.png");
	nav.style.background = "linear-gradient(to right, rgba(255, 255, 255, 0.43) 0%, rgba(255,255,255,0.0) 100%)"
	pop_up.style.background = "#ffffff"
	for (var i = 0; i < a.length; i++) {
		a[i].style.color = "#2F2259"
	}

	for (var i = 0; i < navItens.length; i++) {
		navItens[i].style.color = "#2F2259"
	}
	for (var i = 0; i < paths.length; i++) {
		paths[i].style.fill = "#2F2259"
		if (paths[i].querySelector("d").includes("M22 12.35C21.9909 11.3317 21.5823 10.3578 20.8623 9.63773C20.1422 8.917")) {
			paths[i].style.fill = "none"
		}
	}
	for (var i = 0; i < caixasHome.length; i++) {
		caixasHome[i].style.background = "rgba(255, 255, 255, 0.40)"
	}
	for (var i = 0; i < btn.length; i++) {
		btn[i].style.background = "linear-gradient(to top, rgba(254, 254, 255, 0.5) 17%, rgba(109, 97, 147, 0.5) 200%);"
		btn[i].style.border = "1px solid #2F2259"
		spt[i].style.background = "#2F2259"
		txtCont[i].style.color = "#2F2259"
	}
	paths[0].style.stroke = "#2F2259"
	paths[10].style.stroke = "#2F2259"
	paths[10].style.fill = "none"
}
function homeModoEscuro() {
	var pop_up = document.getElementById("pop_up");
	var logo1 = document.querySelectorAll("img")[0];
	var nav = document.querySelector("nav");
	var navItens = document.querySelectorAll(".navItem")
	var caixasHome = document.querySelectorAll(".caixaHome")
	var btn = document.querySelectorAll(".button")
	var spt = document.querySelectorAll(".separator")
	var txtCont = document.querySelectorAll(".textContent")
	var paths = document.querySelectorAll("path")
	var a = document.querySelectorAll("a");

	body.classList.add("modoEscuro");
	body.style.height = "100%"
	body.style.backgroundImage = "url(../paginas/imagens/backgroundErroForumDark.png)"
	body.style.color = "#f0f8ff"
	body.style.backdropFilter = " brightness(0.8)"
	body.style.backgroundRepeat = "no-repeat "
	body.style.backgroundSize = "cover"
	logo1.setAttribute("src", "imagens/logoEscWeb.png");
	nav.style.background = "linear-gradient(to right, rgba(8, 8, 10, 0.43) 0%, rgba(0,0,0,0.0) 100%)"
	pop_up.style.background = "#12101fff"

	for (var i = 0; i < a.length; i++) {
		a[i].style.color = "#c9baff"
	}
	for (var i = 0; i < navItens.length; i++) {
		navItens[i].style.color = "#c9baff"
	}

	for (var i = 0; i < caixasHome.length; i++) {
		caixasHome[i].style.background = "#12101fff"
	}

	for (var i = 0; i < btn.length; i++) {
		btn[i].style.background = "linear-gradient(23deg, rgb(29, 21, 60) 8%, rgb(48, 37, 89) 32%, rgb(72, 57, 125) 59%, rgb(94, 84, 142) 80%, rgb(122, 106, 200) 100%) "
		btn[i].style.border = "1px solid #C9BAFF"
		spt[i].style.background = "#c9baff"
		txtCont[i].style.color = "#c9baff"
		paths[i].style.fill = "#c9baff";
	}

	for (var i = 0; i < paths.length; i++) {
		paths[i].style.fill = "#c9baff"
	}
	paths[0].style.stroke = "#C9BAFF"
	paths[10].style.stroke = "#C9BAFF"
	paths[10].style.fill = "none"


}
//i
function indexModoClaro() {

	var fundoGradiente = document.getElementById("fundoGradiente")
	var minhaLogo = document.getElementById("minhaLogo")
	var nav = document.getElementById("nav")
	var linkLogin = document.getElementById("linkLogin")
	var footer = document.getElementById("footer")
	var txtCreditos = document.getElementById("txtCreditos")
	var divWeb = document.getElementById("web")

	var texto = [document.getElementById("textLittera"),
	document.getElementById("descricaoD"),
	document.getElementById("descricaoM"),
	document.getElementById("descricaoW")]

	var Logo1 = document.querySelectorAll("img")[3]
	var Logo2 = document.querySelectorAll("img")[6]
	var logo3 = document.querySelectorAll("img")[7]

	var btnsIcons = document.querySelectorAll(".icon")
	var btn = document.querySelectorAll(".button")
	var spt = document.querySelectorAll(".separator")
	var txtCont = document.querySelectorAll(".textContent")
	var pathMenu = document.querySelectorAll("path")

	var titulos = [document.getElementById("tituloWeb"),
	document.getElementById("tituloDesktop"),
	document.getElementById("tituloMobile")]

	var divsExplicativas = [document.getElementById("caixaWeb"),
	document.getElementById("desktop"),
	document.getElementById("mobile")]

	body.classList.remove("modoEscuro")

	body.style.backgroundColor = "#ffff"
	nav.style.background = "#ffffff44"
	titulos[0].style = "#2F2259"
	titulos[1].style.color = "#013B84"
	titulos[2].style.color = "#800000"
	txtCreditos.style.color = "#2F2259"
	linkLogin.style.color = "#2F2259"
	linkLogin.style.border = "1px solid #2F2259"
	linkLogin.style.background = "rgba(255, 255, 255, 0.40)"
	if (window.innerWidth < 600) {
		divWeb.style.background = "linear-gradient(to bottom, white, #A293CD)"
	} else {
		divWeb.style.background = "transparent"
	}

	divsExplicativas[0].style.background = "linear-gradient(to bottom, white, #A293CD)"
	divsExplicativas[1].style.background = "linear-gradient(to left, white, #577DAE)"
	divsExplicativas[2].style.background = "linear-gradient(to right, white, #800000b6)"
	footer.style.background = "linear-gradient(23deg,#F0ECFF 8%, #C9BAFF 32%, #A293CD 59%, #7A6AC8 80% , #48397D 100% )"

	fundoGradiente.style.backgroundImage = "url(../paginas/imagens/backgroundHome.png)"
	minhaLogo.setAttribute("src", "../paginas/imagens/logoLittera.png")
	Logo1.setAttribute("src", "../paginas/imagens/logoLazul.png")
	Logo2.setAttribute("src", "../paginas/imagens/logoLvermelho.png")
	logo3.setAttribute("src", "../paginas/imagens/logoLittera.png")


	//muda as bordas dos botões
	for (var i = 0; i < btn.length; i++) {
		btn[i].style.background = "rgba(255, 255, 255, 0.0)"
		if (i == 0) {
			btn[i].style.border = "1px solid #013B84"
			spt[i].style.background = "#013B84"
			txtCont[i].style.color = "#013B84"
		} else if (i == 1) {
			btn[i].style.border = "1px solid #800500"
			spt[i].style.background = "#800500"
			txtCont[i].style.color = "#800500"
		}else if (i === btn.length - 1) {
			txtCont[i].textContent = "baixo contraste"
			txtCont[i].style.color = "#2f2259"
			btn[i].style.border = "1px solid #2F2259"
			spt[i].style.background = "#2f2259"
		} else {
			btn[i].style.border = "1px solid #2F2259"
			spt[i].style.background = "#2f2259"
			txtCont[i].style.color = "#2f2259"
		}
	}

	for (var i = 0; i < 4; i++) {
		texto[i].style.color = "#000"
	}
	for (var i = 0; i < 6; i++) {
		pathMenu[i].style.fill = "#000"
		document.querySelectorAll(".navItem")[i].style.color = "#000"
	}

	for (var i = 0; i < pathMenu.length; i++) {
		if (i <= 5) {
			pathMenu[i].style.fill = "#2F2259"
		} else if (i > 5 && i <= 7) {
			pathMenu[i].style.fill = "#013B84"
		} else if (i > 7 && i <= 9) {
			pathMenu[i].style.fill = "#800500"
		} else {
			pathMenu[i].style.fill = "none"
			pathMenu[i].style.stroke = "#573280"
			pathMenu[i].setAttribute("d", "M21.4993 1.9165V3.87484M21.4993 39.1248V41.0832M41.0827 21.4998H39.1243M3.87435 21.4998H1.91602M35.3448 7.65442L34.5771 8.42405M8.4216 34.5776L7.65197 35.3472M35.3448 35.3453L34.5771 34.5756M8.4216 8.42209L7.65197 7.65246M10.4171 17.5832C9.52956 20.0959 9.52247 22.8356 10.397 25.3529C11.2716 27.8702 12.9759 30.0154 15.2302 31.4365C17.4845 32.8576 20.1549 33.4702 22.8032 33.1738C25.4515 32.8774 27.9204 31.6896 29.8047 29.8052C31.6891 27.9209 32.8769 25.452 33.1733 22.8037C33.4697 20.1554 32.8571 17.4849 31.436 15.2306C30.0149 12.9764 27.8697 11.2721 25.3524 10.3975C22.8352 9.52296 20.0954 9.53005 17.5827 10.4176")
		}

	}
}
function indexModoEscuro() {

	var fundoGradiente = document.getElementById("fundoGradiente")
	var minhaLogo = document.getElementById("minhaLogo")
	var nav = document.getElementById("nav")
	var linkLogin = document.getElementById("linkLogin")
	var footer = document.getElementById("footer")
	var txtCreditos = document.getElementById("txtCreditos")
	var divWeb = document.getElementById("web")

	var texto = [document.getElementById("textLittera"),
	document.getElementById("descricaoD"),
	document.getElementById("descricaoM"),
	document.getElementById("descricaoW")]

	var Logo1 = document.querySelectorAll("img")[3]
	var Logo2 = document.querySelectorAll("img")[6]
	var logo3 = document.querySelectorAll("img")[7]

	var btnsIcons = document.querySelectorAll(".icon")
	var btn = document.querySelectorAll(".button")
	var spt = document.querySelectorAll(".separator")
	var txtCont = document.querySelectorAll(".textContent")
	var pathMenu = document.querySelectorAll("path")

	var titulos = [document.getElementById("tituloWeb"),
	document.getElementById("tituloDesktop"),
	document.getElementById("tituloMobile")]

	var divsExplicativas = [document.getElementById("caixaWeb"),
	document.getElementById("desktop"),
	document.getElementById("mobile")]


	body.classList.add('modoEscuro')

	titulos[0].style.color = "#C9BAFF"
	titulos[1].style.color = "#0BA4FF"
	titulos[2].style.color = "#FF551C"
	txtCreditos.style.color = "#C9BAFF"
	linkLogin.style.color = "#C9BAFF"
	linkLogin.style.border = "1px solid #C9BAFF"
	linkLogin.style.background = "rgba(255, 255, 255, 0.0)"
	body.style.backgroundColor = "#070512"
	if (window.innerWidth < 600) {
		divWeb.style.background = "#12101fff"
	} else {
		divWeb.style.background = "transparent"
	}
	nav.style.background = "linear-gradient(to right, rgba(8, 8, 10, 0.43) 0%, rgba(0,0,0,0.0) 100%)"
	footer.style.background = "linear-gradient(23deg,#1D153C 8%, #302559 32%, #48397D 59%, #5E548E 80% , #7A6AC8 100% )"

	fundoGradiente.style.backgroundImage = "url(../paginas/imagens/backgroundHomeDark.png)"
	minhaLogo.setAttribute("src", "../paginas/imagens/logoEscWeb.png")
	Logo1.setAttribute("src", "../paginas/imagens/logoEscDesk.png")
	Logo2.setAttribute("src", "../paginas/imagens/logoEscMob.png")
	logo3.setAttribute("src", "../paginas/imagens/logoEscWeb.png")


	for (var i = 0; i < pathMenu.length; i++) {
		if (i <= 5) {
			pathMenu[i].style.fill = "#C9BAFF"
		} else if (i > 5 && i <= 7) {
			pathMenu[i].style.fill = "#0BA4FF"
		} else if (i > 7 && i <= 9) {
			pathMenu[i].style.fill = "#FF551C"
		} else {
			pathMenu[i].style.stroke = "#C9BAFF"
			pathMenu[i].setAttribute("d", "M12.3874 32.2719C12.2813 32.1663 12.1554 32.0826 12.017 32.0256C11.8786 31.9685 11.7303 31.9394 11.5806 31.9397C11.4309 31.94 11.2827 31.9697 11.1445 32.0273C11.0063 32.0849 10.8808 32.1691 10.7752 32.2752C10.6695 32.3812 10.5858 32.5071 10.5288 32.6455C10.4718 32.7839 10.4426 32.9322 10.4429 33.0819C10.4432 33.2316 10.473 33.3798 10.5305 33.518C10.5881 33.6562 10.6723 33.7817 10.7784 33.8873L12.3874 32.2719ZM6.52419 26.5759C6.55923 26.7248 6.62389 26.8652 6.71434 26.9886C6.80478 27.112 6.91914 27.216 7.05062 27.2943C7.18209 27.3726 7.32798 27.4236 7.47959 27.4443C7.6312 27.465 7.78542 27.4549 7.93307 27.4148C8.08072 27.3746 8.21877 27.3051 8.33899 27.2105C8.45921 27.1158 8.55915 26.9979 8.63284 26.8638C8.70652 26.7297 8.75246 26.5821 8.7679 26.4299C8.78334 26.2777 8.76797 26.1239 8.72272 25.9777L6.52419 26.5759ZM35.8855 25.8836C34.933 29.4885 32.5875 32.5675 29.365 34.4431C26.1424 36.3187 22.3068 36.8373 18.7019 35.8848L18.1195 38.089C26.8436 40.394 35.7847 35.1901 38.0896 26.4659L35.8855 25.8836ZM8.70059 18.7012C9.65303 15.0963 11.9985 12.0174 15.2211 10.1418C18.4436 8.26616 22.2793 7.74754 25.8842 8.69998L26.4666 6.4958C17.7424 4.19085 8.80136 9.39474 6.49641 18.1189L8.70059 18.7012ZM26.5626 26.9575C24.3217 26.3654 22.4077 24.9074 21.2418 22.9042C20.0759 20.901 19.7535 18.5167 20.3456 16.2758L18.1414 15.6934C17.3949 18.5189 17.8014 21.5253 19.2715 24.051C20.7415 26.5768 23.1547 28.4152 25.9802 29.1617L26.5626 26.9575ZM34.8793 24.783C33.7979 25.8314 32.464 26.5825 31.0068 26.9635C29.5496 27.3445 28.0187 27.3424 26.5626 26.9575L25.9802 29.1617C27.816 29.6473 29.7461 29.6502 31.5833 29.1702C33.4206 28.6903 35.1026 27.7436 36.4663 26.4222L34.8793 24.783ZM20.3456 16.2758C20.7301 14.8196 21.4845 13.4874 22.5355 12.4086C23.5865 11.3297 24.8985 10.5409 26.3442 10.1184L25.7024 7.93038C23.8801 8.46332 22.2264 9.45808 20.9016 10.8182C19.5769 12.1784 18.6261 13.8577 18.1414 15.6934L20.3456 16.2758ZM25.8842 8.69998C25.8107 8.67904 25.7421 8.64374 25.6824 8.59612C25.6227 8.5485 25.573 8.4895 25.5362 8.42253C25.4907 8.34394 25.4697 8.25354 25.4759 8.16293C25.482 8.11583 25.5199 7.98435 25.7024 7.93038L26.3442 10.1184C27.2013 9.867 27.6556 9.1114 27.739 8.44488C27.8245 7.75221 27.5201 6.77416 26.4666 6.4958L25.8842 8.69998ZM36.4663 26.4222C36.3278 26.5538 36.1947 26.5218 36.1507 26.5039C36.0689 26.4645 36.0007 26.4016 35.9548 26.3232C35.9147 26.2582 35.888 26.1858 35.8761 26.1103C35.8642 26.0349 35.8674 25.9578 35.8855 25.8836L38.0896 26.4659C38.368 25.4123 37.6679 24.6646 37.0234 24.3968C36.4027 24.1401 35.5213 24.1619 34.8793 24.783L36.4663 26.4222ZM18.7019 35.8848C16.3151 35.2588 14.1365 34.0123 12.3874 32.2719L10.7784 33.8873C12.812 35.9109 15.3447 37.3605 18.1195 38.089L18.7019 35.8848ZM8.72272 25.9777C8.07331 23.5967 8.06568 21.0862 8.70059 18.7012L6.49641 18.1189C5.75971 20.891 5.76929 23.8086 6.52419 26.5759L8.72272 25.9777Z")
		}

	}

	//muda as bordas dos botões
	for (var i = 0; i < btn.length; i++) {
		btn[i].style.background = "rgba(255, 255, 255, 0.0)"
		if (i == 0) {
			btn[i].style.border = "1px solid #0BA4FF"
			spt[i].style.background = "#0BA4FF"
			txtCont[i].style.color = "#0BA4FF"
		} else if (i == 1) {
			btn[i].style.border = "1px solid #FF551C"
			spt[i].style.background = "#FF551C"
			txtCont[i].style.color = "#FF551C"
		} else if (i === btn.length - 1) {
			txtCont[i].textContent = "alto Contraste"
			txtCont[i].style.color = "#C9BAFF"
			btn[i].style.border = "1px solid #C9BAFF"
			spt[i].style.background = "#C9BAFF"
		} else {
			btn[i].style.border = "1px solid #C9BAFF"
			spt[i].style.background = "#C9BAFF"
			txtCont[i].style.color = "#C9BAFF"
		}
	}
	for (var i = 0; i < btnsIcons.length; i++) {
		btnsIcons[i].style.background = "rgba(0, 0, 0, 0.0)"
	}

	for (var i = 0; i < 4; i++) {
		texto[i].style.color = "#fff"
	}

	for (var i = 0; i < 6; i++) {
		document.querySelectorAll(".navItem")[i].style.color = "#C9BAFF"
	}
	for (var i = 0; i < 3; i++) {
		divsExplicativas[i].style.background = "#12101fff"
	}

}
//l
function loginModoClaro() {
	var logo1 = document.querySelectorAll("img")[0];
	var divMensagem = document.getElementById("mensagem");
	var h1 = document.querySelectorAll("h1");
	var p = document.querySelectorAll("p");
	var inputs = document.querySelectorAll("input");
	var labels = document.querySelectorAll("label");
	var btn = document.querySelectorAll(".button")
	var spt = document.querySelectorAll(".separator")
	var txtCont = document.querySelectorAll(".textContent")
	var pathMenu = document.querySelectorAll("path")
	var info = document.getElementById("informacoes");

	body.classList.remove("modoEscuro");
	body.style.background = "#ffff";
	body.style.color = "#000"
	logo1.setAttribute("src", "imagens/logoLittera.png");
	divMensagem.style.background = "linear-gradient(to bottom,  rgb(240, 236, 255) 0%, rgb(194, 186, 255) 100%)";
	info.style.background = "rgba(255, 255, 255, 1)"
	if (window.innerWidth < 600) {
		info.style.borderRadius = "0px"
	}
	for (var i = 0; i < labels.length; i++) {
		labels[i].style.color = "#000";
	}
	for (var i = 0; i < h1.length; i++) {
		h1[i].style.color = "#2F2259";
	}
	for (var i = 0; i < p.length; i++) {
		p[i].style.color = "#000";
		if (p[i].classList.contains("textContent")) {
			p[i].style.color = "#2F2259";
		}
	}

	for (var i = 0; i < btn.length; i++) {
		btn[i].style.background = "linear-gradient(0deg, rgba(254, 254, 255, 0.5) 17%, rgba(155, 140, 219, 0.2) 100%)";
		btn[i].style.border = "1px solid #2F2259"
		spt[i].style.background = "#2f2259"
		txtCont[i].style.color = "#2f2259"
	}

	for (var i = 0; i < pathMenu.length; i++) {
		pathMenu[0].style.fill = "none";
		pathMenu[i].style.fill = "#2f2259";
	}

	for (var i = 0; i < inputs.length; i++) {

		inputs[i].style.background = "#fff";
		inputs[i].style.color = "#000";
		inputs[i].style.border = "1px solid #2F2259";
	}
}

function loginModoEscuro() {
	var logo1 = document.querySelectorAll("img")[0];
	var divMensagem = document.getElementById("mensagem");
	var h1 = document.querySelectorAll("h1");
	var p = document.querySelectorAll("p");
	var inputs = document.querySelectorAll("input");
	var labels = document.querySelectorAll("label");
	var btn = document.querySelectorAll(".button")
	var spt = document.querySelectorAll(".separator")
	var txtCont = document.querySelectorAll(".textContent")
	var pathMenu = document.querySelectorAll("path")
	var info = document.getElementById("informacoes");

	body.classList.add("modoEscuro");
	body.style.background = "#070512";
	body.style.color = "#f0f8ff"
	logo1.setAttribute("src", "imagens/logoEscWeb.png");
	divMensagem.style.background = "linear-gradient(to bottom,  rgb(48, 37, 89) 0%, rgb(72, 57, 125) 100%)";
	info.style.background = "#12101fff"
	if (window.innerWidth < 600) {
		info.style.borderRadius = "0px"
	}

	for (var i = 0; i < labels.length; i++) {
		labels[i].style.color = "#f0f8ff";
	}
	for (var i = 0; i < h1.length; i++) {
		h1[i].style.color = "#C9BAFF";
	}
	for (var i = 0; i < p.length; i++) {
		p[i].style.color = "#f0f8ff";
		if (p[i].classList.contains("textContent")) {
			p[i].style.color = "#C9BAFF";
		}
	}

	for (var i = 0; i < btn.length; i++) {
		btn[i].style.background = "linear-gradient(23deg, rgb(29, 21, 60) 8%, rgb(48, 37, 89) 32%, rgb(72, 57, 125) 59%, rgb(94, 84, 142) 80%, rgb(122, 106, 200) 100%) "
		btn[i].style.border = "1px solid #C9BAFF"
		spt[i].style.background = "#c9baff"
		txtCont[i].style.color = "#c9baff"
	}

	for (var i = 0; i < pathMenu.length; i++) {
		pathMenu[i].style.fill = "#c9baff";
	}

	for (var i = 0; i < inputs.length; i++) {
		inputs[i].style.background = "#12101fff";
		inputs[i].style.color = "#f0f8ff";
		inputs[i].style.border = "1px solid #c9baff";
	}
}
//r
function recSenhaaModoClaro() {
	body.classList.remove("modoEscuro");
	body.style.background = "linear-gradient(135deg, #272727 0%, #c4c1c2 100%);";
	body.style.color = "#000";
	document.querySelectorAll("div")[0].style.background = "rgba(255, 255, 255, 1)";
	document.querySelectorAll("h2")[0].style.color = "#000";
	document.querySelector(".subtitle").style.color = "#000";
	document.querySelectorAll("label")[0].style.color = "#000";
	var inputs = document.querySelectorAll("input");

	for (var i = 0; i < inputs.length; i++) {
		inputs[i].style.background = "#fff";
		inputs[i].style.color = "#333";
		inputs[i].style.border = "1px solid #2F2259";
	}
}
function recSenhaaModoEscuro() {
	body.classList.add("modoEscuro");
	body.style.background = "linear-gradient(135deg , #070512 0%, #2c2340 100%)";
	document.querySelectorAll("div")[0].style.background = "#12101fff";
	document.querySelectorAll("h2")[0].style.color = "#C9BAFF";
	document.querySelector(".subtitle").style.color = "#f0f8ff";
	document.querySelectorAll("label")[0].style.color = "#f0f8ff";


	var inputs = document.querySelectorAll("input");
	for (var i = 0; i < inputs.length; i++) {
		inputs[i].style.background = "#12101fff";
		inputs[i].style.color = "#f0f8ff";
		inputs[i].style.border = "1px solid #c9baff";
	}
}