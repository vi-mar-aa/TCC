function clicarLivro() {
	window.location.href = "Acervo.php";
	// document.getElementById("tabLivro").style.backgroundColor = "rgba(0,0,0,0.0)";
	// document.getElementById("tabAudio").style.background = "linear-gradient(to top, #F0ECFF 10% , #48397D 480%)";

}
function clicarAudio() {
	window.location.href = "AcervoAudio.php";
	// document.getElementById("tabAudio1").style.backgroundColor = "rgba(0,0,0,0.0)";
	// document.getElementById("tabLivro1").style.background = "linear-gradient(to top, #F0ECFF 10% , #48397D 480%)";
}

window.addEventListener('DOMContentLoaded', function () {
	// Seu código JavaScript aqui
	var pathname = window.location.pathname.toLowerCase();
	if (pathname.includes("acervo.php")) {
		document.getElementById("tabAudio0").style.backgroundColor = "rgba(0,0,0,0.0)";
		document.getElementById("tabLivro0").style.background = "linear-gradient(to top, #F0ECFF 10% , #48397D 480%)";
	}

	if (pathname.includes("acervoaudio.php")) {
		// Altera o estilo das abas somente quando a página AcervoAudio.php for carregada
		document.getElementById("tabLivro1").style.backgroundColor = "rgba(0,0,0,0.0)";
		document.getElementById("tabAudio1").style.background = "linear-gradient(to top, #F0ECFF 10%, #48397D 480%)";
	}
});

