//devido ao tamnho do codigo e ao grande tempo de carregamento de paginas
//senti a necssidade de criar esse codigo experimental para testes
//nesse caso e a index.html ela ja começa pre carregando as funções e
//seus temas pra so depois aplicar na pagina quando ela for carregada
// nos meus teste ja senti uma grande melhoria no tempo de carregamento 
//porém não testei responsividade e outros fatores

// ======================================INDEX===============================================================================
function indexModoClaro() {
    aplicarTema({
        modo: 'claro',
        bodyBg: "#ffff",
        navBg: "#ffffff44",
        tituloColors: ["#2F2259", "#013B84", "#800000"], //na maiora dos casos a função engloba
        creditosColor: "#2F2259",//                            coisas parecidas(seja cor,gradiente,img
        linkLogin: {//                                           paths etc) ou de elementos parecidos no   
            color: "#2F2259",//                                mesmo array isso faz com que ao inves de 
            border: "1px solid #2F2259",//                     ter que execultar o codigo varias vezes
            bg: "rgba(255, 255, 255, 0.40)"//                  ele apenas altera tudo de uma vez.
        },
        webBgMobile: "linear-gradient(to bottom, white, #A293CD)",
        webBgDesktop: "transparent",
        divsBg: [
            "linear-gradient(to bottom, white, #A293CD)",
            "linear-gradient(to left, white, #577DAE)",
            "linear-gradient(to right, white, #800000b6)"
        ],
        footerBg: "linear-gradient(23deg,#F0ECFF 8%, #C9BAFF 32%, #A293CD 59%, #7A6AC8 80% , #48397D 100%)",
        logos: [
            "../paginas/imagens/logoLittera.png",
            "../paginas/imagens/logoLazul.png",
            "../paginas/imagens/logoLvermelho.png",
            "../paginas/imagens/logoLittera.png"
        ],
        fundoBg: "../paginas/imagens/backgroundHome.png",
        btnConfig: [
            { border: "#013B84", spt: "#013B84", txt: "#013B84" },
            { border: "#800500", spt: "#800500", txt: "#800500" },
            { border: "#2F2259", spt: "#2F2259", txt: "#2F2259" }
        ],
        textoColor: "#000",
        navItemColor: "#000",
        pathColors: [
            { from: 0, to: 5, fill: "#2F2259" },
            { from: 6, to: 7, fill: "#013B84" },
            { from: 8, to: 9, fill: "#800500" },
            {
                from: 10, fill: "none", stroke: "#573280",
                d: "M21.4993 1.9165V3.87484M21.4993 39.1248V41.0832M41.0827 21.4998H39.1243M3.87435 21.4998H1.91602M35.3448 7.65442L34.5771 8.42405M8.4216 34.5776L7.65197 35.3472M35.3448 35.3453L34.5771 34.5756M8.4216 8.42209L7.65197 7.65246M10.4171 17.5832C9.52956 20.0959 9.52247 22.8356 10.397 25.3529C11.2716 27.8702 12.9759 30.0154 15.2302 31.4365C17.4845 32.8576 20.1549 33.4702 22.8032 33.1738C25.4515 32.8774 27.9204 31.6896 29.8047 29.8052C31.6891 27.9209 32.8769 25.452 33.1733 22.8037C33.4697 20.1554 32.8571 17.4849 31.436 15.2306C30.0149 12.9764 27.8697 11.2721 25.3524 10.3975C22.8352 9.52296 20.0954 9.53005 17.5827 10.4176"
            }
        ]
    });
}

function indexModoEscuro() {
    aplicarTema({
        modo: 'escuro',
        bodyBg: "#070512",
        navBg: "linear-gradient(to right, rgba(8, 8, 10, 0.43) 0%, rgba(0,0,0,0.0) 100%)",
        tituloColors: ["#C9BAFF", "#0BA4FF", "#FF551C"],//basicamente ele ja pre-carrega os valores
        creditosColor: "#C9BAFF",//                           que as variaveis irão receber sem a 
        linkLogin: {//                                          necessidade de utiliza o getElementById
            color: "#C9BAFF",//                               nem o querySelectorAll 
            border: "1px solid #C9BAFF",
            bg: "rgba(255, 255, 255, 0.0)"
        },
        webBgMobile: "#12101fff",
        webBgDesktop: "transparent",
        divsBg: ["#12101fff", "#12101fff", "#12101fff"],
        footerBg: "linear-gradient(23deg,#1D153C 8%, #302559 32%, #48397D 59%, #5E548E 80% , #7A6AC8 100%)",
        logos: [
            "../paginas/imagens/logoEscWeb.png",
            "../paginas/imagens/logoEscDesk.png",
            "../paginas/imagens/logoEscMob.png",
            "../paginas/imagens/logoEscWeb.png"
        ],
        fundoBg: "../paginas/imagens/backgroundHomeDark.png",
        btnConfig: [
            { border: "#0BA4FF", spt: "#0BA4FF", txt: "#0BA4FF" },
            { border: "#FF551C", spt: "#FF551C", txt: "#FF551C" },
            { border: "#C9BAFF", spt: "#C9BAFF", txt: "#C9BAFF" }
        ],
        textoColor: "#fff",
        navItemColor: "#C9BAFF",
        pathColors: [
            { from: 0, to: 5, fill: "#C9BAFF" },
            { from: 6, to: 7, fill: "#0BA4FF" },
            { from: 8, to: 9, fill: "#FF551C" },
            {
                from: 10, stroke: "#C9BAFF",
                d: "M12.3874 32.2719C12.2813 ... (caminho do SVG encurtado)"
            }
        ]
    });
}

// =========================
// Função genérica de tema
// =========================
function aplicarTema(config) {
    const body = document.body;
    const ids = id => document.getElementById(id);
    const qsa = sel => document.querySelectorAll(sel);

    const [tituloWeb, tituloDesk, tituloMob] = ["tituloWeb", "tituloDesktop", "tituloMobile"].map(ids);
    const [divWeb, fundoGradiente, minhaLogo, nav, linkLogin, footer, txtCreditos] =
        ["web", "fundoGradiente", "minhaLogo", "nav", "linkLogin", "footer", "txtCreditos"].map(ids);
    const [caixaWeb, desktop, mobile] = ["caixaWeb", "desktop", "mobile"].map(ids);
    const texto = ["textLittera", "descricaoD", "descricaoM", "descricaoW"].map(ids);

    const imgs = qsa("img");
    const btn = qsa(".button");
    const spt = qsa(".separator");
    const txtCont = qsa(".textContent");
    const navItems = qsa(".navItem");
    const pathMenu = qsa("path");

    body.classList.toggle('modoEscuro', config.modo === 'escuro');
    body.style.backgroundColor = config.bodyBg;
    nav.style.background = config.navBg;

    [tituloWeb, tituloDesk, tituloMob].forEach((el, i) => el.style.color = config.tituloColors[i]);
    txtCreditos.style.color = config.creditosColor;
    linkLogin.style.color = config.linkLogin.color;
    linkLogin.style.border = config.linkLogin.border;
    linkLogin.style.background = config.linkLogin.bg;

    divWeb.style.background = window.innerWidth < 600 ? config.webBgMobile : config.webBgDesktop;

    [caixaWeb, desktop, mobile].forEach((el, i) => el.style.background = config.divsBg[i]);
    footer.style.background = config.footerBg;

    fundoGradiente.style.backgroundImage = `url(${config.fundoBg})`;
    [imgs[7], imgs[3], imgs[6], minhaLogo].forEach((el, i) => el.setAttribute("src", config.logos[i]));
    //azul,  vermelha, roxa,  logo littera

    btn.forEach((b, i) => {
        b.style.background = "transparent";
        b.style.border = `1px solid ${config.btnConfig[i].border}`;
        spt[i].style.background = config.btnConfig[i].spt;
        txtCont[i].style.color = config.btnConfig[i].txt;
    });

    texto.forEach(el => el.style.color = config.textoColor);
    navItems.forEach(el => el.style.color = config.navItemColor);

    config.pathColors.forEach(conf => {
        for (let i = conf.from; i <= (conf.to ?? conf.from); i++) {
            if (conf.fill) pathMenu[i].style.fill = conf.fill;
            if (conf.stroke) pathMenu[i].style.stroke = conf.stroke;
            if (conf.d) pathMenu[i].setAttribute("d", conf.d);
        }
    });
}
//======================================FIM INDEX=================================================================================
//======================================ACERVOS===================================================================================
// =========================
// Temas do Acervo
// =========================
function acervoModoClaro() {
    aplicarTemaAcervo({
        modo: 'claro',
        bodyBg: "#fff",
        bodyColor: "#000",
        inputPesquisa: {
            bg: "linear-gradient(0deg, rgba(254, 254, 255, 0.5) 17%, rgba(155, 140, 219, 0.2) 100%)",
            color: "#000",
            border: "1px solid #2F2259"
        },
        acervoContent: {
            bg: "linear-gradient(0deg, rgba(254, 254, 255, 0.5) 17%, rgba(155, 140, 219, 0.2) 100%)",
            color: "#000"
        },
        tabAtiva: {
            bg: "linear-gradient(to top, rgb(240, 236, 255) 10%, rgb(72, 57, 125) 480%)",
            color: "#2F2259"
        },
        tabInativaColor: "#000",
        logo: "imagens/logoLittera.png",
        filtroTituloBg: "linear-gradient(130deg, rgba(228,219,255,1) 0%, rgba(184,164,249,0.5) 70%, rgba(94,84,142,0.95) 115%)",
        filtroOpcoesBg: "#F0ECFF",
        filtroTituloColor: "#2F2259",
        labelColor: "#000",
        iconColor: "#000",
        sumarioBg: "linear-gradient(130deg, rgba(228,219,255,1) 0%, rgba(184,164,249,0.5) 70%, rgba(94,84,142,0.95) 115%)",
        sumarioTextColor: "#2F2259",
        sumarioPathColor: "#2F2259"
    });
}

function acervoModoEscuro() {
    aplicarTemaAcervo({
        modo: 'escuro',
        bodyBg: "#070512",
        bodyColor: "#f0f8ff",
        inputPesquisa: {
            bg: "#070512",
            color: "#f0f8ff",
            border: "1px solid #c9baff"
        },
        acervoContent: {
            bg: "#12101fff",
            color: "#f0f8ff"
        },
        tabAtiva: {
            bg: "linear-gradient(23deg, rgb(29,21,60) 8%, rgb(48,37,89) 32%, rgb(72,57,125) 59%, rgb(94,84,142) 80%, rgb(122,106,200) 100%)",
            color: "#f0f8ff"
        },
        tabInativaColor: "#c9baff",
        logo: "imagens/logoEscWeb.png",
        filtroTituloBg: "linear-gradient(23deg, rgb(29,21,60) 8%, rgb(48,37,89) 32%, rgb(72,57,125) 59%, rgb(94,84,142) 80%, rgb(122,106,200) 100%)",
        filtroOpcoesBg: "#12101fff",
        filtroTituloColor: "#f0f8ff",
        labelColor: "#f0f8ff",
        iconColor: "#c9baff",
        sumarioBg: "linear-gradient(23deg, rgb(29,21,60) 8%, rgb(48,37,89) 32%, rgb(72,57,125) 59%, rgb(94,84,142) 80%, rgb(122,106,200) 100%)",
        sumarioTextColor: "#c9baff",
        sumarioPathColor: "#c9baff"
    });
}

// =========================
// Função genérica de tema do Acervo
// =========================
function aplicarTemaAcervo(config) {
    const body = document.body;
    const icons = document.querySelectorAll("path");
    const inputPesquisa = document.querySelector(".barra-pesquisa");
    const acervoContent = document.querySelector(".acervo-content");
    const filtroTitulo = document.querySelectorAll(".fltro-titulo");
    const filtroOpcoes = document.querySelectorAll(".fltro-opcoes");
    const labels = document.querySelectorAll(".fltro-opcoes label");
    const logo1 = document.querySelectorAll("img")[0];
    const logoMobile = document.querySelector(".logomobile");
    const pathname = window.location.pathname.toLowerCase();

    const tabAtiva = pathname.includes("acervo.php")
        ? document.querySelectorAll(".tab")[0]
        : document.querySelectorAll(".tab")[1];
    const tabInativa = pathname.includes("acervo.php")
        ? document.querySelectorAll(".tab")[1]
        : document.querySelectorAll(".tab")[0];

    const sumario1 = document.getElementById('sumario') || document.querySelector('.sumario');
    const sumario2 = document.getElementById('sumario2') || document.querySelector('.sumario2');
    const divCheckboxs = document.querySelectorAll('.div_Checkboxs, .div_Checkboxs1');

    // Aplicar tema
    body.classList.toggle("modoEscuro", config.modo === "escuro");
    body.style.backgroundColor = config.bodyBg;
    body.style.color = config.bodyColor;

    // Logo
    logo1.setAttribute("src", config.logo);
    if (logoMobile) logoMobile.setAttribute("src", config.logo);

    // Input
    Object.assign(inputPesquisa.style, {
        background: config.inputPesquisa.bg,
        color: config.inputPesquisa.color,
        border: config.inputPesquisa.border
    });

    // Conteúdo
    Object.assign(acervoContent.style, {
        background: config.acervoContent.bg,
        color: config.acervoContent.color
    });

    // Tabs
    Object.assign(tabAtiva.style, {
        background: config.tabAtiva.bg,
        color: config.tabAtiva.color
    });
    tabInativa.style.color = config.tabInativaColor;

    // Filtros
    for (let i = 0; i < filtroTitulo.length; i++) {
        filtroTitulo[i].style.background = config.filtroTituloBg;
        filtroTitulo[i].style.color = config.filtroTituloColor;
        filtroOpcoes[i].style.background = config.filtroOpcoesBg;
        filtroOpcoes[i].style.color = config.labelColor;
    }

    // Labels
    labels.forEach(lab => lab.style.color = config.labelColor);

    // Ícones
    icons.forEach((icon, i) => {
        if (i <= 1) icon.style.fill = config.iconColor;
    });

    // Sumários
    [sumario1, sumario2].forEach(sumario => {
        if (!sumario) return;
        sumario.style.background = config.sumarioBg;
        const divs = sumario.querySelectorAll('div');
        divs.forEach((d, i) => {
            if (i < divs.length - 2) d.style.background = config.sumarioBg;
        });
        const p = sumario.querySelector("p");
        if (p) p.style.color = config.sumarioTextColor;
        const paths = sumario.querySelectorAll("path");
        paths.forEach(p => p.style.stroke = config.sumarioPathColor);
    });

    // Checkboxes
    divCheckboxs.forEach(el => {
        el.querySelectorAll('label').forEach(lab => lab.style.color = config.labelColor);
    });
}
//======================================FIM ACERVOS===========================================================================================