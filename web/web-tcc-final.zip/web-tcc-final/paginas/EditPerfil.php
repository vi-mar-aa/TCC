<?php
session_start();

$serverName = "LAB21T-Prof\SQLEXPRESS";
$database = "Littera";
$username = "sa";
$password = "etesp";

$email = $_SESSION['email_cli'];
$imagem_base64 = "";

try {
    $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $conn->prepare("SELECT imagem_perfil FROM Cliente WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row && $row['imagem_perfil']) {
        $tipoImagem = "image/png"; 
        $imagem_base64 = "data:$tipoImagem;base64," . base64_encode($row['imagem_perfil']);
    }
} catch (PDOException $e) {
    echo "Erro ao carregar imagem: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/button.css">
    <link rel="stylesheet" href="../CSS/Geral.css">
    <link rel="stylesheet" href="../CSS/nav.css">
    <link rel="stylesheet" href="../CSS/perfil.css">
    <script src="../paginas/js/modoEscuroGeral.js" defer></script>
    <title>Editar Perfil</title>

</head>

<body id="homeBody">


    <header>
        <div id="logo">
            <img src="../paginas/imagens/logoLittera.png" alt="logo Littera" id="minhaLogo" onclick="window.location.replace('index.html')">
        </div>

        <nav class="navBar" style="background-color: transparent;">
        </nav>
    </header>

    <main>
        <div class="form-container">
            <div class="perfil-section">

                <!-- SVG com máscara circular e path -->
                <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200" fill="none">

                    <defs>
                        <clipPath id="circleView">
                            <circle cx="100" cy="100" r="100" fill="none" stroke="#000" stroke-width="2" />
                        </clipPath>
                    </defs>
                    <image id="userImage"
       x="0" y="0"
       width="200" height="200"
       preserveAspectRatio="xMidYMid slice"
       clip-path="url(#circleView)"
       href="<?php echo $imagem_base64; ?>" />
                    <circle cx="100" cy="100" r="100" fill="none" stroke="#000" stroke-width="2" />


                    <!-- Path com ajustes de escala e translação -->
                    <path id="purpleCircle" fill-rule="evenodd" clip-rule="evenodd"
                        d="M82.7431 4.35014C62.7813 9.72754 47.0616 19.4962 31.1228 36.4283C-11.4799 81.6883 -9.57513 149.869 35.4879 192.688C62.4092 218.266 95.3375 228.73 130.127 222.764C154.043 218.663 170.882 210.089 189.199 192.688C224.424 159.221 234.164 107.121 213.307 63.7673C205.579 47.7036 184.008 24.4106 168.356 15.2282C143.953 0.914959 111.03 -3.26807 82.7431 4.35014ZM146.2 15.4528C164.123 21.7096 185.015 37.6089 195.54 53.0015C218.466 86.5206 221.277 122.357 203.8 158.24C197.128 171.94 174.919 197.307 169.599 197.307C168.211 197.307 167.078 189.683 167.078 180.361C167.078 166.735 165.912 162.177 161.129 157.076C155.403 150.978 153.562 150.737 112.727 150.737C72.91 150.737 69.8832 151.107 63.9417 156.693C58.616 161.703 57.6089 165.407 57.6089 179.977C57.6089 189.508 56.4896 197.307 55.124 197.307C53.7556 197.307 47.1984 192.014 40.5509 185.546C17.5869 163.207 5.43858 126.688 10.9695 96.6344C22.7895 32.4343 86.0573 -5.54998 146.2 15.4528ZM91.3884 63.2304C86.3556 66.4601 80.8438 73.5332 78.1892 80.1789C63.6817 116.47 106.799 146.968 136.843 121.664C154.618 106.693 152.658 74.7084 133.239 62.8551C121.796 55.8697 102.598 56.0422 91.3884 63.2304ZM124.155 68.8762C150.329 82.2745 141.577 120.604 112.344 120.604C84.4015 120.604 73.8241 83.2415 98.0442 70.087C107.064 65.1863 116.126 64.7672 124.155 68.8762ZM154.569 163.259C157.639 166.335 158.868 172.923 158.868 186.324V205.084L144.5 209.921C126.134 216.107 98.5532 216.107 80.187 209.921L65.8191 205.084V187.028C65.8191 159.563 66.8317 158.955 112.573 158.955C143.192 158.955 151.074 159.763 154.569 163.259Z"
                        fill="#573280"
                        transform="scale(0.9) translate(0.01, 0.01)" />
                </svg>

                <!-- Botão de upload -->
				
                <button class="upload-button" type="button" id="uploadButton">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                    </svg>
                    <p>Foto de perfil</p>
                </button>
            </div>
            <div class="alteracoes-section">
                <form class="form-coluna" action="atualizarPerfil.php" method="post">
				
				
				
				
					<input type="hidden" name="imagem_base64" id="imagem_base64">
					
					
					
					
					
					
                    <div class="form-lacuna">
                        <label for="email" class="form-label">Email</label>
                        <input name="email" id="email" type="email" class="form-input" placeholder="<?php echo $_SESSION['email_cli']; ?>" disabled="" />
                    </div>
                    <div class="form-lacuna">
                        <label for="cpf" class="form-label">CPF</label>
                        <input name="cpf" id="cpf" type="text" class="form-input" placeholder="<?php echo $_SESSION['cpf_cli']; ?>" disabled="" />
                    </div>
                    <div class="form-lacuna">
                        <label for="fone" class="form-label">Telefone</label>
                        <input name="fone" id="telefone" type="text" class="form-input" placeholder="(11)11111-1111" />
                    </div>
                    <div class="form-lacuna">
                        <label for="name" class="form-label">Nome</label>
                        <input name="name" id="name" type="text" class="form-input" placeholder="Fulano Silva" />
                    </div>
                    <div class="form-lacuna">
                        <label for="user" class="form-label">Usuário</label>
                        <input name="user" id="user" type="text" class="form-input" placeholder="Fulaninho02" />
                    </div>

                    <div class="form-lacuna">
                        <label for="senhaAnterior" class="form-label">Senha anterior</label>
                        <input name="senha" id="senha" type="password" class="form-input" />
                    </div>

                    <div class="form-lacuna">
                        <label for="novaSenha" class="form-label">Nova senha</label>
                        <input name="nova_senha" id="nova_senha" type="password" class="form-input" />
                    </div>
            </div>

            <div class="button-container" style="flex-direction: row;">
                <a href="Home.html" style="text-decoration: none; margin-rigth:4vw">
                    <button type="submit" name="submit" class="button button-outline" onclick="cancelar()" value="cancelar"
                        style="border: solid 1px #573280; color: #573280;background: linear-gradient(0deg, rgba(254, 254, 255, 0.5) 17%, rgba(155, 140, 219, 0.2) 100%);border-radius: 30px;">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" syle="margin:auto 0">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                        <div
                            style="border-left:solid 1px #573280; height: 100%; display: flex; text-align: right; align-items: center;  padding-left: 10px;">
                            <p>Cancelar</p>
                        </div>
                    </button>
                </a>


                <button type="submit" name="submit" class="button button-primary" id="button-save" onclick="salvar()" value="nada"
                    style="border: solid 1px #573280;color: #573280;background: linear-gradient(0deg, rgba(254, 254, 255, 0.5) 17%, rgba(155, 140, 219, 0.2) 100%);border-radius: 30px;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" viewBox="0 0 29 29" fill="none">
                        <path d="M28.6496 6.3921L22.6079 0.350437C22.495 0.238447 22.3611 0.149845 22.2139 0.0897132C22.0667 0.029581 21.909 -0.000899215 21.75 2.01964e-05H2.41666C1.77573 2.01964e-05 1.16104 0.254632 0.707825 0.707845C0.254612 1.16106 0 1.77575 0 2.41669V26.5833C0 27.2243 0.254612 27.839 0.707825 28.2922C1.16104 28.7454 1.77573 29 2.41666 29H26.5833C27.2243 29 27.8389 28.7454 28.2922 28.2922C28.7454 27.839 29 27.2243 29 26.5833V7.25001C29.0009 7.09099 28.9704 6.93335 28.9103 6.78613C28.8502 6.63891 28.7616 6.50501 28.6496 6.3921ZM9.66666 2.41669H19.3333V7.25001H9.66666V2.41669ZM19.3333 26.5833H9.66666V16.9167H19.3333V26.5833ZM21.75 26.5833V16.9167C21.75 16.2757 21.4954 15.661 21.0422 15.2078C20.5889 14.7546 19.9743 14.5 19.3333 14.5H9.66666C9.02572 14.5 8.41103 14.7546 7.95782 15.2078C7.50461 15.661 7.24999 16.2757 7.24999 16.9167V26.5833H2.41666V2.41669H7.24999V7.25001C7.24999 7.89095 7.50461 8.50564 7.95782 8.95885C8.41103 9.41207 9.02572 9.66668 9.66666 9.66668H19.3333C19.9743 9.66668 20.5889 9.41207 21.0422 8.95885C21.4954 8.50564 21.75 7.89095 21.75 7.25001V2.9121L26.5833 7.74543V26.5833H21.75Z" fill="#573280" />
                    </svg>
                    <div
                        style="border-left:solid 1px #573280; height: 100%; justify-content:center; display: flex; align-items: center; padding-left: 10px; width: 67px;"><p>
                        Salvar</p></div>
                </button>

                </form>

            </div>

            <script>
			document.addEventListener("DOMContentLoaded", function () {
        const img = document.getElementById('userImage');
        const purpleCircle = document.getElementById('purpleCircle');

        if (img.getAttribute('href') && img.getAttribute('href') !== "") {
            purpleCircle.style.display = 'none';
        }
    });
			
			
			
                const button = document.getElementById('uploadButton');
                const img = document.getElementById('userImage');
                const purpleCircle = document.getElementById('purpleCircle'); // pegando o path roxo

                button.addEventListener('click', function() {
                    const input = document.createElement('input');
                    input.type = 'file';
                    input.accept = 'image/*';
					
					
					
					

                    input.onchange = function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const base64 = e.target.result;

            // Atualiza a imagem no SVG
            img.setAttribute('href', base64);

            // Esconde o círculo roxo
            purpleCircle.style.display = 'none';

            // Define o valor no input hidden
            document.getElementById('imagem_base64').value = base64;
        };
        reader.readAsDataURL(file);
    }
};





                    input.click(); // Simula clique no input escondido
                });
            </script>

            <script>
                function cancelar() {
                    // Limpar todos os campos
                    document.getElementById('email').value = '';
                    document.getElementById('telefone').value = '';
                    document.getElementById('senha').value = '';
                    document.getElementById('nova_senha').value = '';
                    console.log('Formulário cancelado e limpo');
                }

                function salvar() {
                    // Coletar dados do formulário
                    const dados = {
                        email: document.getElementById('email').value,
                        usuario: document.getElementById('telefone').value,
                        senha: document.getElementById('senha').value,
                        senha2: document.getElementById('senha2').value
                    };


                    console.log('Dados salvos:', dados);
                    alert('Dados salvos com sucesso!');
                }
            </script>

            <script>
                // Seleciona as divs internas dentro dos botões .button.button-outline e .button.button-primary
                document.addEventListener('DOMContentLoaded', function () {
                    try {
                        // encontra os botões pelo seletor composto
                        const btnOutline = document.querySelector('.button.button-outline');
                        const btnPrimary = document.querySelector('.button.button-primary');

                        // seleciona as divs internas (se existirem)
                        const innerDivsOutline = btnOutline ? btnOutline.querySelectorAll('div') : [];
                        const innerDivsPrimary = btnPrimary ? btnPrimary.querySelectorAll('div') : [];

                        console.log('innerDivsOutline count:', innerDivsOutline.length, innerDivsOutline);
                        console.log('innerDivsPrimary count:', innerDivsPrimary.length, innerDivsPrimary);

                        // aplicar um destaque visual temporário para verificação
                        innerDivsOutline.forEach(d => {
                            d.style.outline = '2px dashed #573280';
                            d.style.transition = 'outline 0.2s ease-in-out';
                        });
                        innerDivsPrimary.forEach(d => {
                            d.style.outline = '2px dashed #2F2259';
                            d.style.transition = 'outline 0.2s ease-in-out';
                        });

                        // Se quiser, remover o destaque após 3s
                        setTimeout(() => {
                            innerDivsOutline.forEach(d => d.style.outline = '');
                            innerDivsPrimary.forEach(d => d.style.outline = '');
                        }, 3000);

                    } catch (err) {
                        console.error('Erro ao selecionar divs internas dos botões:', err);
                    }
                });
            </script>

    </main>
</body>

</html>