<?php
session_start();
$_SESSION['diretriz'] = true; // marca como aceito
echo json_encode(['status' => 'ok']);
?>