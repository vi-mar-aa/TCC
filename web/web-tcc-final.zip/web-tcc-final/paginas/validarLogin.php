<?php
session_start();

$_SESSION['diretriz'] = false;

if ($_SERVER['REQUEST_METHOD']=='POST') {
    
    $email = $_POST['email'];
    $senha = $_POST['senha'];
	
//$serverName = "LAB02H-00"; // ou IP do servidor SQL
$serverName ="LAB21T-Prof\SQLEXPRESS";
$database = "Littera";
$username = "sa";
$password = "etesp";

try {
	
    $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Preparar a chamada da procedure
    $stmt = $conn->prepare("EXEC sp_LoginCliente @email = :email, @senha = :senha");
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':senha', $senha);
    $stmt->execute();

	
	// Recupera os dados
	$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
	if ($result){
		
		$stmt = $conn->prepare("select * from Cliente where email ='".$email."';" );
		$stmt->execute();
		$result1 = $stmt->fetchAll(PDO::FETCH_ASSOC);
			
		foreach ($result1 as $dado)
		{
			$_SESSION['id_cli'] = $dado['id_cliente'];
			$_SESSION['email_cli'] = $dado['email'];
			$_SESSION['cpf_cli'] = $dado['cpf'];
			header('Location: \web-tcc-final\paginas\Home.html');
			exit;
		}
    }
	else
	{
		echo "<script>alert('Usuário ou Senha Incorretos'); window.location.href='Login.html';</script>";
	}
	
} catch (PDOException $e) {
	echo "<script>alert('Usuário ou Senha Incorretos'); window.location.href='Login.html';</script>";
    echo "Erro na conexão ou execução: " . $e->getMessage();
}

}


?>