<?php 
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_SESSION['email_cli'];
    $fone = $_POST['fone'];
    $name = $_POST['name'];
    $user = $_POST['user'];    
    $senha = $_POST['senha'];
    $nova_senha = $_POST['nova_senha'];
    $imagem_base64 = $_POST['imagem_base64'];
    $submit = $_POST['submit'];
    $status = 'ativo';

    if ($submit == "cancelar") {
        echo "<script>alert('Atualizações canceladas'); window.location.href='Home.html';</script>";
        return;
    }

    if ($senha == $nova_senha) {
        echo "<script>alert('As senhas são iguais!'); history.back();</script>";
        exit;
    }


    $serverName = "LAB21T-Prof\\SQLEXPRESS";
    $database = "Littera";
    $username = "sa";
    $password = "etesp";

    try {
        $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Atualizar perfil
        $stmt = $conn->prepare("EXEC sp_AtualizarPerfilCliente :name, :user, :email, :nova_senha, :fone, :imagem_base64");
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':user', $user);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':nova_senha', $nova_senha);
        $stmt->bindParam(':fone', $fone);
		$stmt->bindParam(':imagem_base64', $imagem_base64);
        $stmt->execute();

        // Se imagem foi enviada, atualiza também
        if (!empty($imagem_base64)) {
            // Remove o prefixo "data:image/...;base64," se existir
            if (str_contains($imagem_base64, 'base64,')) {
                $imagem_base64 = explode(',', $imagem_base64)[1];
            }

            $stmt1 = $conn->prepare("EXEC sp_AtualizarImagemCliente :email, :imagem_base64");
            $stmt1->bindParam(':email', $email);
            $stmt1->bindParam(':imagem_base64', $imagem_base64, PDO::PARAM_STR);
            $stmt1->execute();
        }

        echo "<script>alert('Alterações feitas com sucesso!'); window.location.href='Home.html';</script>";

    } catch (PDOException $e) {
        echo "Erro no cadastro: " . $e->getMessage();
    }
}
?>
