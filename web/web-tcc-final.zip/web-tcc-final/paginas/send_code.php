<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('Método não permitido');
}

$email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);

if (!$email) {
    die('Email inválido');
}

// Gerar código de 6 dígitos
$code = sprintf('%06d', mt_rand(0, 999999));

// Salvar código e email na sessão (em produção, use banco de dados)
$_SESSION['recovery_email'] = $email;
$_SESSION['recovery_code'] = $code;
$_SESSION['recovery_time'] = time();

try {
    $mail = new PHPMailer(true);

    // Configurações do servidor
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'andielars2007@gmail.com';
    $mail->Password   = 'bidthzgmkciuhtaj';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // Configurações do remetente e destinatário
    $mail->setFrom('andielars2007@gmail.com', 'Sistema de Recuperação');
    $mail->addAddress($email);

    // Configurações do email
    $mail->isHTML(true);
    $mail->Subject = 'Código de Recuperação de Senha';
    $mail->CharSet = 'UTF-8';
    
    // Template do email
    $mail->Body = "
    <html>
    <head>
        <style>
            .container { 
                font-family: Arial, sans-serif; 
                max-width: 600px; 
                margin: 0 auto; 
                padding: 20px; 
                background-color: #573280; 
            }
            .header { 
                background-color; #573280; 
                color: white; 
                padding: 30px; 
                text-align: center; 
                border-radius: 10px 10px 0 0; 
            }
            .content { 
                background: white; 
                padding: 30px; 
                border-radius: 0 0 10px 10px; 
            }
            .code { 
                background: #f8f9fa; 
                border: 2px dashed #F0ECFF; 
                padding: 20px; 
                text-align: center; 
                font-size: 32px; 
                font-weight: bold; 
                color: #F0ECFF; 
                letter-spacing: 8px; 
                margin: 20px 0; 
                border-radius: 10px; 
            }
            .warning { 
                background: #573280; 
                border: 1px solid #ffeaa7; 
                padding: 15px; 
                border-radius: 5px; 
                color: #F0ECFF; 
                margin-top: 20px; 
            }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>Recuperação de Senha</h1>
                <p>Código de verificação solicitado</p>
            </div>
            <div class='content'>
                <h2>Olá!</h2>
                <p>Você solicitou um código para recuperar sua senha. Use o seguinte código abaixo:</p>
                
                <div class='code'>$code</div>
                
                <p><strong>Instruções:</strong></p>
                <ul>
                    <li>Digite este código na tela de recuperação</li>
                    <li>O código é válido por 15 minutos</li>
                    <li>Use apenas números, sem espaços</li>
                </ul>
                
                <div class='warning'>
                    <strong> Importante:</strong> Se você não solicitou este código, ignore este email. 
                    Nunca compartilhe este código com outras pessoas.
                </div>
                
                <p style='margin-top: 30px; color: #666; font-size: 14px;'>
                    Este é um email automático, não responda.
                </p>
            </div>
        </div>
    </body>
    </html>";

    // Versão texto alternativa
    $mail->AltBody = "Seu código de recuperação é: $code\n\nO código é válido por 15 minutos.\n\nSe você não solicitou este código, ignore este email.";

    $mail->send();
	
	
	
    echo 'Código enviado com sucesso para seu email!';
    
} catch (Exception $e) {
    error_log("Erro no PHPMailer: " . $mail->ErrorInfo);
    echo 'Erro ao enviar email. Tente novamente mais tarde.';
}
?>