<?php
	
//$serverName = "LAB02H-00"; // ou IP do servidor SQL
$serverName ="LAB21T-Prof\SQLEXPRESS";
$database = "Littera";
$username = "sa";
$password = "etesp";

try {
	
    $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	if(isset($_GET['id'])){

	$id=$_GET['id'];
	$stmt = $conn->prepare("select imagem from Midia where id_midia=:id;");
	$stmt->bindParam(':id', $id);
	$stmt->execute();
	if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		header("Content-Type:image/jpeg");
	echo $row['imagem'];
	}else{
		http_response_code(404);
		echo"imagem não encontrada";
	}
	}else{
		echo "ID não fornecido";
	}
}catch (PDOException $e) {
    echo "Erro:" . $e->getMessage();

}


?>