<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$name = $_POST['name'];
    $nome = $_POST['nome'];
	$fone = $_POST['fone'];
	$cpf = $_POST['cpf'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $confirmar_senha = $_POST['confirmar_senha'];
    $status = 'ativo';

    if ($senha !== $confirmar_senha) {
        echo "<script>alert('As senhas não coincidem!'); history.back();</script>";
        exit;
    }


    //$serverName = "LAB02H-00";
	$serverName ="LAB21T-Prof\SQLEXPRESS";
    $database = "Littera";
    $username = "sa";
    $password = "etesp";

    try {
        $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Verifica se o e-mail já existe
        $verifica = $conn->prepare("SELECT * FROM Cliente WHERE email = :email");
        $verifica->bindParam(':email', $email);
        $verifica->execute();

        if ($verifica->fetch()) {
            echo "<script>alert('E-mail já cadastrado!'); history.back();</script>";
            exit;
        }

        $stmt = $conn->prepare("EXEC sp_CadastrarCliente 
            @nome = :name,
			@username = :nome,
            @cpf = :cpf,
            @email = :email,
            @telefone = :fone,
            @senha = :senha,
            @status_conta = :status");
			
		$stmt->bindParam(':name', $name);
        $stmt->bindParam(':nome', $nome);
		$stmt->bindParam(':cpf', $cpf);
		$stmt->bindParam(':fone', $fone);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':senha', $senha); 
        $stmt->bindParam(':status', $status);
        $stmt->execute();

        echo "<script>alert('Cadastro realizado com sucesso!'); window.location.href='Login.html';</script>";
    } catch (PDOException $e) {
        echo "Erro no cadastro: " . $e->getMessage();
    }
}
?>
