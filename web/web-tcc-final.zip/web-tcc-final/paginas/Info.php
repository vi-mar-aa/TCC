<?php
//$serverName = "LAB02H-00"; // ou IP do servidor SQL LAB21T-Prof\SQLEXPRESS
$serverName ="LAB21T-Prof\SQLEXPRESS";
$database = "Littera";
$username = "sa";
$password = "etesp";

try {


    if ($_GET) {
        $id = $_GET['id'];

        $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Preparar a chamada da procedure
        $stmt = $conn->prepare("select * from Midia where id_midia=" . $id);
        $stmt->execute();

        //Recupera os dados
        $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);


        foreach ($produtos as $midia) {

            $isbn = $midia['isbn'];
            $titulo = $midia['titulo'];
            $genero_atual = $midia['genero'];
        }

        $stmt1 = $conn->prepare("EXEC sp_AcervoMidiasTodasInfosComExemplares");


        $stmt1->execute();

        $result = $stmt1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($result as $exemplares) {

            $total_exemplares = $exemplares['total_exemplares'];
        }
        
        // Busca similares pelo mesmo gênero (exclui a mídia atual)
        // Tornamos a comparação mais tolerante: case-insensitive e permite correspondência parcial
        try {
            // Usa a coluna correta (status_midia) — no script do banco esta coluna indica se a mídia é 'publica' ou 'privada'
            // Faz comparação insensível a maiúsculas/minúsculas e a acentos usando COLLATE e usa LIKE com o parâmetro já contendo '%'
            $query = "SELECT TOP 12 id_midia, titulo, autor FROM Midia WHERE status_midia = 'publica' AND id_midia <> :id_midia AND genero IS NOT NULL AND genero <> '' AND (genero COLLATE Latin1_General_CI_AI = :genero_collate OR genero COLLATE Latin1_General_CI_AI LIKE :genero_like) ORDER BY NEWID()";
            $stmt_similares = $conn->prepare($query);
            // preparar valores: genero exato e genero para like (com %)
            $genero_exato = $genero_atual;
            $genero_like = '%' . $genero_atual . '%';

            $stmt_similares->bindValue(':genero_collate', $genero_exato, PDO::PARAM_STR);
            $stmt_similares->bindValue(':genero_like', $genero_like, PDO::PARAM_STR);
            $stmt_similares->bindValue(':id_midia', $id, PDO::PARAM_INT);
            $stmt_similares->execute();
            $similares = $stmt_similares->fetchAll(PDO::FETCH_ASSOC);

            // Se não encontrou similares, coletar uma amostra dos gêneros existentes para ajudar no debug
            if (empty($similares)) {
                try {
                    $stmt_gen = $conn->prepare("SELECT DISTINCT genero FROM Midia WHERE genero IS NOT NULL AND genero <> '' ORDER BY genero");
                    $stmt_gen->execute();
                    $generos_disponiveis = $stmt_gen->fetchAll(PDO::FETCH_COLUMN);
                } catch (PDOException $ex) {
                    $generos_disponiveis = [];
                }
            } else {
                $generos_disponiveis = [];
            }
        } catch (PDOException $e) {
            // se der erro, registra no log do PHP e retorna lista vazia
            error_log('Erro ao buscar similares: ' . $e->getMessage());
            $similares = [];
            $generos_disponiveis = [];
        }
    }
} catch (PDOException $e) {
    echo "Erro na conexão ou execução: " . $e->getMessage();
}


?>



<!DOCTYPE html>

<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Littera - Detalhes do Livro</title>
    <link rel="stylesheet" href="../CSS/info.css">

</head>

<body>
    <div class="cabecalho">
        <a href="Index.html"><img src="../paginas/imagens/logoLittera.png" class="logo" /></a>

    </div>


    <?php


    foreach ($produtos as $dado) {
    ?>

        <div class="container">
            <div class="painel-superior">
                <div class="capa-livro">
                    <?php echo '<img src="exibirImagem.php?id=' . $dado['id_midia'] . '"alt="">'; ?>
                </div>
                <div class="informacoes">
                    <div class="informacoes-titulo">Informações</div>
                    <div class="informacoes-lista">
                        <div><strong>Título:</strong> <?php echo $dado['titulo']; ?></div>
                        <div><strong>Autor:</strong> <?php echo $dado['autor']; ?></div>
                        <div><strong>Local de publicação:</strong> <?php echo $dado['local_publicacao']; ?></div>
                        <div><strong>Número de páginas:</strong> <?php echo $dado['numero_paginas']; ?></div>
                        <div><strong>Ano de lançamento:</strong> <?php echo $dado['ano_publicacao']; ?></div>
                        <div><strong>Editora:</strong> <?php echo $dado['editora']; ?></div>
                        <div><strong>ISBN:</strong> <?php echo $dado['isbn']; ?></div>
                        <div><strong>Gênero:</strong> <?php echo $dado['genero']; ?></div>
                        <div><strong>Edição:</strong> <?php echo $dado['edicao']; ?></div>
                    </div>
                </div>
                <div class="disponibilidade">
                    <div class="disponibilidade-titulo">Disponibilidade</div>



                    <div class="disponibilidade-numero"><?php echo $total_exemplares ?></div>

                    <div class="disponibilidade-texto">exemplares<br>disponíveis</div>
                    <div class="disponibilidade-info">
                        Para realizar uma reserva faça o <span class="download">download</span> do nosso aplicativo mobile!
                    </div>
                </div>
            </div>
            <div class="painel-sinopse">
                <div class="sinopse-titulo">Sinopse</div>
                <div class="sinopse-texto">
                    <?php echo $dado['sinopse']; ?>
                </div>
            </div>
            <div class="similares-titulo">Títulos Similares</div>

            <div class="similares-carousel">
                <button id="prevBtn" class="similares-seta">
                    < </button>
                        <div class="carrossel" id="carrossel" style="display: flex; gap: 18px;"></div>
                        <button id="nextBtn" class="similares-seta">></button>
            </div>
        </div>

        <script defer>
            // carrega os itens similares (servidor já buscou por mesmo gênero)
            const cartasOriginais = <?php
                // transforma $similares (php) em estrutura JS amigável
                $cartas_js = [];
                if (isset($similares) && is_array($similares)) {
                    foreach ($similares as $s) {
                        $cartas_js[] = [
                            'titulo' => $s['titulo'],
                            'autor' => $s['autor'],
                            'image' => 'exibirImagem.php?id=' . $s['id_midia'],
                            'id' => $s['id_midia']
                        ];
                    }
                }
                echo json_encode($cartas_js, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            ?>;

            // DEBUG: informa no console o gênero atual, os similares carregados e gêneros disponíveis (se nenhum similar)
            (function(){
                try {
                    const generoAtual = "<?php echo isset($genero_atual) ? addslashes($genero_atual) : ''; ?>";
                    console.log('Info.php: gênero atual =', generoAtual);
                    console.log('Info.php: similares carregados (count) =', cartasOriginais.length);
                    if (cartasOriginais.length > 0) {
                        console.log('Info.php: títulos similares =', cartasOriginais.map(c => c.titulo));
                    } else {
                        // lista de gêneros distintos do banco (apenas para debug)
                        const generosDisponiveis = <?php echo json_encode(isset($generos_disponiveis) ? $generos_disponiveis : [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
                        console.log('Info.php: nenhum similar encontrado. gêneros disponíveis (amostra) =', generosDisponiveis.slice(0,30));
                    }
                } catch (e) {
                    console.warn('Erro ao logar similares:', e);
                }
            })();

            const carrossel = document.getElementById("carrossel");
            const prevBtn = document.getElementById("prevBtn");
            const nextBtn = document.getElementById("nextBtn");
            const body = document.body;
            const modo = localStorage.getItem("modo");
            let posicao = 0;
            const cartasPorTela = 4;
            const total = cartasOriginais.length || 0;
            const capaLivroImg = document.querySelector(".capa-livro img"); 
            const capaSrc = capaLivroImg ? capaLivroImg.getAttribute("src") : ""; 

            window.addEventListener('resize', function() {
                if(window.innerWidth <600){
                    renderizar(2);
                }else if(window.innerWidth <1000){
                    renderizar(3)
                }else{
                    renderizar(4);
                }

                if(modo === "escuro"){
                    infoModoEscuro();
                }else{
                    infoModoClaro();
                }
            });

            window.addEventListener("DOMContentLoaded", () => {
                const modo = localStorage.getItem("modo") || "claro"; // padrão claro

                if (modo === "escuro") {
                    body.classList.add("modoEscuro");
                    infoModoEscuro(); // chama sempre
                } else {
                    body.classList.remove("modoEscuro");
                    infoModoClaro(); // chama sempre
                }

                if(window.innerWidth <600){
                    renderizar(2);
                }else if(window.innerWidth <1000){
                    renderizar(3)
                }else{
                    renderizar(4);
                }
            });


            function infoModoClaro() {

                const logo1 = document.querySelectorAll("img")[0];
                const divsPainelSup = document.querySelector(".painel-superior").querySelectorAll("div");
                const painelSin = document.querySelector(".painel-sinopse");
                const divsPainelSin = painelSin.querySelectorAll("div");
                const sinTitulo = document.querySelector(".sinopse-titulo");
                const simTitulo = document.querySelector(".similares-titulo");
                const disNumero = document.querySelector(".disponibilidade-numero");

                body.style.background = "radial-gradient(circle at 50% 20%, #ede9f7 60%, #d6cbe7 100%);";
                body.style.color = "#000";
                logo1.setAttribute("src", "imagens/logoLittera.png");
                painelSin.style.background = "#fff";
                sinTitulo.style.color = "#2F2259";
                simTitulo.style.color = "#2F2259";
                disNumero.style.color = "#2F2259";

                divsPainelSup.forEach(div => {
                    div.style.background = "#fff";
                    if (["Informações", "Disponibilidade"].includes(div.innerText)) {
                        div.style.color = "#2F2259";
                    }
                });

                divsPainelSin.forEach(div => {
                    div.style.background = "#fff";
                    if (div.innerText === "Sinnopse") {
                        div.style.color = "#2F2259";
                    }
                });

            }

            function infoModoEscuro() {
                const logo1 = document.querySelectorAll("img")[0];
                const painelSup = document.querySelector(".painel-superior");
                const divsPainelSup = document.querySelector(".painel-superior").querySelectorAll("div");
                const painelSin = document.querySelector(".painel-sinopse");
                const divsPainelSin = painelSin.querySelectorAll("div");
                const sinTitulo = document.querySelector(".sinopse-titulo");
                const simTitulo = document.querySelector(".similares-titulo");
                const disNumero = document.querySelector(".disponibilidade-numero");


                body.style.background = "#070512";
                body.style.color = "#f0f8ff";
                logo1.setAttribute("src", "imagens/logoEscWeb.png");
                painelSin.style.background = "#12101fff";
                sinTitulo.style.color = "#C9BAFF";
                simTitulo.style.color = "#C9BAFF";
                disNumero.style.color = "#C9BAFF";
                if(window.innerWidth < 800){
                    painelSup.style.background ="rgb(7, 5, 18)";
                }

                divsPainelSup.forEach(div => {
                    div.style.background = "#12101fff";
                    if (["Informações", "Disponibilidade"].includes(div.innerText)) {
                        div.style.color = "#C9BAFF";
                    }
                });

                divsPainelSin.forEach(div => {
                    div.style.background = "#12101fff";
                    if (div.innerText === "Sinnopse") {
                        div.style.color = "#C9BAFF";
                    }
                });
            }

            function renderizar(cartasPorTela) {
                carrossel.innerHTML = "";

                if (total === 0) {
                    carrossel.innerHTML = '<div class="sem-similares" style="padding:16px;color:#666">Nenhum título similar encontrado</div>';
                    return;
                }

                for (let i = posicao; i < posicao + cartasPorTela; i++) {
                    const index = i % total;
                    const carta = cartasOriginais[index];

                    const div = document.createElement("div");
                    div.className = "similares-cartao";
                    const imageSrc = carta.image || capaSrc;
                    div.style.backgroundImage = `url('${imageSrc}')`;
                    div.style.backgroundSize = "60% 60%";
                    div.style.backgroundRepeat="no-repeat"
                    div.style.backgroundPosition="center 10%"
                    

                    if(cartasPorTela === 4){
                        div.style.height = "350px"
                        div.style.backgroundSize = "60% 60%";
                    }else{
                        div.style.height = "250px"
                        div.style.backgroundSize = "60% 55%";
                    }

                    

                    div.innerHTML = `
            <div class="similares-info" style="background: ${modo === 'escuro' ? '#12101fff' : '#F0ECFF'};">
                <strong>${carta.titulo}</strong>
                <span>${carta.autor}</span>
                <a href="Info.php?id=${carta.id}">+ Informações</a>
            </div>

            
        `;

                    carrossel.appendChild(div);
                }


            }


            nextBtn.addEventListener("click", () => {
                if (total === 0) return;
                posicao++;
                if(window.innerWidth <600){
                    renderizar(2);
                }else if(window.innerWidth <1000){
                    renderizar(3)
                }else{
                    renderizar(4);
                }
            });

            prevBtn.addEventListener("click", () => {
                if (total === 0) return;
                posicao = (posicao - 1 + total) % total;
                if(window.innerWidth <600){
                    renderizar(2);
                }else if(window.innerWidth <1000){
                    renderizar(3)
                }else{
                    renderizar(4);
                }
            });
        </script>


    <?php
    }
    ?>


</body>

</html>