<?php

session_start();

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Verifica se a opção foi selecionada
    if (isset($_POST['grupo_opcoes'])) {
        $opcaoSelecionada = $_POST['grupo_opcoes'];
    } else {
        $opcaoSelecionada = 'Nenhuma opção selecionada';
    }

    // Verifica se o ID da mensagem foi enviado
    if (isset($_POST['id_mensagem'])) {
        $idMensagem = $_POST['id_mensagem'];
    } else {
        $idMensagem = 'ID não fornecido';
    }


	if(isset($_SESSION['email_cli']))
	{
		$email = $_SESSION['email_cli'];
	}


    $serverName ="LAB21T-Prof\SQLEXPRESS";
    $database = "Littera";
    $username = "sa";
    $password = "etesp";

    try {
        $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		
	$stmt = $conn->prepare("EXEC sp_CriarDenuncia @email_cliente = :email, @id_mensagem = :idMensagem, @motivo = :motivo");

$stmt->bindParam(':email', $email);
$stmt->bindParam(':idMensagem', $idMensagem);
$stmt->bindParam(':motivo', $opcaoSelecionada);

$stmt->execute();

        echo "<script>alert('Denúncia enviada com sucesso!'); window.location.href='forum.php';</script>";
		
    } catch (PDOException $e) {
        echo "Erro no envio: " . $e->getMessage();
    }





}

?>




