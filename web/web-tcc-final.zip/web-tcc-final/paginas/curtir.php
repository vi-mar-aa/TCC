<?php
session_start();

$serverName ="LAB21T-Prof\SQLEXPRESS";
$database = "Littera";
$username = "sa";
$password = "etesp";

// Força retorno JSON e evita qualquer output antes do JSON
header('Content-Type: application/json; charset=utf-8');

if (!isset($_POST['id_mensagem'])) {
    echo json_encode(['success' => false, 'error' => 'ID da mensagem não recebido']);
    exit;
}

$id_mensagem = (int) $_POST['id_mensagem'];

try {
    $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Verifica se está curtindo ou descurtindo
    $acao = isset($_POST['acao']) ? $_POST['acao'] : 'curtir';
    
    // Atualiza o número de curtidas (incrementa ou decrementa)
    $stmt = $conn->prepare("UPDATE Mensagem SET curtidas = curtidas " . ($acao === 'descurtir' ? "- 1" : "+ 1") . " WHERE id_mensagem = :id AND curtidas " . ($acao === 'descurtir' ? "> 0" : ">= 0"));
    $stmt->bindParam(':id', $id_mensagem, PDO::PARAM_INT);
    $stmt->execute();

    // Retorna o número atualizado de curtidas
    $stmt = $conn->prepare("SELECT curtidas FROM Mensagem WHERE id_mensagem = :id");
    $stmt->bindParam(':id', $id_mensagem, PDO::PARAM_INT);
    $stmt->execute();
    $curtidas = $stmt->fetchColumn();

    echo json_encode(['success' => true, 'curtidas' => $curtidas]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
