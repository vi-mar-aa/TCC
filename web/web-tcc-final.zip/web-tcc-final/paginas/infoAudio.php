<?php
//$serverName = "LAB02H-00"; // ou IP do servidor SQL
$serverName = "LAB21T-Prof\SQLEXPRESS";
$database = "Littera";
$username = "sa";
$password = "etesp";

try {


    if ($_GET) {
        $id = $_GET['id'];

        $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Preparar a chamada da procedure
        $stmt = $conn->prepare("select * from Midia where id_midia=" . $id);
        $stmt->execute();

        //Recupera os dados
        $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);


        foreach ($produtos as $midia) {

            $isbn = $midia['isbn'];
            $titulo = $midia['titulo'];
        }

        $stmt1 = $conn->prepare("EXEC sp_AcervoMidiasTodasInfosComExemplares");

        $stmt1->execute();

        $result = $stmt1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($result as $exemplares) {

            $total_exemplares = $exemplares['total_exemplares'];
        }
    }
} catch (PDOException $e) {
    echo "Erro na conexão ou execução: " . $e->getMessage();
}


?>



<!DOCTYPE html>

<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Littera - Detalhes do Livro</title>
    <link rel="stylesheet" href="../CSS/info.css">
</head>

<body>
    <div class="cabecalho">
        <img src="../paginas/imagens/logoLittera.png" class="logo" />

    </div>


    <?php


    foreach ($produtos as $dado) {
    ?>

        <div class="container">
            <div class="painel-superior">
                <div class="capa-livro">
                    <?php echo '<img src="exibirImagem.php?id=' . $dado['id_midia'] . '"alt="">'; ?>
                </div>
                <div class="informacoes">
                    <div class="informacoes-titulo">Informações</div>
                    <div class="informacoes-lista">
                        <div><strong>Título:</strong> <?php echo $dado['titulo']; ?></div>
                        <div><strong>Duração:</strong> <?php echo $dado['duracao']; ?></div>
                        <div><strong>Estúdio:</strong> <?php echo $dado['estudio']; ?></div>
                        <div><strong>Roteirista:</strong> <?php echo $dado['roteirista']; ?></div>
                        <div><strong>Gênero:</strong> <?php echo $dado['genero']; ?></div>

                    </div>
                </div>
                <div class="disponibilidade">
                    <div class="disponibilidade-titulo">Disponibilidade</div>



                    <div class="disponibilidade-numero"><?php echo $total_exemplares ?></div>

                    <div class="disponibilidade-texto">exemplares<br>disponíveis</div>
                    <div class="disponibilidade-info">
                        Para realizar uma reserva faça o <span class="download">download</span> do nosso aplicativo mobile!
                    </div>
                </div>
            </div>
            <div class="painel-sinopse">
                <div class="sinopse-titulo">Sinopse</div>
                <div class="sinopse-texto">
                    <?php echo $dado['sinopse']; ?>
                </div>
            </div>
            <div class="similares-titulo">Títulos Similares</div>
            <div class="similares-carousel">
                <button id="prevBtn" class="similares-seta">< </button>
                        <div class="carrossel" id="carrossel" style="display: flex; gap: 18px;"></div>
                        <button id="nextBtn" class="similares-seta">></button>
            </div>
        </div>
        <script defer>
             const cartasOriginais = [{
                    // exemplo de dados vindo do banco 
                    titulo: "<?php echo htmlspecialchars($dado['titulo'], ENT_QUOTES); ?>",
                    autor: "<?php echo htmlspecialchars($dado['autor'], ENT_QUOTES); ?>"
                },
                {
                    titulo: "Capitães da Areia, 1937",
                    autor: "Jorge Amado"
                },
                {
                    titulo: "Gabriela, Cravo e Canela",
                    autor: "Jorge Amado"
                },
                {
                    titulo: "Dona Flor e Seus Dois Maridos",
                    autor: "Jorge Amado"
                },
                {
                    titulo: "Tieta do Agreste",
                    autor: "Jorge Amado"
                }
            ];

            const carrossel = document.getElementById("carrossel");
            const prevBtn = document.getElementById("prevBtn");
            const nextBtn = document.getElementById("nextBtn");
            const body = document.body;
            const modo = localStorage.getItem("modo");
            let posicao = 0;
            const cartasPorTela = 4;
            const total = cartasOriginais.length;
            const capaLivroImg = document.querySelector(".capa-livro img"); 
            const capaSrc = capaLivroImg ? capaLivroImg.getAttribute("src") : ""; 

            window.addEventListener('resize', function() {
                if(window.innerWidth <600){
                    renderizar(2);
                }else if(window.innerWidth <1000){
                    renderizar(3)
                }else{
                    renderizar(4);
                }

                if(modo === "escuro"){
                    infoModoEscuro();
                }else{
                    infoModoClaro();
                }
            });

            window.addEventListener("DOMContentLoaded", () => {
                const modo = localStorage.getItem("modo") || "claro"; // padrão claro

                if (modo === "escuro") {
                    body.classList.add("modoEscuro");
                    infoModoEscuro(); // chama sempre
                } else {
                    body.classList.remove("modoEscuro");
                    infoModoClaro(); // chama sempre
                }

                if(window.innerWidth <600){
                    renderizar(2);
                }else if(window.innerWidth <1000){
                    renderizar(3)
                }else{
                    renderizar(4);
                }
            });


            function infoModoClaro() {

                const logo1 = document.querySelectorAll("img")[0];
                const divsPainelSup = document.querySelector(".painel-superior").querySelectorAll("div");
                const painelSin = document.querySelector(".painel-sinopse");
                const divsPainelSin = painelSin.querySelectorAll("div");
                const sinTitulo = document.querySelector(".sinopse-titulo");
                const simTitulo = document.querySelector(".similares-titulo");
                const disNumero = document.querySelector(".disponibilidade-numero");

                body.style.background = "radial-gradient(circle at 50% 20%, #ede9f7 60%, #d6cbe7 100%);";
                body.style.color = "#000";
                logo1.setAttribute("src", "imagens/logoLittera.png");
                painelSin.style.background = "#fff";
                sinTitulo.style.color = "#2F2259";
                simTitulo.style.color = "#2F2259";
                disNumero.style.color = "#2F2259";

                divsPainelSup.forEach(div => {
                    div.style.background = "#fff";
                    if (["Informações", "Disponibilidade"].includes(div.innerText)) {
                        div.style.color = "#2F2259";
                    }
                });

                divsPainelSin.forEach(div => {
                    div.style.background = "#fff";
                    if (div.innerText === "Sinnopse") {
                        div.style.color = "#2F2259";
                    }
                });

            }

            function infoModoEscuro() {
                const logo1 = document.querySelectorAll("img")[0];
                const painelSup = document.querySelector(".painel-superior");
                const divsPainelSup = document.querySelector(".painel-superior").querySelectorAll("div");
                const painelSin = document.querySelector(".painel-sinopse");
                const divsPainelSin = painelSin.querySelectorAll("div");
                const sinTitulo = document.querySelector(".sinopse-titulo");
                const simTitulo = document.querySelector(".similares-titulo");
                const disNumero = document.querySelector(".disponibilidade-numero");


                body.style.background = "#070512";
                body.style.color = "#f0f8ff";
                logo1.setAttribute("src", "imagens/logoEscWeb.png");
                painelSin.style.background = "#12101fff";
                sinTitulo.style.color = "#C9BAFF";
                simTitulo.style.color = "#C9BAFF";
                disNumero.style.color = "#C9BAFF";
                if(window.innerWidth < 800){
                    painelSup.style.background ="rgb(7, 5, 18)";
                }

                divsPainelSup.forEach(div => {
                    div.style.background = "#12101fff";
                    if (["Informações", "Disponibilidade"].includes(div.innerText)) {
                        div.style.color = "#C9BAFF";
                    }
                });

                divsPainelSin.forEach(div => {
                    div.style.background = "#12101fff";
                    if (div.innerText === "Sinnopse") {
                        div.style.color = "#C9BAFF";
                    }
                });
            }

            function renderizar(cartasPorTela) {
                carrossel.innerHTML = "";

                for (let i = posicao; i < posicao + cartasPorTela; i++) {
                    const index = i % total;
                    const carta = cartasOriginais[index];

                    const div = document.createElement("div");
                    div.className = "similares-cartao";
                    div.style.backgroundImage = `url('${capaSrc}')`; 
                    div.style.backgroundSize = "cover";

                    div.innerHTML = `
            <div class="similares-info" style="background: ${modo === 'escuro' ? '#12101fff' : '#A293CD)'};">
                <strong>${carta.titulo}</strong>
                <span>${carta.autor}</span>
                <a href="#">+ Informações</a>
            </div>
        `;

                    carrossel.appendChild(div);
                }


            }


            nextBtn.addEventListener("click", () => {
                posicao++;
                if(window.innerWidth <600){
                    renderizar(2);
                }else if(window.innerWidth <1000){
                    renderizar(3)
                }else{
                    renderizar(4);
                }
            });

            prevBtn.addEventListener("click", () => {
                posicao = (posicao - 1 + total) % total;
                if(window.innerWidth <600){
                    renderizar(2);
                }else if(window.innerWidth <1000){
                    renderizar(3)
                }else{
                    renderizar(4);
                }
            });
        </script>

    <?php
    }
    ?>


</body>

</html>