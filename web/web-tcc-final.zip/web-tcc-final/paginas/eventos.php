<?php

//$serverName = "LAB02H-00"; // ou IP do servidor SQL
$serverName = "LAB21T-Prof\\SQLEXPRESS";
$database = "Littera";
$username = "sa";
$password = "etesp";

try {

		$conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


		$stmt1 = $conn->prepare("EXEC sp_TodosEventos");

		$stmt1->execute();
			
		$result = $stmt1->fetchAll(PDO::FETCH_ASSOC);
		
		$contar = count($result);
			
			
} catch (PDOException $e) {
    echo "Erro na conexão ou execução: " . $e->getMessage();
}


?>



<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/Geral.css">
    <link rel="stylesheet" href="../CSS/nav.css">
    <link rel="stylesheet" href="../CSS/button.css">
    <link rel="stylesheet" href="../CSS/eventos.css">
	<script src="../paginas/js/modoEscuroGeral.js" defer></script>
    <title>Eventos</title>
</head>

<body id="homeBody">




    <section>
        <header>
            <div id="logo">
               <a href="Index.html"><img src="../paginas/imagens/logoLittera.png" alt="logo Littera" id="minhaLogo"></a>
            </div>
            <div class="titulo">Eventos</div>
        </header>



		<?php
			
		$a=0;
		$i = 0;
		while($contar >= 3){
		?>

        <div class="evento-container">
            <!-- Hexágono central -->
			
			
			<div class="evento-linha-cima">
				<div>
					<img src="../paginas/imagens/hexagono1Evento.png" alt="logo Littera" class="hexagonosEvento"style="width:23vw;">
				</div>
				<div class="evento-caixa">
					<h2 class="evento-titulo">
					 <?php					 		
					 echo $result[$i]['titulo'];	
					 ?>
					</h2>
					<div class="evento-detalhes">
						<div class="evento-detalhe">
							<span class="evento-detalhe-label">Local:</span> <?php					 		
					 echo $result[$i]['local_evento'];	
					 ?>
						</div>
						<div class="evento-detalhe">
							<span class="evento-detalhe-label">Início:</span> <?php

							echo date("d/m/Y H:i:s", strtotime($result[$i]['data_inicio']));	
					 ?>
						</div>
						<div class="evento-detalhe">
							<span class="evento-detalhe-label">Fim:</span> <?php					 		
							echo date("d/m/Y H:i:s", strtotime($result[$i]['data_fim']));
					 $i++;
					 ?>
						</div>
					</div>
				</div>
				<div>
					<img src="../paginas/imagens/hexagono2Evento.png" alt="logo Littera" class="hexagonosEvento" style="width:19vw;">
				</div>
			</div>
			
            <div class="evento-linha-baixo">
                <!-- Hexágono inferior esquerdo -->
                <div class="evento-caixa">
                    <h2 class="evento-titulo">
                        <?php	
						echo $result[$i]['titulo'];
						?>
                    </h2>
                    <div class="evento-detalhes">
                        <div class="evento-detalhe">
                            <span class="evento-detalhe-label">Local:</span> <?php					 		
					 echo $result[$i]['local_evento'];	
					 ?>
                        </div>
                        <div class="evento-detalhe">
                            <span class="evento-detalhe-label">Início:</span> <?php

							echo date("d/m/Y H:i:s", strtotime($result[$i]['data_inicio']));	
					 ?>
                        </div>
                        <div class="evento-detalhe">
                            <span class="evento-detalhe-label">Fim:</span> <?php					 		
							echo date("d/m/Y H:i:s", strtotime($result[$i]['data_fim']));
					 $i++;
					 ?>
                        </div>
                    </div>
                </div>
				<div>
					<img src="../paginas/imagens/hexagono3Evento.png" alt="logo Littera" class="hexagonosEvento" style="width:18vw; margin-top:5vw; margin-bottom: -30vw;">
				</div>
                <!-- Hexágono inferior direito -->
                <div class="evento-caixa">
                    <h2 class="evento-titulo">
                        <?php 
						echo $result[$i]['titulo'];
						?>
                    </h2>
                    <div class="evento-detalhes">
                        <div class="evento-detalhe">
                            <span class="evento-detalhe-label">Local:</span> <?php					 		
					 echo $result[$i]['local_evento'];	
					 ?>
                        </div>
                        <div class="evento-detalhe">
                            <span class="evento-detalhe-label">Início:</span> <?php

							echo date("d/m/Y H:i:s", strtotime($result[$i]['data_inicio']));	
					 ?>
                        </div>
                        <div class="evento-detalhe">
                            <span class="evento-detalhe-label">Fim:</span> <?php					 		
							echo date("d/m/Y H:i:s", strtotime($result[$i]['data_fim']));
					 $i++;
					 ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php
		$contar = $contar -3;
		}
		
		if($contar != 0){
		?>
		
		<div class="evento-container">
            <!-- Hexágono central -->
			
			
			<div class="evento-linha-cima">
				<div>
					<img src="../paginas/imagens/hexagono1Evento.png" alt="logo Littera" class="hexagonosEvento"style="width:23vw;">
				</div>
				<div class="evento-caixa">
					<h2 class="evento-titulo">
					 <?php					 		
					 echo $result[$i]['titulo'];	
					 ?>
					</h2>
					<div class="evento-detalhes">
						<div class="evento-detalhe">
							<span class="evento-detalhe-label">Local:</span> <?php					 		
					 echo $result[$i]['local_evento'];	
					 ?>
						</div>
						<div class="evento-detalhe">
							<span class="evento-detalhe-label">Início:</span> <?php

							echo date("d/m/Y H:i:s", strtotime($result[$i]['data_inicio']));	
					 ?>
						</div>
						<div class="evento-detalhe">
							<span class="evento-detalhe-label">Fim:</span> <?php					 		
							echo date("d/m/Y H:i:s", strtotime($result[$i]['data_fim']));
					 $i++;
					 ?>
						</div>
					</div>
				</div>
				<div>
					<img src="../paginas/imagens/hexagono2Evento.png" alt="logo Littera" class="hexagonosEvento" style="width:19vw;">
				</div>
			</div>
			
            <div class="evento-linha-baixo" style ="<?php if($contar == 1){ echo "display:none;"; }?>">
                <!-- Hexágono inferior esquerdo -->
                <div class="evento-caixa">
                    <h2 class="evento-titulo">
                        <?php	
						echo $result[$i]['titulo'];
						?>
                    </h2>
                    <div class="evento-detalhes">
                        <div class="evento-detalhe">
                            <span class="evento-detalhe-label">Local:</span> <?php					 		
					 echo $result[$i]['local_evento'];	
					 ?>
                        </div>
                        <div class="evento-detalhe">
                            <span class="evento-detalhe-label">Início:</span> <?php

							echo date("d/m/Y H:i:s", strtotime($result[$i]['data_inicio']));	
					 ?>
                        </div>
                        <div class="evento-detalhe">
                            <span class="evento-detalhe-label">Fim:</span> <?php					 		
							echo date("d/m/Y H:i:s", strtotime($result[$i]['data_fim']));
					 $i++;
					 ?>
                        </div>
                    </div>
                </div>
				<div>
					<img src="../paginas/imagens/hexagono3Evento.png" alt="logo Littera" class="hexagonosEvento" style="width:18vw; margin-top:5vw; margin-bottom: -30vw;">
				</div>
				<!-- Hexágono inferior direito -->
                <div class="evento-caixa" style="visibility: hidden;">
                    <h2 class="evento-titulo">
                        <?php 
						echo $result[$i]['titulo'];
						$i++;
						?>
                    </h2>
                    <div class="evento-detalhes">
                        <div class="evento-detalhe">
                            <span class="evento-detalhe-label">Local:</span> Biblioteca Littera – Auditório Principal
                        </div>
                        <div class="evento-detalhe">
                            <span class="evento-detalhe-label">Data:</span> 18 de maio de 2025
                        </div>
                        <div class="evento-detalhe">
                            <span class="evento-detalhe-label">Horário:</span> Das 14h às 18h
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php
		}
		?>

    </section>
</body>

</html>
