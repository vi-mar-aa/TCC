<?php
session_start();

$email_cli = $_SESSION['email_cli'] ?? null;

// Recupera o ID da mensagem pai (para comentário)
$id = isset($_GET['id']) ? (int) $_GET['id'] : null;

// Recupera o conteúdo do comentário (título/conteúdo)
$filtro = isset($_GET['filtro']) ? trim($_GET['filtro']) : null;

if (!$email_cli) {
    die("Usuário não logado!");
}

$serverName = "LAB21T-Prof\SQLEXPRESS";
$database = "Littera";
$username = "sa";
$password = "etesp";

try {
    $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Se o usuário enviou um comentário (filtro preenchido)
    if ($filtro) {
        $stmt = $conn->prepare("EXEC sp_MensagemAdicionar
            @titulo = :titulo,
            @email_cliente = :email_cliente,
            @conteudo = :conteudo,
            @id_pai = :id_pai
        ");

        $stmt->bindParam(':titulo', $filtro);
        $stmt->bindParam(':email_cliente', $email_cli);
        $stmt->bindParam(':conteudo', $filtro);
        $stmt->bindParam(':id_pai', $id, PDO::PARAM_INT);

        $stmt->execute();
        if ($id) {
            echo "<script>window.location.href='comment.php?id={$id}';</script>";
        } else {
            echo "<script>window.location.href='comment.php';</script>";
        }
        exit;
    }

    // Caso contrário, apenas seleciona a mensagem
    $stmt = $conn->prepare("
        SELECT m.titulo, m.id_mensagem, c.nome AS autor, c.username, c.imagem_perfil, 
               m.conteudo, m.data_postagem, m.curtidas,
               (SELECT COUNT(1) FROM Mensagem cm WHERE cm.id_pai = m.id_mensagem) AS qtd_comentarios
        FROM Mensagem m
        JOIN Cliente c ON c.id_cliente = m.id_cliente
        WHERE m.id_pai IS NULL AND m.visibilidade = 1 AND m.id_mensagem = :id
    ");

    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
	
	//este código é para carregar os coments
	
        $stmt1 = $conn->prepare("exec sp_ComentariosListar
            @id_post = :id
        ");
        
		$stmt1->bindParam(':id', $id, PDO::PARAM_INT);

        $stmt1->execute();

		$result1 = $stmt1->fetchAll(PDO::FETCH_ASSOC);
		
} catch (PDOException $e) {
    die("Erro na conexão ou execução: " . $e->getMessage());
}
?>


<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <title>Comentários - Littera</title>
    <link rel="stylesheet" href="../CSS/forum.css">
    <!-- <link rel="stylesheet" href="../CSS/comentarios.css">  -->
    <link rel="stylesheet" href="../CSS/button.css">
    <script src="../paginas/js/modoEscuroGeral.js" defer></script>
	<script>

function commentModoEscuro(){
	var forumCards = document.querySelectorAll(".forum-card")
	var textsCards = document.querySelectorAll(".forum-card-text")
	var forumActions = document.querySelectorAll(".forum-card-actions")
	var forumCardTitles = document.querySelectorAll(".forum-card-title");
	var paths = document.querySelectorAll("path")
    document.querySelector("html").style.background = "#000"
	body.classList.add("modoEscuro");
	body.style.color = "#f0f8ff"
	body.style.margin = "0"

	forumCards.forEach((element, i) => {
		element.style.background = "#12101fff";
		textsCards[i].style.color = "#f0f8ff";
		forumActions[i].style.background = "#12101fff";
		forumActions[i].style.color = "#f0f8ff";
		if (forumCardTitles[i]) forumCardTitles[i].style.color = "#c9baff";
	});
	paths.forEach(function (path) {
		path.style.fill = "#c9baff";
		path.style.stroke = "#c9baff"
	});
}
    // Inicializa os botões de curtir ao carregar a página
    window.onload = function() {
        try {
            // Carrega o estado dos likes do localStorage
            const likedPosts = JSON.parse(localStorage.getItem('liked_posts') || '[]');
            
            // Inicializa cada botão de like
            document.querySelectorAll('.forum-like').forEach(element => {
                const id = element.getAttribute('data-id');
                
                // Define o estado visual baseado no localStorage
                element.style.opacity = likedPosts.includes(id) ? '0.5' : '1';
                
                // Sempre permite clicar (necessário para descurtir)
                element.style.pointerEvents = 'auto';
                
                // Adiciona o atributo data-liked para rastrear estado
                element.setAttribute('data-liked', likedPosts.includes(id) ? 'true' : 'false');
            });
            
            console.log('Estado dos likes carregado:', likedPosts);
        } catch (e) {
            console.error('Erro ao carregar estado dos likes:', e);
        }
    };


    function curtirPost(id_mensagem, element) {
        try {
			
            // Verifica diretamente no localStorage se o post já foi curtido
            const key = 'liked_posts';
            const likedPosts = JSON.parse(localStorage.getItem(key) || '[]');
            const jaCurtido = likedPosts.includes(id_mensagem);
            
            // Define a ação baseado no estado do localStorage
            const acao = jaCurtido ? 'descurtir' : 'curtir';
            
            // Desabilita temporariamente durante a requisição
            const originalPointerEvents = element.style.pointerEvents;
            element.style.pointerEvents = 'none';
            
            // Obtém contador atual
            const span = element.querySelector('.curtidas-count');
            const curtidas = parseInt(span.textContent);

            // Atualiza visual imediatamente
            element.style.opacity = acao === 'curtir' ? '0.5' : '1';
			
            // Atualiza o contador visualmente (antecipadamente)
            if (span) {
                span.textContent = acao === 'curtir' ? curtidas + 1 : curtidas - 1;
            }

            // Monta URL relativa corretamente
            const basePath = window.location.pathname.replace(/\/[^/]*$/, '/');
            const url = basePath + 'curtir.php';

            fetch(url, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                },
                body: 'id_mensagem=' + encodeURIComponent(id_mensagem) + '&acao=' + acao
            })
            .then(response => {
                console.log('Curtir response status:', response.status, 'ok:', response.ok, 'url:', url);
                if (!response.ok) throw new Error('HTTP error ' + response.status);
                return response.json();
            })
            .then(data => {
                if (data && data.success) {
                    // Atualiza contador
                    const span = element.querySelector('.curtidas-count');
                    if (span && typeof data.curtidas !== 'undefined') {
                        span.textContent = data.curtidas;
                    }

                    // Atualiza localStorage e visual
                    try {
                        const arr = JSON.parse(localStorage.getItem(key) || '[]');
                        if (acao === 'curtir') {
                            // Adiciona ao localStorage se curtindo
                            if (!arr.includes(id_mensagem)) {
                                arr.push(id_mensagem);
                                element.style.opacity = '0.5';
                                element.setAttribute('data-liked', 'true');
                            }
                        } else {
                            // Remove do localStorage se descurtindo
                            const index = arr.indexOf(id_mensagem);
                            if (index > -1) {
                                arr.splice(index, 1);
                                element.style.opacity = '1';
                                element.setAttribute('data-liked', 'false');
                            }
                        }
                        localStorage.setItem(key, JSON.stringify(arr));
                        console.log('Estado dos likes atualizado:', arr);
                    } catch (e) {
                        console.warn('Erro ao atualizar liked_posts no localStorage:', e);
                    }
                } else {
                    // Reverte visual em caso de erro
                    element.style.opacity = jaCurtido ? '0.5' : '1';
                    console.warn('Resposta de curtir.php indica falha:', data);
                    alert((data && (data.message || data.error)) || 'Não foi possível processar a ação.');
                }
                // Reabilita interação sempre
                element.style.pointerEvents = 'auto';
            })
            .catch(err => {
                console.error('Erro ao chamar curtir.php:', err);
                alert('Erro ao conectar com o servidor. Veja console para detalhes.');
                // Reverte visual e reabilita em caso de erro
                element.style.opacity = jaCurtido ? '0.5' : '1';
                element.style.pointerEvents = 'auto';
            });
        } catch (e) {
            console.error('Erro interno em curtirPost:', e);
            element.style.pointerEvents = 'auto';
        }
    }
    </script>
</head>
<style> 
.forum-posts{
	    box-shadow: 0 1px 60px #9389B06E;
		margin-top:2vw;
}
#pop_up {
            width: 85%;
            height: 100%;
            display: none;
            position: fixed;
            background-color: #FFFFFF;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 99999;
            text-align: center;
            padding: 15px;
        }

        #botao {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 30px;
        }

        #meuPlace::placeholder {
            color: #2F2259;
        }

        #meuPlace2::placeholder {
            font-weight: 500;
            font-size: 1vw;
            color: #000000;
        }

        .minhasDiretrizes {
            margin: 10px 0 20px 10%;
            font-family: Roboto, sans-serif;
        }

        .textoMinhasDiretrizes {
            margin-top: 10px;
            margin: 0 0 0 10%;
            font-family: Roboto, sans-serif;
        }

        #liConcordo {
            margin-right: 0;
            border: solid 1px #653a96;
            background: linear-gradient(to top, rgba(254, 254, 255, 0.5)17%, rgba(109, 97, 147, 0.5)200%);
            width: min(37vw, 180px);
        }

        #tituloForum {
            font-size: 5vw;
            color: #2F2259;
            font-family: Nunito Sans, sans-serif;
            margin-bottom: 1vw;
            margin-top: 0.2vw;
        }

        @media (max-width: 600px) {
            #pop_up {
                width: 90%;
                height: 415px;
            }

            #botao {
                width: 95%;
                margin-right: 4vw;
            }

            .textContent {
                font-size: 16px;
            }
        }


        #pop_up2 {
            width: 50%;
            height: 60%;
            display: none;
            position: fixed;
            background-color: #FFFFFF;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 510;
            text-align: center;
            padding: 15px;
        }

        #botao2 {
            width: 100%;
            height: 15%;
            display: flex;
            align-items: center;
            position: relative;
        }

        #button-save {
            position: absolute;
            right: 3vw;
            border: solid 1px #653a96;
            background: linear-gradient(to top, rgba(254, 254, 255, 0.5)17%, rgba(109, 97, 147, 0.5)200%);
            grid-template-columns: 2fr 1px 1fr;
            bottom: 26vw;
        }

        #button-save2 {
            border: solid 1px #653a96;
            background: linear-gradient(to top, rgba(254, 254, 255, 0.5)17%, rgba(109, 97, 147, 0.5)200%);
            grid-template-columns: 2fr 1px 1fr;

        }

        #meuPlace {
            margin: auto;
            width: 86%;
            height: 40px;
            background-color: transparent;
            border: none;
            outline: none;
            color: #2F2259;
            font-size: 1.5vw;
            font-family: Nunito Sans, sans-serif;
            font-weight: 600
        }

        .forum-card-text {
            overflow-wrap: break-word;
        }

        @media (max-width: 1200px) {
            #pop_up2 {
                width: 90%;
                height: 600px;
            }

            #botao2 {
                width: 95%;
                margin-right: 4vw;
                margin-top: 2vw;
            }

            .textContent {
                font-size: 30px;
            }

            #meuPlace {
                font-size: 5vw;
            }

            textarea {
                font-size: 4vw;
            }

            #meuPlace2::placeholder {
                font-size: 4vw;
            }

            #button-save {
                bottom: 54vw;
            }

            #button-save2 {
                bottom: 7.8vw;
                right: 6vw !important;
            }

            .button {
                width: min(37vw, 190px);
            }

        }




        #pop_denuncia {
            width: 30%;
            height: 55%;
            display: none;
            position: fixed;
            flex-direction: column;
            justify-content: center;
            background-color: #FFFFFF;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 510;
            text-align: center;
            padding: 15px;
        }

        #botaoDenuncia {
            width: 90%;
            height: 15%;
            margin: 0 auto;
            display: flex;
            margin-top: 40px;
            justify-content: space-evenly;
            align-items: center;
        }

        #textDenuncia {
            color: #653a96;
            font-family: 'Nunito Sans', sans-serif;
            font-size: 30px;
        }

        #opcoesDenuncia {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap: 15px;
            padding-left: 2vw
        }

        input[type="radio"] {
            width: 18px;
            height: 15px;
        }

        @media (max-width: 1200px) {
            #pop_denuncia {
                width: 60%;
                height: 584px;
            }

            #botaoDenuncia {
                width: 95%;
                margin-right: 4vw;
            }

            .textContent {
                font-size: 30px !important;
            }

            .textbtnSave2 {
                font-size: 30px;
            }

            label {
                font-family: "Roboto", sans-serif;
            }

            #opcoesDenuncia {
                font-size: 3.5vw;
            }

            input[type="radio"] {
                width: 30px;
                height: 27px;
            }
        }

        @media (max-width: 1200px) {
            #pop_up {
                height: 94%;
            }

            #tituloDiretriz {
                font-size: 60px !important;
            }

            .minhasDiretrizes {
                font-size: 4.1vw;
            }

            .textoMinhasDiretrizes {
                font-size: 2.5vw;
            }

            #liConcordo {
                width: min(37vw, 340px);
                height: min(5vh, 75px);
            }

            #btnTextLiCon {
                font-size: 3.5vw;
            }

            #separaLiCon {
                height: 69% !important;
            }

            #botao {
                margin-top: 50px;
            }

            #tituloForum {
                font-size: 11vw;
            }

            .forum-busca input {
                font-size: 3vw
            }

            .forum-tabs button {
                font-size: 2.5vw;
            }

            .forum-tabs {
                gap: 3vw;
                margin-bottom: 7vw;
                margin-top: 3vw;
            }

            .forum-posts {
                gap: 3vw;
				    box-shadow: 0 1px 60px #9389B06E;
            }

            .forum-card-user {
                font-size: 3vw;
            }

            .forum-card-title {
                font-size: 4.5vw;
            }

            .forum-card-text {
                font-size: 3.2vw;
                margin-bottom: 2vw;
            }

            .forum-like,
            .forum-comment {
                font-size: 3.5vw;
            }

            .forum-card-date {
                font-size: 2.95vw;
            }

            #button2 {
                bottom: 5vw !important;
                right: 3vw !important;
            }

            #textDenuncia {
                font-size: 45px;
            }
        }
</style>
<body style="display: flex; align-items: center; justify-content: center;">
   <div class="forum-posts">
                <?php


                foreach ($result as $dado) {
				$qtde = $dado['qtd_comentarios'];
					
                ?>
                    <!-- Post -->
                    <div class="forum-card" style="box-shadow:none">
                        <div class="forum-card-header">
                            <div class="forum-card-user">
                                <svg width="45" height="45" viewBox="0 0 45 45" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <ellipse cx="22.5" cy="22.3299" rx="22.5" ry="22.3299" fill="#8B7AC2" fill-opacity="0.26" />
                                    <rect x="0.427734" y="0.855469" width="44.1451" height="44.1451" fill="url(#pattern0_64_271)" />
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M16.5597 2.07853C12.5458 3.11912 9.38492 5.00945 6.17998 8.28601C-2.38652 17.0443 -2.00351 30.238 7.05771 38.524C12.471 43.4736 19.0922 45.4985 26.0876 44.344C30.8967 43.5504 34.2826 41.8912 37.9658 38.524C45.0487 32.0478 47.0072 21.9658 42.8134 13.5764C41.2593 10.4679 36.9219 5.96046 33.7747 4.18356C28.8677 1.41378 22.2476 0.60432 16.5597 2.07853ZM29.3195 4.22703C32.9234 5.43778 37.1244 8.51448 39.2408 11.4931C43.8507 17.9794 44.4158 24.9142 40.9016 31.858C39.56 34.509 35.0943 39.4178 34.0246 39.4178C33.7455 39.4178 33.5177 37.9425 33.5177 36.1385C33.5177 33.5018 33.2833 32.6197 32.3214 31.6327C31.1702 30.4527 30.7998 30.406 22.5888 30.406C14.5825 30.406 13.9739 30.4776 12.7792 31.5585C11.7083 32.528 11.5058 33.2447 11.5058 36.0643C11.5058 37.9086 11.2807 39.4178 11.0061 39.4178C10.731 39.4178 9.41244 38.3936 8.07576 37.142C3.45821 32.8191 1.01543 25.7523 2.12758 19.9366C4.50432 7.51312 17.2261 0.162746 29.3195 4.22703ZM18.2981 13.4725C17.2861 14.0975 16.1778 15.4662 15.644 16.7522C12.7269 23.775 21.3968 29.6766 27.438 24.7801C31.0122 21.8831 30.6182 15.6936 26.7133 13.3999C24.4125 12.0481 20.5521 12.0815 18.2981 13.4725ZM24.8868 14.565C30.1499 17.1578 28.39 24.5749 22.5117 24.5749C16.8932 24.5749 14.7663 17.3449 19.6364 14.7994C21.4502 13.851 23.2723 13.7699 24.8868 14.565ZM31.0023 32.8291C31.6197 33.4244 31.8668 34.6993 31.8668 37.2926V40.9227L28.9778 41.8589C25.2847 43.0558 19.7388 43.0558 16.0457 41.8589L13.1567 40.9227V37.4288C13.1567 32.114 13.3603 31.9963 22.558 31.9963C28.7147 31.9963 30.2996 32.1527 31.0023 32.8291Z" fill="#573280" />
                                    <defs>
                                        <pattern id="pattern0_64_271" patternContentUnits="objectBoundingBox" width="1" height="1">
                                            <use xlink:href="#image0_64_271" transform="scale(0.00195312)" />
                                        </pattern>
                                        <image id="image0_64_271" width="512" height="512" preserveAspectRatio="none" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAA7DAAAOwwHHb6hkAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzt3Xe8XUW5//HPKTlJThKSECCUJJTQApEWOojSm0gHpdjAeMWCiopdVFT0/kSwXIVrRb00FZFOpIP0FgihJYQEAklI7znt98ezjzk52aftvZ6ZVb7v12tewYCz5ll7rTWzZk2pQUTSrh7YuJRGAsOA4aU/O6ZBQGPpzwZgKFBX+ncdDQb6dfq7JmBZp79bBDQDS4A1wHJgRenPRZ3SwtKfc4B5wFygpeKIRcRdTewCiBTchsAoYEwpjSqlLYBNSmljsnevtrG2ITAHmA3MAt4o/Tmz9M8LYhVQpOiy9lARyZoarELftlMaW/pzULyipcIyYBrwaqc0DWsgtMUrmki+qQEgkpzNgZ2AnTv8uQswJGahMmw11hCYArzQ4c+pQGvEconkghoAIn1XD+wATCilnYA9sO588bcMeJa1DYIngSeAVTELJZI1agCIdK8G2A7Yp0N6F9A/ZqFkPauBycBjwKPAI8ArUUskknJqAIisqxHYF3g3ayt8vdln03ysMfAocH/pz5VRSySSImoASNENAvYDDgQOwCp+vd3nUzP26eBfwEPAA9jURZFCUgNAiqYee8M/vJT2Kv2dFE8z1iswqZQeK/2dSCGoASBFMBY4CqvwDwY2iFscSanFwD1YY+A24LW4xRHxpQaA5FEdsBtwHPA+bKS+SF9NB24GbgLuw1ZLFMkNNQAkLwYBRwMnYG/7I+IWR3JmPtYrcCNwK7YkskimqQEgWdYIHAqcCpyIrXEv4m0VNpDweqxBsDhucUQqowaAZM0QrLI/DTgMjdiXuFZjYwauA25g/Q2VRFJLDQDJggbgSPSmL+nW3jNwFdYzsCZucUS6pwaApFUNNi//Q8Ap2Pa3IlmxAPgr1hh4KHJZRMpSA0DSZjOse/8cbMldkax7Gbga+D3weuSyiPyHGgCSBg3A+4GPYl39dXGLI+KiBbgdawj8E00rlMjUAJCYNgfOBj4NjIpcFpGQ5gB/AH4NzIhaEiksNQAktFrgEGAiNqBPy/BKkbUCdwNXAn/HeglEglADQELZAPuu/2lgm8hlEUmjacDlwO+A5ZHLIgWgBoB4Gwt8Fvu+PyRyWfJkDbaTXbnUhM1HX4lNTVvKupvcLGH9N8061t0joR77vQYAA7Gpl/2AYZ3S8NKf/RKLTBZgnwZ+DrwduSySY2oAiJf3AF/A1uKvjVyWLFkKzARmldJsYC7wVunPeaW/S9uCM0OwGRybABtj4zs2BrbAxneMKSWt4dB7q4G/AJcCUyKXRXJIDQBJUi02mv9CbMtdWV8zVsG/inX5vlpK07EKP+/Lyg4DRmOfgbbFeoi2LaUxaAZIOW3YPgQ/wcYLiCRCDQBJQgNwBvBlYFzksqRFEzb/+4VSmlL682U0/asrDcD2wE4d0s7AdugTQ7unsIbAdaz7WUekz9QAkGo0AOcCX6XY0/iWAc8CT3dIz6OKPikNwHhg9w5pV2wHyKKaCVwC/BYtOSwiAdVjFf8MrHuyaOkVbA73x7G3VI1xCK8O6x2YCPwR+4wS+7qIkV4DPoam04qIs1psQ56Xif/gC5WasO77K7B9CcZUfRbFy0jgOOzN+EFsBkTs6ydkQ2AiGkMhIgmrBU7HvmHHftB5p2XALcDXgIOwKXCSTY3YbJSvA7dic+tjX1/eaQrWSNfnXRGp2mHAk8R/sHmmadgb/nHYvHfJpwHY9XwJ8ATxrzvP9DxqCIhIhY4hvw/JZdhmLJ8Etk7qhEnmbAOcB9xEfnsHHgOOSuqEiUi+TQDuIf6DK+k0FZs+dRjQP7GzJXkxADgcW3TnReJfr0mnSdhMChGR9WyBdYM3E/9hlVSajq2tvkeC50mKYWfgIqzhGPs6Tiq1AFdhqzWKiDAEuJj8dIG+Anwf2CXJkySFthvwA/Iz1XA+tj+Hpg6KFNhx2IIisR9I1abXsTf9A9GgJ/HV3jPwCvGv+2rTS8CxiZ4dEUm9XYEHiP8AqibNxb7X7oMqfQmvBtvv4jJsg6bY90M16SZsCWYRybFh2JtyE/EfOpWkFmyBl4lofr6kRwM25W4S0Er8+6SStAZ7NgxL+NyISGQ12Cp2c4n/oKkkzca+wW6T9IkRSdi2wA+x7Ztj3zeVpLeBDyR+VkQkirHAncR/sPQ1tWBvVKeineAke+qwKafXkc0et1vQstcimdUf+BawkvgPk76kN7BBVqMTPyMicYwBvgO8Sfz7qy9pMfAptNmVSKYcQPbmLz8NnI3e9iW/GrBPcc8S/37rS3oQGOdwPkQkQQOxdc6ztJjPg9h0RI3klyI5EBt9n5VBg2uwZ4tW0RRJoQOweb2xHxS9SauxFcne5XImRLJjF2wFzqx8qnsOm/4oIikwGPgl2XiTWICNkN7c5UyIZNcWwI+ARcS/T3tKLdiUwUEuZ0JEemUv4GXiPxB6SrOBz2GNFRHp2hDgC9h0vNj3bU/pRWBPn9MgIl2pAc7HutJjPwS6S/OAC4FGn9MgkluN2D2e9oZAEzZrp87lLIjIOkYD9xL/xu8uzcceChu4nAGR4hiENaIXEP++7i79Gy3UJeLqFKxyjX2zd5WWYiOFtZyoSLKGYA2BNI8RWASc6XUCRIpqCDZSOPYN3lVahg0K0j7jIr5GYL1ri4l/33eVrkMvASKJ2A+YTvybulxahe3Ip4pfJKyR2E6EaR0H9Cq2U6eIVKAea+mndR3xG7B9BkQknu2AfxL/eVAuNQHfRAMERfpkI2wjnNg3cLk0FTjaL3QRqcAhwGTiPx/KpXuxHgsR6cEewGvEv2k7p/nYtKR6v9BFpAr1wETSue33LPRJQKRbHwJWEP9m7ZiasAGIGznGLSLJGY7Nxknb+IBVwMcd4xbJpP7AlcS/QTunScB4x7hFxM8OwC3Ef450TldhG5eJFN4Y4DHi35Qd0wzgfY4xi0g4xwMzif9c6ZgeAUZ5Bi2Sdu8hXUt9tmLd/UM8gxaR4BpJ31bh84DDPIMWSaP2tfzXEP8mbE/Po20+RfJuf2AK8Z837akZW+GwxjNokbRoBK4n/o3XnlYB3wYaPIMWkdToD3yHdA0SvBaNC5Cc2wh4kPg3W3v6N7Cza8QiklbjgYeJ/xxqT4+i9QIkp7YDXib+TdYGLMe63bRCl0ix1WBrBywh/nOpDVv2fJxrxCKBHUx6tvO8E9tSWESk3ZbAv4j/fGrDFh17j2+4ImGcDqwk/k21Cnvrr/UNV0Qyqn1w8iriP69WA2f5hivipwbbzKeV+DfTC8DurtGKSF6MJx37CrRiz1DNEJBMaQD+SDpuoCuwmQciIr01ALicdLzA/B7o5xuuSDKGAXcT/6aZCxznHKuI5NuRwGziP8/+hT1bRVJrDOlYZOMWNJ1GRJKxKXA78Z9rz6HlgyWltgKmEfcGWYkG+olI8tqnCy4n7jNuBrCtb6gifbMj8AZxb4zXgb28AxWRQtsNm6sf81n3FtqlVFJid+x7e8wb4lZgQ+9ARUSAEcT/JDAHa4yIRLMXtmhFrJugFdvhS13+IhJSDfa5sYV4z7+FwH7egYqUcxBxl89cDJzoHqWISNfeh1XEsZ6Dy9CWwhLY0cAK4l30U9F62SKSDtthI/RjPQ9XAe93j1IEm1sfc6nMq4FB7lGKiPTeYOAa4j0XVwOnuEcphfZBoIk4F3gT9s1NRCStJgJriPOMbAY+4h6hFNLZxBvwsgg43D9EEZGqHUW88VEtaBMhSdgJxHvzfwNNdxGRbBmPrU0SqyfgNP8QpQgOJ943/2fR0pcikk2bAU8S59m5GjjWP0TJswOwaSYxLuA7gA38QxQRcTMYuIk4z9AVwHvdI5Rc2od437H+F6j3D1FExF0d8AviPEuXAQf6hyh5sitxVvhrBS7yD09EJLjziTOQehGwR4D4JAe2B94m/EW6CvhAgPhERGI5mTiLqM0FdgoQn2TYtsCbhL84F6A1rUWkGA4kzvLBbwDbBIhPMmg0ttd06ItSu1qJSNHsAcwj/PN2OppZJZ1sAEwm/MWofa1FpKh2xN7KQz93pwDDAsQnGdAPmET4i3AG9slBRKSotgKmEf75ew/Q4B+epFkN8AfCX3wvYp8cRESKbgzwEuGfw78NEZyk10WEv+imAJsHiE1EJCtGYiufhn4efz1EcJI+H8Dm3Ye82J4ANgoRnIhIxgwHHiHsM7kV2+hNCuQgwq/v/wBa2ldEpDuDgbsJ+2xeDRwSIjiJbxw27z505T8oRHAiIhk3CHiQsM/o+cAOIYKTeDYCXiHshfU01rUlIiK9swHwOGGf1dOxsQiSQwOBhwl7QU0GRoQITkQkZ4YBTxH2mf0Y0BgiOAmnBriesBfSS6g1KSJSjU2Blwn77L46SGQSzIWEvYBmAlsGiUxEJN9GYd3zIZ/hXwgSmbg7BGgi3IXzBjA2SGQiIsUwlrAbtTUB7w0RmPgZjW0DGeqi0ZaTIiI+diDsVu1z0MZBmdUfG9AR6mJZBEwIEpmISDHtSthp3I9gdYlkzG8Id5GsAPYLE5aISKEdCKwk3PP9V2HCkqRMJNzF0QKcHCYsEREBTsWevaGe8+eECUuqtTdhl/m9IExYIiLSwVcI95xfCewZJiyp1AjgNcJdFFeGCUtERMr4JeGe96+jzdxSqx64i3AXw81AXZDIRESknHrgNsI99+9Az/1UuohwF8GT2K5VIiIS1xBsz5VQz/+vhQlLemsvYA1hfvw30NxQEZE02RxbgTVEHdAE7BsmLOnJYMKtFb0Em4cqIiLpMh5bjyVEXfAq1vMgkf2RMD/4GuDwQDGJiEjfHUW4pd9/Gygm6cIphPmh24DzA8UkIiKV+yLh6oXTA8UknYwC5hPmR9b2kCIi2VADXEuYumEhMCZMWNKuFribMD/wZGBQmLBERCQBg4HnCVNH3IemBgb1dcL8sEuAHQPFJCIiydmecIMCvxwopsKbAKzG/wdtBU4MFJOIiCTv/diz3Lu+WIMtQy+OQk75+26gmERExM8PCFNnvIg+F7v6H8L8kHeibzoiInlQS7jlgi8NFFPhvJcwXTkzsE2FREQkHzYEpuNff7QA+weKqTAasZWXvH+8FcBugWISEZFwJhBmq/jJQL9AMRXC5YTpvvl0qIBERCS4LxCmLvlGqIDybj+gGf8f7HZsAQkREcmnGuAW/OuTVcBOgWLKrf7AVPx/rDnAyEAxiYhIPJsB8/CvVx7ABiBKhb6N/4/UChwXKiAREYnuaMIMKv9kqIDyZjtgJf4/0M9DBSQiIqnxa/zrl8XYvjXSR//C/8eZAgwMFZCIiKRGI2E+Md8cKqC8+DD+P8oqYNdQAYmISOrsTpil5U8LFVDWDQfm4v+DfD5UQCIiklpfwr++eRsYGiqgLPsF/j/GnWjKn4iI2Ej9EJ+cLwsVUFaNB5rw/RGWAVuHCkhERFJvDLAU37qnCdglVEBZUwPci38r7FOB4hERkez4HP71z/2o97mss/A/+Y+ghRlERGR9tcBD+NdDqRkQmJaWyBDgJWyFJi+rgT2AFxyPIRLTJsBWHdJobGfLjUppKDbIFqCBtXuXLwfWlP55ITZ3+Z1Smg/MwnbJnAG8hq2iJpJH44EnsfvDyyxgR2zzOQEuxr/V9e1g0Yj4qsN2rTwX2yjrHmAB/vdQe5oP3F069jmlstS5RiwSznfxv4e+FSyalBuNvYF4nuzn8W3RiXhqAA4BLgImAUsIV9n3Ni3BZtdcBByM7jfJrv5YT7Hn/bIU3x7vzPgjvie6Bdg3WDQiyRgD/BdwI/6jk70ecDcAn8Aa+SJZciBWd3jeI78JFk1K7Y7/SdbcS8mKLYDzgQcJs1FJyDQFuLAUo0gW/BLfe6IFG5dWWPfge4JnAINDBSNSgQHAmdgUWO/GcBpSCzZ+4Aysq1UkrTYAZuJ7P0wKFk3KHIP/w+Z9waIR6ZsdsN6p+cSvlGOld4Cfls6FSBqdgP99cFSwaFLkUXxPamFbVpJqBwLXAc3Er4DTklqx+/W4Ks6riJfb8b3+n6Fg69N4t6rWAOOCRSPSvRrgROAJ4le2aU+PAe8nPWuUiOyM/xL1qVkcyFsN1uLxPJk/DRaNSPcOAx4nfsWatfQscGoF51vEg/cmdS8B9cGiieh0fE/kPNaudiYSy97YaP7YFWnW0wPAXn089yJJG4H/eJ1zg0UTSR3+CyycFywakfVtAVxF/qbxxUwtwO/RwikS12fwvc5nkvOZMWfjewInU5BuFEmdeuDL2HbTsSvMvKalwAXoHpc46rH1LDyv8dy+wNZh3zk8T94RwaIRWWsXbPBa7AqyKOkZYM9e/TIiyToU32s7t70A5+J74m4IF4oIYDfqD/EfIay0floDfB/tOSDh/RPfa/uT4UIJox8wHb8TthrYLlg0IjbN9CniV4RFT88B7+rhtxJJ0lhgFX7XdO56Ac7D9yHwk3ChSMHVYNfzCuJXfkqWlmObDomEchm+13RurucGfNdTXgpsEiwaKbIhwPXEr/CUyqergUFd/noiydkU323sXyMng10/hu9N/4NwoUiBbYd1N8eu5JS6T1PRKqASxo/xvZbPCheKj1p85/0vBjYMFo0U1XHYtRa7clPqXVqEbTYm4mkjYAl+1/FkMr4k9on43ugXBYtEimoiGuWfxdQMfLrM7ymSpO/hex0f61l479bFw8C+TnkvALbB3sxEklaLDS79XOyCVOFtYAY2BmcetpTpfGwE82psICNAIzbqeAC25OkIbFzNaGAr7HtnVv0EW6CpNXZBJJeGYd/rhznl/wBwkFPert6Db8voa+FCkYLph23ZG/sttrdpFbbvwE+BjwITgIEJno/GUp4fKx3jIXynQSWdrsZ+UxEP38T3+t0/XCjJuRG/EzIXGBwuFCmQAcBNxK+0ukvNWCX8DezhEGPO8ADgAOzh93CpTLHPS3fpRnI2t1pSYwjWw+Z17f41XCjJGItt4OF1Qi4IF4oUyCBgEvErq3JpDXAL8GHSOfB1BPAR4FasrLHPV7l0J5omKD6+jN9124x9isuMy/E7GbNJtntTBOyaupv4lVTn9AzwKdJZ6XdlQ2wA3rPEP3+d011Y74VIkgZhY268rtvMLHY3FN+pEVkelCXp1IC9ucaunNrTGuDPwN6eQQeyD/AX0tUrcDMaEyDJuwC/a3YR9qkh9T6P30lYgL79S7Lqgb8Rv1Jqw7YS/m9glGvEcYzB3mI8V0/rS7oO26FUJCkbYBW11zX72XChVKYWmIbfCfhhuFCkIK4gfmW0Aqsci7Ck9UhsHfWVxD/v/+McqxSP5+qAr2J1bGodg1/wq4HNw4UiBXAh8Suhv2Lz7YtmS2wL79jnXwOKJUmj8P3cdWS4UPrOc/rU7wLGIfl3Kr4zVXpKr6LlagEOBV4k3u/QCnzQPUopkqvwu15vCBhHn2yJ31zgVrTntyRnAvG6oFdiS1hrJPpaA4HvEm9xoRXAbu5RSlHsit+12kRKxwhdjF/QtweMQ/JtBLY8boyK5nFsV0Epb3vgSeL8NtPI1lRLSbc78btWvxMwjl7pB7yJX8CHhgtFcqwWuI04FcwVaCW63uiPrSPSSvjfaBKaGSDJOBK/63Q2KZvGegp+wT4dMA7Jt+8SvlJZiO2KKX1zMr5TqrpK3woRnOReDb4LYZ0QLpSeeS6icnbAOCS/DiT8evWPAVuHCC6ntsE+m4T8zZqA/UIEJ7n3Yfyu038GjKNbW+D3YJ1Fyro6JJOGYlt2hqxI/o4G+iVhIPAPwv5208jIqmuSag34fRpvIiXbdH8VvxvxonBhSI55Tsspl65E35KTVAf8hrC/4e+DRCZ55/nZ8UsB4+jSVHyCa8GmFopU42jCVhyXYN//JFk12AtByN/yfSECk1wbjV8P+YsB4yjrQPxuvlsCxiH5NASYSZjKohWtKhfCpwm3gNMMtPeIVO92/K7RfQLGsZ4ruyhUEilVoxwlk35BmIqiDZgYKCaBTxDud/1poJgkv07G7/qMtp9FA7Y7n0dQs7Fd2kQqtRfh3hS/ESgmWetbhPltm9EqgVKdfsDb+Fyf84g0UP6ECgrb2/T9gHFI/tQA9xOmgtCOcvFcRpjf+EE0rkOq8yP8rs9jA8bxH9dWWNieUiuwbcA4JH/OIEzFcDUp354z52rxew51TqcEiknyaSx+q1v+JWAcgA2uWpFAwculSQHjkPwZCLyOf4VwF/YZTOLqD9yL/+/9GlrXQapzNz7X5jJgUMA4XFc4Oi1gHJI/F+BfGbxNShbhEAA2wcYNef/unwkVkOSSZ8/kGQHjcFv6dx7aMEUqNwiYg28l0II2p0qj9+K/1PNbQGOgeCR/+mN1nMe1eWOoIIbit2/3paGCkFzyXJWyPWnEf3pdhP/vn4rV1ySzfobPdbmSQMtXn+kUQBuRFzWQTBsMzMf34X8nGvSXZnXY2AzPa2Au6gWQyu2P37V5eogA/u5U+Oloqo1U7rP4PvjnACODRSOV2gy/btb2dF6waCRvavBbnfQ678I3AsudCn+Jd+Elt+qAV/F96H84WDRSrbPwvRamoc2epHL/D5/rcjnOswFOcSp4G7CHZ8El107F94F/P+qdyhqvgcrt6aRwoUjO7I3fdXmiZ8H/7FToVzwLLbn3AH431BpgfLhQJCFbYwOjvK6Le4NFInlTg/UieVyXf/AqdB3wjlOhL/YqtOTejvitsNUG/DhcKJKwi/G7LtqAceFCkZy5BJ9rci5On6fe7VTgNmAXjwJLIVyK33U5C20Hm2WDgTdR41DSZ3f8rsv9PAr8Y6fCTvUorBRCf6zF63UjnRMuFHHySfyuDy1cJtWYis916bKZnldhL/IorBSC5z7brxJpm01JVD9sirHXdXJcuFAkZ76HzzX5bNIFHetU0DZgp6QLK4VxDX7X5YcDxiG+zsXvOvlzwDgkX8bjd12OSbKgn3Iq5AtJFlIKpRHbBcvjupyF3v7zpD9+YwGWYDtQilTiRXyuy4m9OXhvlzU9opf/XV/d5pSv5N9x+C16cTnQ5JS3hLca+LlT3kOAo53ylvy73Snfw5PKqB+wGJ9WymFJFVIK5y/4XJPLgGEB45AwhuO3iulVAeOQfDkSn2tyAQlNBzzQqYDL0AhaqUwtftv+/iZgHBLWH/C5ZuaiTaKkMgPwa5j2uLleby7axLoSOrkb65oT6au9gE2c8v5fp3wlPq/fdmNsXrdIX63Cb1XJHuvumA0Aff+XSnl9c50CPOqUt8T3EPCSU94aByCV8qoLqx67NwQbDOXRPbF1tYWTwrofn2vymyGDkCi+g8+1c3fIICRXtsXnmlyNzZaq2FFOBdPqf1KpBmAFPtfljgHjkDh2xOfaWY5dmyKVeAWf6/LQ7g7a0yeAgyoKpWfq/pdK7YHPvOvnsDm5km8v4vMC0gjs6pCvFINXndhtHd5TA+A9CRakIzUApFIHOOV7q1O+kj5ec6+9rk3JvygNgO40Yt8Qku6SWIZNfRCphNfyv+8NGIPEdTg+19D/hQxCcmUgPp82V1LhdPtDHArTBtxSSWFESjw2pVqGlv4tkv7YgzHp6+j5kEFI7tyBT5377q4O2N0ngAOrCqVrDzrlK/k3ENjOId/H0NK/RbIa+82Ttj1a3Ewq51U3VtQA2M+hIKAGgFRuPAktb9mJrsniecghz37AOId8pRg8rknoZkXArhoANcDeDgVZAzzhkK8Ug9fW0Y845Svp9bBTvjs75Sv59yjQ7JDvvl39i64aANsDGzoU5Cns25tIJbwWj3rGKV9Jr2ed8tUCZ1Kp5fg8izYBxpb7F101AHrcRKBCXl0cUgxbOeQ5H5jtkK+k20xgkUO+agBINbzqyLK9AKEbAP92yleKYSuHPDVyu7g8fns1AKQaQccBdNUA8Pj+D+oBkOps6ZDnNIc8JRumO+TpcY1KcURvADQA73IowCvYHu4ilRrpkOcMhzwlG15zyNPjGpXimI3PdbkLZdY6KdcAGIfPXFZ1/0s1GvHZA2CGQ56SDTMc8hyEVjqV6nhMSx5Amc3OyjUAJjgcHDTXWqqzkVO+bzvlK+nn9duPcMpXisHrM8Bunf+iXANgvf8oIV7zbqUYPKalAixwylfSb75TvmoASDW8est37/wX5RoAezgceBk+W3BKcQxxyneeU76Sfu845TvYKV8phhfwWS+nxwZALT57Wj8LtDrkK8XR4JTvMqd8Jf2WOuWr/QCkGi34vDDvhq3y+x+dGwBb4dN6fcohTykWr4fqaqd8Jf28fns1AKRakx3yHAZs0fEvOjcAvNZaf9opXykOrx6ANU75Svp5NQC8rlUpjuec8l1nrwo1ACQrPHYBBOtuk2Ly2HgFysy3Fukjjx4AiNAAWIMNahCphtebuh7WxaVeJUkrrwbAOnV85waAx1aWL6MbQqrndQ2pu7a4vL7Vr3LKV4pjLj7rVHTZAKihzEpBCdD0P0mC1/dardpWXF6/vV54JAke4wB2psNMgI4NgFH4zACY4pCnFI/XQ3W4U76Sfl6/vWaWSBI8PgNsAGzW/j86NgC2czgY6Pu/JGOhU75ata24vJaX1uqSkgSvmQBj2/+httxfJkwNAEmC17KtXpWApJ9X408NAEmC10DAbdv/obbcXyaoGdsGWKRaC4A2h3y36Pk/kZwa5ZBnK369VVIsU/FZQTdYA2AmGhAjyWgGFjvku5VDnpINWzvkuRCtLSHJWIXPTICynwA8GgCvOuQpxTXbIc+tHPKUbNjKIc+3HPKU4nrNIc//jPfr2ADYxuFAagBIkmY45LmDQ56SDds75OnxwJbi8rie1usBGIHPFMBpDnlKcc1wyHMcWg2wiBrwafypASBJmuGQ51BsOuB/GgCjHQ4C6gGQZM1wyLM/Pm+Ckm7j8FkFcoZDnlJcM5zyHQNrGwAeo2FBrWFJlleDcg+nfCW9dnfKVy89kiSvOnQ0rG0AjHE6yOtO+UoxeS2McYBTvpJeXr+519we3s+XAAAgAElEQVRtKaYgDQCPTwBLgSUO+UpxTcOuq6SpAVA8BzrkuRib+iySlFn4bFu9TgPA4xOAbgRJWhs+e0vshJYELpKR+AwAfB6fxaqkuJqBNxzyXWcMwGbd/IeVmuWQp8gzDnnWAkc65CvpdCQddkRL0LMOeYp4fAbYDNY2ADZ1OIB6AMTDw075HuWUr6TP0U75/tspXym2GQ55joS1DYBNHA6gFbHEw0NO+R4F1DvlLenRDzjCKW+va1OKzeMTwCZgDYB6fL5/eqxhLDINn8blxsDBDvlKuhwObOiQ75toDQDxMcchz42ButrSP9T28B9XYq5DniLg19V6mlO+kh6nOuX7oFO+Ih51aR0wopbStwAHHq0WEYA7nfI9CRjglLfENxA40Slvr2tSxKsu3aS9B8CDGgDi5XanfDcETnbKW+I7FVsHPWltwB0O+YqAX126cS0w3ClzfQIQLzPxWQ8A4ONO+Up85zrl+xw2BkDEg1ddOrwWGOaQ8Rq0CqD4us0p34OAnZ3ylnjehc/qfwC3OuUrArAIn9UAh3n1ACx0yFOko7865VsDfMEpb4nnS/gs/gN+16II2CemxQ75Dq/F55vYIoc8RTp6DL9pV2fiszqmxLEFcLpT3tOBp5zyFmnnUacO8/oE4NFaEemoDbjeKe/+wAVOeUt4XwYanPK+Bq3/L/48etXdGgDqAZAQrnXM+zzUC5AHo4CJjvl7XoMi7Tzq1OG1wGCHjNUAkBCexG8DloHAV53ylnC+jt/aDk8Ak53yFunIo04dXAs0OmSsGQASyv865v1JYBfH/MXXOOAcx/x/45i3SEdLHfIcWIu96SRtpUOeIuX8GVjhlHc98Ev8Ro+Lr59im/94WA5c7ZS3SGcedaoaAJJ5i/H9DnsgcLZj/uLjeOBIx/yvQT2dEo7HS06j1ycArzcykXIuxXck9o/xWzFTkjcE+Llj/m1Y74JIKB516kA1ACQPngcmOeY/EvieY/6SrB8Cox3zvxW/pahFyvHoVW+sxWeErD4BSGg/cc7/k8AhzseQ6h2B/VaeLnXOX6Qztx6AeoeM1zjkKdKdSfiuyFYL/AXY1PEYUp3NgT9hv5WXx4C7HfMXKcejTq33agB4bFwg0p024NvOx9gUG/ld53wc6bta4CpgE+fjfNM5f5FyWhzyrKvF52HmUViRntwMPOJ8jPdii8tIulwEHOp8jIeAO52PIVKOx0t1PcAq7O0pyXSWQ2FFeuNwkr+eO6cW4LBQAUmPDsYekN6/+8GhAhLp5EMkfz2vAGhyyPiDPudApFduw78ymAfsGCog6dJ2wBz8f++bQgUkUsYZJH9NrwFodcj4NJ9zINIr47CL27tSmIXvdDPp3hbYltDev/NqYIcwIYmUdTrJX9ctXqNltXSqxDQV+HWA44zCehs2DHAsWddQ4BZgywDH+hnwUoDjiATn8aZ0ZtAIRNa3ITAX/7fDNuABfJbUlvIGAg8S5rd9C2tsiMR0Jslf22tq8Rmx7zG1UKQvFgCfD3SsA7H9CPoHOl6R9QeuAw4IdLzzsf0mRGJym66/nORbFp5bcIr0xT8J86bYBtyD3hY9DQbuINzveUuYsER6dC7JX99L1QMgefdpfPbSLue92OeAzQMdr0hGAvdjS/2GsBT4r0DHEumJx7bWzbU4LjAgkgIzgS8GPN67sO/T2wU8Zt5tjTWsdg94zPOxWR4iaeBRp7aoASBFcCVwQ8DjbY29re4Z8Jh5tRfwMGEbVH8Ffh/weCI9cRkDUIvPzn1qAEjafBx4M+DxNsV6Aj4V8Jh58xnszX9kwGPOAiYGPJ5Ib3jUqSu9GgCDHPIUqcZ84GzC7lPRH/gFcD0aHNgXw4C/YfPvQ86saMaWMV8Y8JgiveFRp6oBIIVyD/C1CMc9BXgW2DfCsbNmAvAEcFKEY38Z+3QjkjaDHfJcAbbDVdLTC/7HobAiSajBvvGGmkrWMa3CBiTqE9n66rEKeDVxfptr/EMUqdivSf6afwBgkkPGf/I5ByKJGAJMIU5F04a94e7mHmV27AE8RbzfYzI+b1giSfkLyV/3d3h9AtDNJGm2FDgWeDvS8ScAj2PfuIu8j8AI4JfAo4Sd4tfRW8D7gGWRji/SGx516spafC58NQAk7WYA76f0HSyCemyU+8ulPxsilSOG/sDngFeA84j3SWQZVvnPjHR8kd7yqFOXgX2vT7pr4WGHwop4OB4b/R2r+7k9vY5NVfRY8SstGrDV9WYR/3w3YZW/SBY8SvL3wM8BfuCQ8Qs+50DExYew6YGxK6U2rGfi89g4hbwYAlyAvWnHPr9t2G+tHUslS14k+fvge2Ajb5POeK7PORBx80mglfiVU3taCFwK7OQZtLOdgJ8Ci4h/PttTK/AJz6BFHLxD8vfCF8C6HZPOuBmodTkNIn4uIH4FVS49iK1Ot5Ff6InZGKtgPaYXJ5FCbREtkpR6fHooPwZwqkPGbWTjYSXS2adJV09Ax9QE3I71VmzlFH8ltsYG892BlTH2eSqXWtGyzJJNI/G5J04CONwp8x09zoRIAB8jHQMDe0pTsaWGzwBGu5yJ8sZg39B/ic+3yaRTM/ARjxMhEsDO+NwXB9cD85wKvTH2cBDJmt9hU2SuIuxa9H21Yym1v9m+DTyHLWzzAvBaKb1B33f9rMcaFVsB2wDjgF2w7Y43rbLcIa3C1vf/W+yCiFRoY6d859UDc5wy1ycAybLrsEVi/kF2FuvZtJQO7/T3bdhmSO1pBfZNcUnp328A1AGN2OI87anGv8iu3gFOwMYjiGSVVwNgTnsPQCvJD9rzKrRIKA8A+wO3AGMjl6UaNViDvEiN8lew1R5fiV0QkSp51KXNwPza9n9wOMDmDnmKhPYStovfXbELIr12J7AfqvwlHzzq0neA1va3fo/PACEHJYl4egc4EvgO1p0u6dQG/Ag4Bp+XGpEYPOrSt2Ftt78aACLdawEuwqbNLo5bFCljEXAi8BXstxLJi1EOec6DtQ2AtxwOoAaA5NHfsK18NbAsPe4HdgVujF0QEQcedelsWNsAmOVwADUAJK9mAO/B3jab4hal0JqxzzKHoB39JJ9q8OkBmAm+DYBBZGf6lEhftWDfm/cHnolcliJ6GtgH+yyjLn/JqxHAQId834C1DQCv1rN6ASTvngD2wva3Xx65LEWwEnvr3xd4KnJZRLyNccp3nTp/V3yWGny/U+FF0mg74GbiL32b13Qj2V6PQaSvTsDnXtoZ/HsAtnXKVySNXgHeBxwGPB+5LHnyEraoz/HAtMhlEQlpO6d81/vsv5TkWxm/diq8SNr1w3YWnE38N+espjexXQbr+3juRfLiSpK/rxaWO9AzDgf6VzLnQCSz+gMTsam2sSvUrKR5wIX4DH4SyZJ7Sf7+erzcgf7qcCBNzRExg4ELsHsidgWb1jQD+Dw2g0hErBcs6fvsmnIHusThQC2oFS/SUT/gTGwEe+wKNy3pSeCDqKtfpKPB2EZ9Sd9vF5c72McdDtQGjE/iTIjk0ATgCnzG36Q9rcS2XD6s6rMokk+743PvfbTcwd7rdLCTEjgRInm2ATZO4F6s1yx25eyVmoG7gXOBIUmcOJEcOw2f+/Dd5Q42yulg30riTIgUxObAZ4EHsQozdqWdRKX/APAZYLMEz5NI3n0Xn3uy7H1YAyxxONj1SZwJkQIage0+eAW2dGfsyry3aS7WvT8R2DTxsyJSDP8g+XtzMVbXl/WowwFfqvo0iEgNsCNwDvB77L7yGCDU19QKvAj8DvhYqYwiUr1pJH+//rvjATqPun0B2DvhIMYCjcCKhPMVKZI2rKJ9Efht6e+GAO8qpV2B7YGtsT04+iV8/CZs9bDXsMbH5FJ6HhvEKCLJGYLdy0mb0vF/lGsAJK0OW3e47OIDIlKxpViL/t+d/r4OG9MzBvuMMALYCBiODTiswxoIg0v//TKsgm8u5bkQeAeYX0ozsU8Q2nVPJIzxdNNVX4V16vgQDQCAXVADQCSUFuD1UhKR7NnVKd91egBqO/1LrwbAu5zyFRERyRuvOrPbBsDr+HzP28MhTxERkTza3SHPhdjSwt26n+RHHi5Hy3yKiIj0pB82aD7peviuzgfq3AMA8HSioZhGbCCgiIiIdG1XfPbQWa9uD9UAgOSnF4qIiOSNV12pBoCIiEiKedWVz/TmP6rHdupK+vvDs8nFISIikksvkHz9u4I+jMN73KEAzaxdeERERETWtQE+O4I+Wu5g5T4B0NV/XKU6YE+HfEVERPJgb7qul6sRvQEAcJBTviIiIln3Hqd8Hy73l101AB5xKoRXcCIiIlnn9ZLcpzq9BpiHz0CE/lWHIiIiki/98RmAP6erA3bVA9AGPFZtNGUMROMAREREOtsXGOCQb+fdQv+ju8EG+gwgIiIShlf3f5dj+rprADzoUBDQQEAREZHOvOrGByr5Pw0EVpH894ilQEPFoYiIiORLA7CMwOPuuusBWAk8UUVAXRkM7OeQr4iISBa9GxjkkO8jwOqu/mVPCw7cl2xZ/uNIp3xFRESyxqtOvL+7f9lTA6Db/3MV1AAQERExRznlW9VL/GCgieS/S7QCI6spmIiISA5sgdWJSdezq4HG7g7cUw/AMnzWA6gBjnDIV0REJEuOxOrEpD2MDQLsUm82HZiUTFnWo88AIiJSdF51YSJ19/4k3zXRBszFZ9cjERGRLKgHFuBTx+6dVAEXORXwwCQKKCIikkGH4FO3LgDqejp4b97Am4F7ex9Pn5zglK+IiEjaedWB/wJaevqPetsF7zUO4GSnfEVERNLuOKd8E62zt8Snm6INeFeSBRUREcmACfjVq1v2pgC97QF4HZjSy/+2r/QZQEREiuZ4p3yfwersHvVlFP7NlZWlR2oAiIhI0ZzolO9NHpkeiE9XRSu97K4QERHJgW3x6/7ft7eF6EsPwMPAO33473urBjjdIV8REZE0+oBTvnPxWb0XgKvwabE87VVgERGRlHken7r0d56FPtmp0G3AOM+Ci4iIpMAu+NWjrmPqGrENgjwK/h3PgouIiKTAD/GpQ5cCA70L/zenwr+Kz45IIiIiaVADTMenDr0mRABnOBW+DdgzRAAiIiIReG2u1wacGiKADYBVTgFcGiIAERGRCH6OT925AhgcKoibnIKYB/QPFYSIiEggDVgd51F3/r2SAvVlHYCOrqvw/9eTjYBjnfIWERGJ5SSsjvPgVSeXNQi/2QAuyxiKiIhEdAc+deYyrE4O6poECl4uNQOjA8YhIiLiaRRWt3nUmX+qtFD1lf4fgf/DZwnfOuAsbK6kSDkDgR2A7YGRWOt3GDYIZhARWsNSCMtLaRmwqPTPc4CXgJeBlfGKJin3Uaxu83B1pf/HaubdNwBvARtWkUdXXsEe8G0OeUu2DAUOAt4LjMeuizFozQhJlzZsC9aXgeeA+0ppScxCSSrUANOArR3yngdsATQ55N2jK/Dp0mjDHvhSPHXAocAlwKP4dZspKXmnZuARrDfzEPzeACXdDsPvGvtlwDjWc0AXhUoiXR8wDolvJ+Ai4DXiP7iVlDzSm8DlwO5IkfwDv2tq74BxrKcGeLFMoZJITdjACcmvRuBT2G6QsR/OSkoh05PAeQRYu12i2hK/XswpAePo0lfwu0m+GzAOCWcwcD72RhT7QaykFDPNxXq+hiF5dAl+184FAePo0ub4tXDexgYbSj4Mw3Z9XED8B6+SUprSfODb2FLrkg8DsAaex/WyBpsBlQq34HdjnBEwDvFzHDCL+A9aJaU0p7eAD6FZLnnwEfyuk3+EC6NnJ+MX6EMB45Dk7QTcQ/wHq5JSltJdwI5Ilj2G3/VxfMA4etQPa7l6BRt1pKNUpB64GOuqiv0wVVLKYlqNfTKrZsE2icNzhtwbpPCauBi/gDUlMFtGAQ8Q/wGqpJSHdB+22Itkx434XQ8XhQuj90bjNxiwGdg2XChShcOwwZuxH5pKSnlK84BjkCzYAWjB5zpIdHp8pdsBlzMLGwzooQ74vFPekowa4AfAnaRodKpITmwE3Ax8Dw0QTLsLSLZu7ehm7BNAKh2NXwt4BbBxuFCkD+qB3xL/LUlJqQjpKmzclaTPSGxTKK/f/ohwofRdLfAqfsFfFCwS6a1GfKeBKikprZ9uwu49SZfv4/ebv4Jfz0JiPoPfCZiHtnpNkw2BfxP/YaikVMT0ED67sUplhuC7yNl54UKpXCPwDn4nIRXLHwpDgCeI/xBUUipyehy7FyW+r+L3O88nQy+/nlMC30ZdX7E1ALcT/+GnpKRkiwb1R2IahN+yv23YehCZsQm+AyE0IyCeWuBa4j/0lJSU1qarycD34Ry7EL/fdhWwabhQkuE5KvwttI1mLD8n/sNOSUlp/XQZEoP32/+V4UJJzo74LYbQhm0nK2F9kPgPOSUlpa7T2UhoX8Lv92wFxnkV3HtBiVvwW71qNjAW6x4Rf+OwAUdpHIgyD5gJLAOWl5JI0gZj44+GYCufpnFdkmXAnsBLsQtSEI3AdPwWP/snKdv4py8Owbe1+4VwoRRaI/Ac8d9u2rDK/nrgU8C+wHDHuEW6syF2DX4a+Cu+s5/6kp5Fn0hD8fz23wYcFC4UH0/iWxkMDRdKYf2GuA+0+cD/APuhgU6SXrXA/sCv8J0P3puUye/GGTMc39/50XCh+DkD3wv9e+FCKaTDifcQewH4EJriJNnTH/gw8CLx7p9D3aMsth/i+/udGi4UP/XA6/idpGVkcIpERvTHviWGfnC9DJyC3vYl+2qB0/BdIr2r9CK2Zockb3NsrJHXbzcN2wQvFz6J74X+y3ChFMo3CfvAWoHt9zAgQGwiITVg34s910cpl74WIrgCugLf321iuFD8NQCv4Xey1gDbBoumGLbBKuRQD6qnge2DRCYSz47YIL1Q99VyYKsQgRXIdlid4/WbzSCHPTcfw/dCvzZcKIVwPeEeUr9Cb/1SHAPxf4PsmK4JE1ZheD8bPxEulHDq8B8Qk/kpEykxDt9FnNpTK5rKKcX1acLcZy3AzoFiyrsDsOeW1281kxy+/bc7C98L/Sk0cCwJf8L/obQa+ECogERS6iTCjAv4Q6B48qwW/x1Q/ytYNBHUAVPwPYEfDRZNPm0DNOH7GzUDJ4QKSCTlTsTuCc97rgnYOlRAOXUuvr/R6xRgyvOp+J7Et9D+2NXw/jbZit1IIrLWRHzvuzbg18GiyZ+h2Fb0nr/Px4JFE1EN8Ay+J/KHwaLJlw3wndvahhZuEunKD/C995ajl6NK/Te+v81UcjTvvyfH43syV2EbBUnfeM/UuIcCXeQifVQP3IfvPfiRUMHkyPbYmCXP3+WUYNGkQA3wGL4n9NZg0eTHPfj9HnOAzcKFIpJJW2B7nHjdh3eFCyU37sS3rnoc/515U+cofE9q4VpVVdoK3+ktZwWLRCTbPoLffdgCjAkWSfZ9AP966ohg0aTMJHxP7BvYd23p2Tfw+x3uoYAtXJEK1QAP4Hc/fjVcKJk2FJiNbx11W7BoUmg8/lPOLgsWTbY9jM/5b8F+ZxHpvd3w65F7MGAcWfYLfOumNdiia4XmfZKbgd2DRZNNQ/Bb2/r6gHGI5MkN+FU8gwPGkUUT8F+b4afBokmxEcB8fE/0o2iFwO4ci895bwX2CBiHSJ7sid8z8aiAcWRNHf4r/s0DhocKKO0+i+/JbgM+Hyya7Pl/+Jzzu0MGIZJDXtMCfxwyiIz5Ev710XnBosmAfvgvEbwcbRnclafwOecfCRiDSB6dg8+9+UTIIDJkB/z3ZpiMrfkgHRyKf6vrIfQpoLMGfAZiLkOrjolUy2t1zjXYi5esVYvv7Iv2VNhpfz25Cf+T/6lg0WTDOHzO899CBiGSYzfic4/uEDKIDPgc/vXPDcGiyaCx2DK+nj/AMrRMcEcnoIaWSJqdj889elzIIFJua2ApvnXPamC7UAH1Rtq6w6cBv3Q+xiBsxzstTGO83gLuccpXpGi8BtPu6JRv1tQCv8d/auRlwCvOx8i8ENsutmGtaoHfkfy5XYgaWCJJqQEWk/x9+puQQaTYF/Gvb2ajVWl7LcT6yyuBnUMFlGJ3kfy5fSRoBCL557F52qSgEaTTrvh/dm4jpfvSpO0TQLtrsIEvngYA15b+LDKPVumLDnmKFNlLDnkW/Y20P3BV6U9PNwN/dT5GRdLaAAD4DLDE+Rg7A991PkbaeXz3mu6Qp0iRTXPIs+jTdC8BdnE+xmLgE87HqFiaGwCzgK8FOM4FwCEBjpNWHg+BxQ55ihSZx8tQkRsAhxFmHNiF2Pd/qUAttnOV9/eZmRR3XeZFJH8+zwkagUj+nUvy9+mioBGkxwhsq3jveuU+Uj4YOs09AGCbyXwcmz/paTTwB1L+Yznx+ASwzCFPkSLzuKeKuCNgDfbdfwvn46wCJmINgdRKewMAYCrwgwDHeT/F3DCoziHPVoc8RYqsxSFPj3s/7b4MHBPgON/DZ+BmITUAz+HfZbMG2D9QTGnhcR5PDRqBSP6dis+9WiT7Ys9473pkMhnZZyELPQBgP9o5+LSCO+qHTUEc4XwcEREJZ0Ps2e5dMbdio/6bnI+TiKw0AMAWwvBeJhhsPMAfKeZ4ABGRvKnBlvrdMsCxLgMeDnCcQhqEfVfx7sJpA74UKKbY9AlAJP30CaByXydMnTEVaAwUU2Htgc0K8P4xW4CjAsUUkxoAIumnBkBlDgea8a8v1gB7BYqp8L5KmBbdfPK/dbAaACLppwZA320FvEOYuuKLYUISsLELHpvYlEvPYp8e8koNAJH0UwOgbwYTZuZYG3Av2RpP9x+ZLDQ20vLDwIIAx9oF+N8AxxERkerVAL8Fxgc41kLgQ2jtkyhOI0wLrw34QqCYQlMPgEj6qQeg9y4kXL1wUqCYpAu/J8wP3QwcFyimkNQAEEk/NQB65xjCDPprA64MFJN0I+TUwCX4bx8ZmhoAIumnBkDPdgOWEqYueIUc7KaY1TEAHS0HziTMyktDgFvx30hCRER6bzPgn4TZ4KgZOAtrbGRaHhoAAE8AFwc61hbAjWjBBxGRNBgI/ANbxTWEbwKPBjqW9FIdMIkw3T9twHXkY7lgfQIQST99AiivFriBcM/928jPi3PubATMINzFcEmQqHypASCSfmoAlPcTwj3vp2ObCkmK7QasINxF8fkwYblRA0Ak/dQAWN+nCPecXwlMCBOWVOtswl0YraXjZZUaACLppwbAuj6A7dcS6jn/0TBhSVKuINzFsQY4IkxYiVMDQCT91ABY6xBgFeGe7z8PE5YkqR/wIOEukiXYToVZowaASPqpAWAmYM/aUM/1h4GGIJFFkOfRjE3AB4G5gY43BLiF/O8eKCISw7bYMzbUAjxvAydjPby5lOcGAMAs7FtRc6DjbQrcg21DKSIiyRgN3AmMDHS8ZqzumB3oeFHkvQEAViF/NeDxRmPrEWwW8JgiInk1Eqv8tw54zC8C9wU8njiqAa4l3HejNmwv6o1CBFcljQEQSb+ijgHYGJhC2Gf3X4JEJkENBP5N2AvpGdK/cIQaACLpV8QGwFBsmfeQz+xHKdAy70X4BNBuJXACtppTKLsCNxNmgwoRkbzYAOv2D7n4zqvAsdhCcoVQpAYA2IyAI4F3Ah5zP+AO7IIWEZHuDQVuB/YOeMz5wPsIWzdEV7QGAFgr7yRgdcBj7g/cTfo/B4iIxDQMe2HaL+Ax12CfWF4KeEyJ7HRsGd+Q35eeBEaECK4PNAZAJP2KMAZgGPAYYZ/JrcBZIYKT9PkmYS+2NuBp0jU7QA0AkfTLewNgOPA44Z/HXwkRnKTX7wh/0T2DTW9JAzUARNIvzw2ATYDJhH8OXxkiOEm3ftho09AX31RgTID4eqIGgEj65bUBMAZ4kfDP39uB+gDxSQZsADxL+IvwTWB8gPi6owaASPrlsQGwIzATn7i6S89jMw0Kr4izAMpZAhxD2DUCADbHlpvcN/BxRURi2hO4H1s6PaRp2NbtiwMfVzJgDDCD8C3SpcDh/uGVpR4AkfTLUw/AwVgFHPo5O4uw+wlIBu0IzCH8xbkSODFAfJ2pASCSfnlpAJwCrKqivJWmt4HtA8QnObALtjJU6Iu0GfhsgPg6UgNAJP3y0AA4H2hJsOy9TQuB3QPEJzmyDzY2IPTF2gZcTrjxGWoAiKRflhsAdcDPnMrfU1oM7OUfouTRAcAy4ly4NxBmVyo1AETSL6sNgEHAP5zK3lNaAbzHP0TJs8OJ882qDduacqRzfGoAiKRfFhsAGwEPOZW7p7Qam9klUrWTgCbiXMjTgJ0cY1MDQCT9stYAGI9Nq47xzGzCtn4XScxZxBnA0oaNRTjOKS41AETSL0sNgOOJN36qBTjTKS4puA9gW0fGuLBbgUuAmoRjUgNAJP2y0ACoAS4k3otSM/DhhGMSWcdx2Jz9GBd4G3AtyQ4OVANAJP3S3gAYAPzJqYy9SauxT7Ui7g7GVu+LdbE/A2yVUCxqAIikX5obAKOIs5Vve1oOHJlQLCK98m7iLGfZnuaRzEWvBoBI+qW1AXAwtsperOfgUuCQBOIQ6bMJwDvEu/jbxwVUs2iQGgAi6Ze2BkD79/5mp3L1Ji1AG6lJZDsDs4l3E7QBdwGbVFh+NQBE0i9NDYARwG1O5eltehvYtcLyiyRqB2ynqZg3xExgvwrKrgaASPqlpQEwgXjz+9vTbOzFSyQ1tib+jbEa23CjL1MF1QAQSb/YDYAa4HPYMybmM+5VkhsALZKoUcBzxL1B2oBb6P0nATUARNIvZgNgJHCr0/H7kp4FNu9lmUWiGIxVwLFvljn0bi1sNQBE0i9WA+Aw4o9xagPuBIb2+myJRFQP/Ir4N00rtrVw/27KqgaASPqFbgD0Ay4i3qp+HdNvS+URyZSvY5Vw7BvoSWBcF2VUA0Ak/UI2AHYCnnY6Xl9SK/CVis6WSEqcQtylg9vTSmzebl2n8tQza6IAAAjvSURBVKkBIJJ+IRoAtcBEbGW92M+rVcAZ1ZwwkbTYD5hL/JuqDXgYm7bYTg0AkfTzbgBsA9zndIy+pvnAQdWeMJE0GQu8RPybqw1YgfUG1DrlrwaASLK8GgA12Ft/zL1NOqZprPuCIpIbG2Nv4LFvsvZ0t1O+agCIJMurAeD1DKgkPQRslNQJE0mjgcDVxL/ZPJMaACLJ8moApCX9BdtSWAKqZhMZqcxK4IPAJ4CmyGUREYmpGRvpfyY28E8CUgMgniuBQ7FNLUREiqZ9S/MfxS5IUakBENcDwJ7YuAARkaJ4Anv23R27IEWmBkB8b2JTXtQKFpEiuBI4ANvBVCJSAyAd2r+DnY1N0RMRyZtVwDnY+Kc1kcsiqAGQNn/GWsavxS6IiEiCZmI9nb+LXRBZSw2A9HkG2Au4I3ZBREQScDuwO/B47ILIutQASKf5wLHYZkKaKigiWdQEfBV7li2IXBaRTNqT9CwhrIWAROLI2kJA07E9UCTF1AOQfk8AuwE/i10QEZFe+BOwC5renHpqAGTDSuB84GTs84CISNoswlY5/RCwLHJZRHJpU+A24nfxdZdmYg2WgU7nQKQoGrDd+mYS/77uLt0FbOF0DkSkgxqsgl1N/Bu/uzQH23a40ec0iORWf6zif4P493F3aQ1wEepNFgluPDCZ+A+BntJc1BAQ6Y1BWOP+TeLftz2lqcAePqdBRHqjEfgptppg7AdCbxoC30Z7fot0tjH2Jj2P+PdpT6kZuBQ16EVSY3fgSeI/HHqTVgFXATu4nAmR7NgauBxYTvz7sjdpMrCPy5kQkar0A76BVbCxHxS9fZO4Flv5UKRI9gauIxs9d23YTKSvYc8YEUmxbbFtNmM/NPqSnsAGPWnmgORVA7agzyTi3299SQ8C4xzOh4g4qcHm484n/gOkL+lt4BJgTPKnRCSKTbFBsGkf0d85LcIGJGqEv0hGjQJuJP7DpK9pDfZ54FCsMSOSJbXAYVg3fxPx76e+phuAzRM/KyISxWnY23XsB0slaRq2MZIeSJJ2W2DjcKYT/76pJM0GTkn8rIhIdEOBy8jmG0kbNmDqn8D7gfqEz41IpfoBxwM3kZ1BfZ3TKuBHwJCEz42IpMwO2B7dsR861aT5wBXAgegTgcSxMzZeJas9a+3pJmBswudGRFLuOGAG8R9A1abXsQex1hUQb1thA/peJv51X22aChyd6NkRkUxpBL6F7d4V+4GURHoMe0Bvm+RJkkLbDvgKNlU19vWdRHoHOA99RhORks2wLvWsfsMsl6Zgy6tOSO40SUHsjDUkHyT+dZxUasLucS3FLSJl7Ur2FirpTZqKfSY4CL35yPrqgfdgA+FeJP71mnS6DS3mIyK9dCTZ2Vugr2kBcA22UNLGSZ0wyZxNgA9j600sJP516ZEeB45I6oSJSHHUYEuX5vGNqD21AI8AFwOHAAMSOXOSRgOxhaW+DzyK/faxrz+v9AJwMpohIyJVqgfOAWYS/8HmnVYC/8I2PtkXfS7IsnrsN/w6cBf228a+vrzT68BHgboEzp+IyH80YN3m04j/oAuVlmEDwS7Bpk2OqPosipch2LoQF2Jz2/ParV8uzcTW7VcPloi46g98EnvbiP3gC51agOeAXwMfwwZNaovU8PoBu2G/wRXYb5LnLv2u0gzgE1jjXKRP9H1IqtGAPYAvxBZIKapVwGTgqVJ6EpuCuDpmoXJkADYtbw9sSucewC5YQ7SopmMzFv6AbZwl0mdqAEgSaoFjsQWF9oxcljR5C2sIvNDhz6eB5TELlWL9gO2BnbAKv/3PHdA37XZPAZcD/4et2SFSMTUAJEk1wDFYj8C7I5clrVqwfeGndUjTO/zz4nhFC2Iotu5857QNMBrtPV9OK3Az8BPg/shlkRxRA0C87A98ATgBvb31xTJgFrYt65ul9BY2yGt+p9QSqYyd1WGDI9vTRlhlvhkwCtsid7PS3w2OVMYsWgX8CbgUm4orkig1AMTbVsBnsGmEQ+MWJXcWYuu6z8caDkuwqW7LsZ6ElcAKbCzCig7/v5bSf9vRBqzbUGvEvrEPwr7BDy3988DSfzuYtZX98ARjEvtNfwX8ApgbuSySY2oASChDsPnJn0Eb9YiU8yrwU2xg34ru/1OR6qkBIKHVYivuTQRORAvtSLG1AncDVwJ/Jz2fdaQA1ACQmDbDFhY6DxgTuSwiIb0FXIV19b8euSxSUGoASBrUA+/D1hQ4GvUKSD41Ybvy/Q64BU3jk8jUAJC02RQ4HRsvsGvksogk4UXsu/4fgDlRSyLSgRoAkmb7Yp8ITsVGm4tkxTzgeqyb/9HIZREpSw0AyYI64GCsMXACNqNAJG1WYgv2/Am4HevyF0ktNQAkawYBxwOnAUei3c8krpXAHcB1wI1o+p5kiBoAkmUDgcOwTwTqGZBQVgJ3YV38/2D9RZVEMkENAMmLgcBRWO/AMcDGcYsjOTMXuBV7y78DawSIZJoaAJJHtcDuwHHY9MI90LUuffcCcBPwL+BeNG1PckYPRSmCMVjvwBHYKoRau17KWYB17U/CBvHNilscEV9qAEjR1AF7AoeX0n7YPvRSPGuAh7EKfxLwJFqKVwpEDQApukbsE8EB2IDCA7DxBJI/TcBkrEv/IeA+NIBPCkwNAJF19Qf2Bt6NLUS0D7BJ1BJJpeZgi/A8AjwAPIa99YsIagCI9MZY1jYG9gF2QesPpM1K7O3+UdZW+tOjlkgk5dQAEOm7emAHYCdgZ2AC1jDQ1MMwlgDPYd/sp2Cj9R8HVscslEjWqAEgkpzhWINgpw5/7ooaBpVaAryCVfBTOvz5GtAWsVwiuaAGgIi/zYFtS2lsp38eGrFcabAImAa82uHP9vRWxHKJ5J4aACJxbQCMBrYERpX+eQy2LfJmWO/Bxtj0xSxpwXbEmwu8XUqvA29g8+tnltLSWAUUKTo1AETSrwZrBGxS+nN4KQ0rpfZ/Hog1KPpj0xsHAQ1YL0Nth/wGsP5Ux5XAqg7/uxVYjI2aX45tcrMa65ZfCSzE3t4XdfjnhViFP6+U1E0vkmL/H62JsLV304PoAAAAAElFTkSuQmCC" />
                                    </defs>
                                </svg>
                                <span style="padding-left:0.5vw"><?php echo $dado['autor']; ?></span>
                            </div>
                            <span class="forum-card-date"><?php echo date("d/m/Y", strtotime($dado['data_postagem'])); ?></span>
                        </div>
                        <div class="forum-card-title" id="titulo"><?php echo $dado['titulo']; ?></div>
                        <div class="forum-card-text" id="conteudo">
                            <?php echo $dado['conteudo']; ?>
                            <!--<?php $_SESSION['id_mensagemDenuncia'] = $dado['id_mensagem']; ?>-->
                        </div>
                        <div class="forum-card-footer">
                            <div class="forum-card-actions">
                                <span class="forum-like"  data-id="<?php echo $dado['id_mensagem']; ?>" onclick="curtirPost(<?php echo $dado['id_mensagem']; ?>, this)" style="cursor: pointer;">
									<svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg" >
                                        <path d="M15 10C15 10 15 10 14.05 8.75C12.95 7.3 11.325 6.25 9.375 6.25C6.2625 6.25 3.75 8.7625 3.75 11.875C3.75 13.0375 4.1 14.1125 4.7 15C5.7125 16.5125 15 26.25 15 26.25M15 10C15 10 15 10 15.95 8.75C17.05 7.3 18.675 6.25 20.625 6.25C23.7375 6.25 26.25 8.7625 26.25 11.875C26.25 13.0375 25.9 14.1125 25.3 15C24.2875 16.5125 15 26.25 15 26.25" stroke="#573280" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg><span class="curtidas-count"><?php echo $dado['curtidas']; ?></span></span>
                                <span class="forum-comment">
    <a href="comment.php?id=<?php echo $dado['id_mensagem']; ?>" style="text-decoration: none; color: inherit; display: flex;text-align: center;justify-content: center;align-items: center;">
        <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M2.8125 5.625V24.375H11.7994L15 27.5756L18.2006 24.375H27.1875V5.625H2.8125ZM4.6875 7.5H25.3125V22.5H17.4244L15 24.9244L12.5756 22.5H4.6875V7.5ZM8.4375 10.3125V12.1875H21.5625V10.3125H8.4375ZM8.4375 14.0625V15.9375H21.5625V14.0625H8.4375ZM8.4375 17.8125V19.6875H17.8125V17.8125H8.4375Z" fill="#573280" />
        </svg>
        <?php echo $dado['qtd_comentarios']; ?>
    </a>
</span>
                            </div>
                            <span onclick="pop_denuncia(<?php echo $dado['id_mensagem']; ?>)" class="forum-card-more"><svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.5 22.875C13.5 22.3777 13.6975 21.9008 14.0492 21.5492C14.4008 21.1975 14.8777 21 15.375 21C15.8723 21 16.3492 21.1975 16.7008 21.5492C17.0525 21.9008 17.25 22.3777 17.25 22.875C17.25 23.3723 17.0525 23.8492 16.7008 24.2008C16.3492 24.5525 15.8723 24.75 15.375 24.75C14.8777 24.75 14.4008 24.5525 14.0492 24.2008C13.6975 23.8492 13.5 23.3723 13.5 22.875ZM13.5 15.375C13.5 14.8777 13.6975 14.4008 14.0492 14.0492C14.4008 13.6975 14.8777 13.5 15.375 13.5C15.8723 13.5 16.3492 13.6975 16.7008 14.0492C17.0525 14.4008 17.25 14.8777 17.25 15.375C17.25 15.8723 17.0525 16.3492 16.7008 16.7008C16.3492 17.0525 15.8723 17.25 15.375 17.25C14.8777 17.25 14.4008 17.0525 14.0492 16.7008C13.6975 16.3492 13.5 15.8723 13.5 15.375ZM13.5 7.875C13.5 7.37772 13.6975 6.90081 14.0492 6.54917C14.4008 6.19754 14.8777 6 15.375 6C15.8723 6 16.3492 6.19754 16.7008 6.54917C17.0525 6.90081 17.25 7.37772 17.25 7.875C17.25 8.37228 17.0525 8.84919 16.7008 9.20083C16.3492 9.55246 15.8723 9.75 15.375 9.75C14.8777 9.75 14.4008 9.55246 14.0492 9.20083C13.6975 8.84919 13.5 8.37228 13.5 7.875Z" fill="#A7A7A7" />
                                </svg></span>
                        </div>
						               <div style="background: linear-gradient(to top, #FEFEFF 10%, #6D6193 670%); height:45px; border:1px solid #6D6193; border-radius:100px; display:flex; align-items:center; padding:0 10px; margin-top: 1.5vw;">
    <input id="titulo_digitado" name="titulo" type="text" placeholder="Digite seu comentário" style="flex:1; border:none; outline:none; background:transparent; font-size:16px;">
    <svg onclick="enviarComentario();" xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 41 41" fill="none" style="cursor:pointer; border: 1px ">
        <path d="M35.4869 6.67969C35.8191 6.67969 36.1377 6.81164 36.3726 7.04653C36.6074 7.28142 36.7394 7.59999 36.7394 7.93217V18.787C36.7394 20.4479 36.0796 22.0408 34.9052 23.2152C33.7308 24.3896 32.1379 25.0494 30.477 25.0494H7.66014L13.8724 31.2617C14.0843 31.474 14.213 31.7552 14.235 32.0543C14.2571 32.3534 14.1711 32.6505 13.9927 32.8916L13.8724 33.0319C13.6603 33.2444 13.3788 33.3737 13.0793 33.396C12.7798 33.4184 12.4823 33.3324 12.2409 33.1538L12.1006 33.0319L3.75074 24.682C3.53862 24.4699 3.40965 24.1888 3.38728 23.8897C3.36491 23.5906 3.45062 23.2934 3.62883 23.0521L3.75074 22.9118L12.1006 14.562C12.3244 14.3399 12.6237 14.2104 12.9387 14.1993C13.2537 14.1883 13.5614 14.2964 13.8002 14.5021C14.0391 14.7079 14.1915 14.9961 14.2272 15.3093C14.2629 15.6225 14.1791 15.9377 13.9927 16.1919L13.8724 16.3321L7.66014 22.5444H30.4803C31.4321 22.5441 32.3484 22.1826 33.0439 21.5329C33.7395 20.8832 34.1626 19.9937 34.2278 19.0442L34.2378 18.787V7.93217C34.2378 7.59999 34.3697 7.28142 34.6046 7.04653C34.8395 6.81164 35.1581 6.67969 35.4903 6.67969" fill="#573280"/>
    </svg>
	
</div>
                    </div>
                <?php
                }
                ?>

				<!--para coments-->
				<?php


                foreach ($result1 as $coment) {				
                ?>
                    <div class="forum-card" style="box-shadow:none">
                        <div class="forum-card-header">
                            <div class="forum-card-user">
                                <svg width="45" height="45" viewBox="0 0 45 45" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <ellipse cx="22.5" cy="22.3299" rx="22.5" ry="22.3299" fill="#8B7AC2" fill-opacity="0.26" />
                                    <rect x="0.427734" y="0.855469" width="44.1451" height="44.1451" fill="url(#pattern0_64_271)" />
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M16.5597 2.07853C12.5458 3.11912 9.38492 5.00945 6.17998 8.28601C-2.38652 17.0443 -2.00351 30.238 7.05771 38.524C12.471 43.4736 19.0922 45.4985 26.0876 44.344C30.8967 43.5504 34.2826 41.8912 37.9658 38.524C45.0487 32.0478 47.0072 21.9658 42.8134 13.5764C41.2593 10.4679 36.9219 5.96046 33.7747 4.18356C28.8677 1.41378 22.2476 0.60432 16.5597 2.07853ZM29.3195 4.22703C32.9234 5.43778 37.1244 8.51448 39.2408 11.4931C43.8507 17.9794 44.4158 24.9142 40.9016 31.858C39.56 34.509 35.0943 39.4178 34.0246 39.4178C33.7455 39.4178 33.5177 37.9425 33.5177 36.1385C33.5177 33.5018 33.2833 32.6197 32.3214 31.6327C31.1702 30.4527 30.7998 30.406 22.5888 30.406C14.5825 30.406 13.9739 30.4776 12.7792 31.5585C11.7083 32.528 11.5058 33.2447 11.5058 36.0643C11.5058 37.9086 11.2807 39.4178 11.0061 39.4178C10.731 39.4178 9.41244 38.3936 8.07576 37.142C3.45821 32.8191 1.01543 25.7523 2.12758 19.9366C4.50432 7.51312 17.2261 0.162746 29.3195 4.22703ZM18.2981 13.4725C17.2861 14.0975 16.1778 15.4662 15.644 16.7522C12.7269 23.775 21.3968 29.6766 27.438 24.7801C31.0122 21.8831 30.6182 15.6936 26.7133 13.3999C24.4125 12.0481 20.5521 12.0815 18.2981 13.4725ZM24.8868 14.565C30.1499 17.1578 28.39 24.5749 22.5117 24.5749C16.8932 24.5749 14.7663 17.3449 19.6364 14.7994C21.4502 13.851 23.2723 13.7699 24.8868 14.565ZM31.0023 32.8291C31.6197 33.4244 31.8668 34.6993 31.8668 37.2926V40.9227L28.9778 41.8589C25.2847 43.0558 19.7388 43.0558 16.0457 41.8589L13.1567 40.9227V37.4288C13.1567 32.114 13.3603 31.9963 22.558 31.9963C28.7147 31.9963 30.2996 32.1527 31.0023 32.8291Z" fill="#573280" />
                                    <defs>
                                        <pattern id="pattern0_64_271" patternContentUnits="objectBoundingBox" width="1" height="1">
                                            <use xlink:href="#image0_64_271" transform="scale(0.00195312)" />
                                        </pattern>
                                        <image id="image0_64_271" width="512" height="512" preserveAspectRatio="none" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAA7DAAAOwwHHb6hkAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzt3Xe8XUW5//HPKTlJThKSECCUJJTQApEWOojSm0gHpdjAeMWCiopdVFT0/kSwXIVrRb00FZFOpIP0FgihJYQEAklI7znt98ezjzk52aftvZ6ZVb7v12tewYCz5ll7rTWzZk2pQUTSrh7YuJRGAsOA4aU/O6ZBQGPpzwZgKFBX+ncdDQb6dfq7JmBZp79bBDQDS4A1wHJgRenPRZ3SwtKfc4B5wFygpeKIRcRdTewCiBTchsAoYEwpjSqlLYBNSmljsnevtrG2ITAHmA3MAt4o/Tmz9M8LYhVQpOiy9lARyZoarELftlMaW/pzULyipcIyYBrwaqc0DWsgtMUrmki+qQEgkpzNgZ2AnTv8uQswJGahMmw11hCYArzQ4c+pQGvEconkghoAIn1XD+wATCilnYA9sO588bcMeJa1DYIngSeAVTELJZI1agCIdK8G2A7Yp0N6F9A/ZqFkPauBycBjwKPAI8ArUUskknJqAIisqxHYF3g3ayt8vdln03ysMfAocH/pz5VRSySSImoASNENAvYDDgQOwCp+vd3nUzP26eBfwEPAA9jURZFCUgNAiqYee8M/vJT2Kv2dFE8z1iswqZQeK/2dSCGoASBFMBY4CqvwDwY2iFscSanFwD1YY+A24LW4xRHxpQaA5FEdsBtwHPA+bKS+SF9NB24GbgLuw1ZLFMkNNQAkLwYBRwMnYG/7I+IWR3JmPtYrcCNwK7YkskimqQEgWdYIHAqcCpyIrXEv4m0VNpDweqxBsDhucUQqowaAZM0QrLI/DTgMjdiXuFZjYwauA25g/Q2VRFJLDQDJggbgSPSmL+nW3jNwFdYzsCZucUS6pwaApFUNNi//Q8Ap2Pa3IlmxAPgr1hh4KHJZRMpSA0DSZjOse/8cbMldkax7Gbga+D3weuSyiPyHGgCSBg3A+4GPYl39dXGLI+KiBbgdawj8E00rlMjUAJCYNgfOBj4NjIpcFpGQ5gB/AH4NzIhaEiksNQAktFrgEGAiNqBPy/BKkbUCdwNXAn/HeglEglADQELZAPuu/2lgm8hlEUmjacDlwO+A5ZHLIgWgBoB4Gwt8Fvu+PyRyWfJkDbaTXbnUhM1HX4lNTVvKupvcLGH9N8061t0joR77vQYAA7Gpl/2AYZ3S8NKf/RKLTBZgnwZ+DrwduSySY2oAiJf3AF/A1uKvjVyWLFkKzARmldJsYC7wVunPeaW/S9uCM0OwGRybABtj4zs2BrbAxneMKSWt4dB7q4G/AJcCUyKXRXJIDQBJUi02mv9CbMtdWV8zVsG/inX5vlpK07EKP+/Lyg4DRmOfgbbFeoi2LaUxaAZIOW3YPgQ/wcYLiCRCDQBJQgNwBvBlYFzksqRFEzb/+4VSmlL682U0/asrDcD2wE4d0s7AdugTQ7unsIbAdaz7WUekz9QAkGo0AOcCX6XY0/iWAc8CT3dIz6OKPikNwHhg9w5pV2wHyKKaCVwC/BYtOSwiAdVjFf8MrHuyaOkVbA73x7G3VI1xCK8O6x2YCPwR+4wS+7qIkV4DPoam04qIs1psQ56Xif/gC5WasO77K7B9CcZUfRbFy0jgOOzN+EFsBkTs6ydkQ2AiGkMhIgmrBU7HvmHHftB5p2XALcDXgIOwKXCSTY3YbJSvA7dic+tjX1/eaQrWSNfnXRGp2mHAk8R/sHmmadgb/nHYvHfJpwHY9XwJ8ATxrzvP9DxqCIhIhY4hvw/JZdhmLJ8Etk7qhEnmbAOcB9xEfnsHHgOOSuqEiUi+TQDuIf6DK+k0FZs+dRjQP7GzJXkxADgcW3TnReJfr0mnSdhMChGR9WyBdYM3E/9hlVSajq2tvkeC50mKYWfgIqzhGPs6Tiq1AFdhqzWKiDAEuJj8dIG+Anwf2CXJkySFthvwA/Iz1XA+tj+Hpg6KFNhx2IIisR9I1abXsTf9A9GgJ/HV3jPwCvGv+2rTS8CxiZ4dEUm9XYEHiP8AqibNxb7X7oMqfQmvBtvv4jJsg6bY90M16SZsCWYRybFh2JtyE/EfOpWkFmyBl4lofr6kRwM25W4S0Er8+6SStAZ7NgxL+NyISGQ12Cp2c4n/oKkkzca+wW6T9IkRSdi2wA+x7Ztj3zeVpLeBDyR+VkQkirHAncR/sPQ1tWBvVKeineAke+qwKafXkc0et1vQstcimdUf+BawkvgPk76kN7BBVqMTPyMicYwBvgO8Sfz7qy9pMfAptNmVSKYcQPbmLz8NnI3e9iW/GrBPcc8S/37rS3oQGOdwPkQkQQOxdc6ztJjPg9h0RI3klyI5EBt9n5VBg2uwZ4tW0RRJoQOweb2xHxS9SauxFcne5XImRLJjF2wFzqx8qnsOm/4oIikwGPgl2XiTWICNkN7c5UyIZNcWwI+ARcS/T3tKLdiUwUEuZ0JEemUv4GXiPxB6SrOBz2GNFRHp2hDgC9h0vNj3bU/pRWBPn9MgIl2pAc7HutJjPwS6S/OAC4FGn9MgkluN2D2e9oZAEzZrp87lLIjIOkYD9xL/xu8uzcceChu4nAGR4hiENaIXEP++7i79Gy3UJeLqFKxyjX2zd5WWYiOFtZyoSLKGYA2BNI8RWASc6XUCRIpqCDZSOPYN3lVahg0K0j7jIr5GYL1ri4l/33eVrkMvASKJ2A+YTvybulxahe3Ip4pfJKyR2E6EaR0H9Cq2U6eIVKAea+mndR3xG7B9BkQknu2AfxL/eVAuNQHfRAMERfpkI2wjnNg3cLk0FTjaL3QRqcAhwGTiPx/KpXuxHgsR6cEewGvEv2k7p/nYtKR6v9BFpAr1wETSue33LPRJQKRbHwJWEP9m7ZiasAGIGznGLSLJGY7Nxknb+IBVwMcd4xbJpP7AlcS/QTunScB4x7hFxM8OwC3Ef450TldhG5eJFN4Y4DHi35Qd0wzgfY4xi0g4xwMzif9c6ZgeAUZ5Bi2Sdu8hXUt9tmLd/UM8gxaR4BpJ31bh84DDPIMWSaP2tfzXEP8mbE/Po20+RfJuf2AK8Z837akZW+GwxjNokbRoBK4n/o3XnlYB3wYaPIMWkdToD3yHdA0SvBaNC5Cc2wh4kPg3W3v6N7Cza8QiklbjgYeJ/xxqT4+i9QIkp7YDXib+TdYGLMe63bRCl0ix1WBrBywh/nOpDVv2fJxrxCKBHUx6tvO8E9tSWESk3ZbAv4j/fGrDFh17j2+4ImGcDqwk/k21Cnvrr/UNV0Qyqn1w8iriP69WA2f5hivipwbbzKeV+DfTC8DurtGKSF6MJx37CrRiz1DNEJBMaQD+SDpuoCuwmQciIr01ALicdLzA/B7o5xuuSDKGAXcT/6aZCxznHKuI5NuRwGziP8/+hT1bRVJrDOlYZOMWNJ1GRJKxKXA78Z9rz6HlgyWltgKmEfcGWYkG+olI8tqnCy4n7jNuBrCtb6gifbMj8AZxb4zXgb28AxWRQtsNm6sf81n3FtqlVFJid+x7e8wb4lZgQ+9ARUSAEcT/JDAHa4yIRLMXtmhFrJugFdvhS13+IhJSDfa5sYV4z7+FwH7egYqUcxBxl89cDJzoHqWISNfeh1XEsZ6Dy9CWwhLY0cAK4l30U9F62SKSDtthI/RjPQ9XAe93j1IEm1sfc6nMq4FB7lGKiPTeYOAa4j0XVwOnuEcphfZBoIk4F3gT9s1NRCStJgJriPOMbAY+4h6hFNLZxBvwsgg43D9EEZGqHUW88VEtaBMhSdgJxHvzfwNNdxGRbBmPrU0SqyfgNP8QpQgOJ943/2fR0pcikk2bAU8S59m5GjjWP0TJswOwaSYxLuA7gA38QxQRcTMYuIk4z9AVwHvdI5Rc2od437H+F6j3D1FExF0d8AviPEuXAQf6hyh5sitxVvhrBS7yD09EJLjziTOQehGwR4D4JAe2B94m/EW6CvhAgPhERGI5mTiLqM0FdgoQn2TYtsCbhL84F6A1rUWkGA4kzvLBbwDbBIhPMmg0ttd06ItSu1qJSNHsAcwj/PN2OppZJZ1sAEwm/MWofa1FpKh2xN7KQz93pwDDAsQnGdAPmET4i3AG9slBRKSotgKmEf75ew/Q4B+epFkN8AfCX3wvYp8cRESKbgzwEuGfw78NEZyk10WEv+imAJsHiE1EJCtGYiufhn4efz1EcJI+H8Dm3Ye82J4ANgoRnIhIxgwHHiHsM7kV2+hNCuQgwq/v/wBa2ldEpDuDgbsJ+2xeDRwSIjiJbxw27z505T8oRHAiIhk3CHiQsM/o+cAOIYKTeDYCXiHshfU01rUlIiK9swHwOGGf1dOxsQiSQwOBhwl7QU0GRoQITkQkZ4YBTxH2mf0Y0BgiOAmnBriesBfSS6g1KSJSjU2Blwn77L46SGQSzIWEvYBmAlsGiUxEJN9GYd3zIZ/hXwgSmbg7BGgi3IXzBjA2SGQiIsUwlrAbtTUB7w0RmPgZjW0DGeqi0ZaTIiI+diDsVu1z0MZBmdUfG9AR6mJZBEwIEpmISDHtSthp3I9gdYlkzG8Id5GsAPYLE5aISKEdCKwk3PP9V2HCkqRMJNzF0QKcHCYsEREBTsWevaGe8+eECUuqtTdhl/m9IExYIiLSwVcI95xfCewZJiyp1AjgNcJdFFeGCUtERMr4JeGe96+jzdxSqx64i3AXw81AXZDIRESknHrgNsI99+9Az/1UuohwF8GT2K5VIiIS1xBsz5VQz/+vhQlLemsvYA1hfvw30NxQEZE02RxbgTVEHdAE7BsmLOnJYMKtFb0Em4cqIiLpMh5bjyVEXfAq1vMgkf2RMD/4GuDwQDGJiEjfHUW4pd9/Gygm6cIphPmh24DzA8UkIiKV+yLh6oXTA8UknYwC5hPmR9b2kCIi2VADXEuYumEhMCZMWNKuFribMD/wZGBQmLBERCQBg4HnCVNH3IemBgb1dcL8sEuAHQPFJCIiydmecIMCvxwopsKbAKzG/wdtBU4MFJOIiCTv/diz3Lu+WIMtQy+OQk75+26gmERExM8PCFNnvIg+F7v6H8L8kHeibzoiInlQS7jlgi8NFFPhvJcwXTkzsE2FREQkHzYEpuNff7QA+weKqTAasZWXvH+8FcBugWISEZFwJhBmq/jJQL9AMRXC5YTpvvl0qIBERCS4LxCmLvlGqIDybj+gGf8f7HZsAQkREcmnGuAW/OuTVcBOgWLKrf7AVPx/rDnAyEAxiYhIPJsB8/CvVx7ABiBKhb6N/4/UChwXKiAREYnuaMIMKv9kqIDyZjtgJf4/0M9DBSQiIqnxa/zrl8XYvjXSR//C/8eZAgwMFZCIiKRGI2E+Md8cKqC8+DD+P8oqYNdQAYmISOrsTpil5U8LFVDWDQfm4v+DfD5UQCIiklpfwr++eRsYGiqgLPsF/j/GnWjKn4iI2Ej9EJ+cLwsVUFaNB5rw/RGWAVuHCkhERFJvDLAU37qnCdglVEBZUwPci38r7FOB4hERkez4HP71z/2o97mss/A/+Y+ghRlERGR9tcBD+NdDqRkQmJaWyBDgJWyFJi+rgT2AFxyPIRLTJsBWHdJobGfLjUppKDbIFqCBtXuXLwfWlP55ITZ3+Z1Smg/MwnbJnAG8hq2iJpJH44EnsfvDyyxgR2zzOQEuxr/V9e1g0Yj4qsN2rTwX2yjrHmAB/vdQe5oP3F069jmlstS5RiwSznfxv4e+FSyalBuNvYF4nuzn8W3RiXhqAA4BLgImAUsIV9n3Ni3BZtdcBByM7jfJrv5YT7Hn/bIU3x7vzPgjvie6Bdg3WDQiyRgD/BdwI/6jk70ecDcAn8Aa+SJZciBWd3jeI78JFk1K7Y7/SdbcS8mKLYDzgQcJs1FJyDQFuLAUo0gW/BLfe6IFG5dWWPfge4JnAINDBSNSgQHAmdgUWO/GcBpSCzZ+4Aysq1UkrTYAZuJ7P0wKFk3KHIP/w+Z9waIR6ZsdsN6p+cSvlGOld4Cfls6FSBqdgP99cFSwaFLkUXxPamFbVpJqBwLXAc3Er4DTklqx+/W4Ks6riJfb8b3+n6Fg69N4t6rWAOOCRSPSvRrgROAJ4le2aU+PAe8nPWuUiOyM/xL1qVkcyFsN1uLxPJk/DRaNSPcOAx4nfsWatfQscGoF51vEg/cmdS8B9cGiieh0fE/kPNaudiYSy97YaP7YFWnW0wPAXn089yJJG4H/eJ1zg0UTSR3+CyycFywakfVtAVxF/qbxxUwtwO/RwikS12fwvc5nkvOZMWfjewInU5BuFEmdeuDL2HbTsSvMvKalwAXoHpc46rH1LDyv8dy+wNZh3zk8T94RwaIRWWsXbPBa7AqyKOkZYM9e/TIiyToU32s7t70A5+J74m4IF4oIYDfqD/EfIay0floDfB/tOSDh/RPfa/uT4UIJox8wHb8TthrYLlg0IjbN9CniV4RFT88B7+rhtxJJ0lhgFX7XdO56Ac7D9yHwk3ChSMHVYNfzCuJXfkqWlmObDomEchm+13RurucGfNdTXgpsEiwaKbIhwPXEr/CUyqergUFd/noiydkU323sXyMng10/hu9N/4NwoUiBbYd1N8eu5JS6T1PRKqASxo/xvZbPCheKj1p85/0vBjYMFo0U1XHYtRa7clPqXVqEbTYm4mkjYAl+1/FkMr4k9on43ugXBYtEimoiGuWfxdQMfLrM7ymSpO/hex0f61l479bFw8C+TnkvALbB3sxEklaLDS79XOyCVOFtYAY2BmcetpTpfGwE82psICNAIzbqeAC25OkIbFzNaGAr7HtnVv0EW6CpNXZBJJeGYd/rhznl/wBwkFPert6Db8voa+FCkYLph23ZG/sttrdpFbbvwE+BjwITgIEJno/GUp4fKx3jIXynQSWdrsZ+UxEP38T3+t0/XCjJuRG/EzIXGBwuFCmQAcBNxK+0ukvNWCX8DezhEGPO8ADgAOzh93CpTLHPS3fpRnI2t1pSYwjWw+Z17f41XCjJGItt4OF1Qi4IF4oUyCBgEvErq3JpDXAL8GHSOfB1BPAR4FasrLHPV7l0J5omKD6+jN9124x9isuMy/E7GbNJtntTBOyaupv4lVTn9AzwKdJZ6XdlQ2wA3rPEP3+d011Y74VIkgZhY268rtvMLHY3FN+pEVkelCXp1IC9ucaunNrTGuDPwN6eQQeyD/AX0tUrcDMaEyDJuwC/a3YR9qkh9T6P30lYgL79S7Lqgb8Rv1Jqw7YS/m9glGvEcYzB3mI8V0/rS7oO26FUJCkbYBW11zX72XChVKYWmIbfCfhhuFCkIK4gfmW0Aqsci7Ck9UhsHfWVxD/v/+McqxSP5+qAr2J1bGodg1/wq4HNw4UiBXAh8Suhv2Lz7YtmS2wL79jnXwOKJUmj8P3cdWS4UPrOc/rU7wLGIfl3Kr4zVXpKr6LlagEOBV4k3u/QCnzQPUopkqvwu15vCBhHn2yJ31zgVrTntyRnAvG6oFdiS1hrJPpaA4HvEm9xoRXAbu5RSlHsit+12kRKxwhdjF/QtweMQ/JtBLY8boyK5nFsV0Epb3vgSeL8NtPI1lRLSbc78btWvxMwjl7pB7yJX8CHhgtFcqwWuI04FcwVaCW63uiPrSPSSvjfaBKaGSDJOBK/63Q2KZvGegp+wT4dMA7Jt+8SvlJZiO2KKX1zMr5TqrpK3woRnOReDb4LYZ0QLpSeeS6icnbAOCS/DiT8evWPAVuHCC6ntsE+m4T8zZqA/UIEJ7n3Yfyu038GjKNbW+D3YJ1Fyro6JJOGYlt2hqxI/o4G+iVhIPAPwv5208jIqmuSag34fRpvIiXbdH8VvxvxonBhSI55Tsspl65E35KTVAf8hrC/4e+DRCZ55/nZ8UsB4+jSVHyCa8GmFopU42jCVhyXYN//JFk12AtByN/yfSECk1wbjV8P+YsB4yjrQPxuvlsCxiH5NASYSZjKohWtKhfCpwm3gNMMtPeIVO92/K7RfQLGsZ4ruyhUEilVoxwlk35BmIqiDZgYKCaBTxDud/1poJgkv07G7/qMtp9FA7Y7n0dQs7Fd2kQqtRfh3hS/ESgmWetbhPltm9EqgVKdfsDb+Fyf84g0UP6ECgrb2/T9gHFI/tQA9xOmgtCOcvFcRpjf+EE0rkOq8yP8rs9jA8bxH9dWWNieUiuwbcA4JH/OIEzFcDUp354z52rxew51TqcEiknyaSx+q1v+JWAcgA2uWpFAwculSQHjkPwZCLyOf4VwF/YZTOLqD9yL/+/9GlrXQapzNz7X5jJgUMA4XFc4Oi1gHJI/F+BfGbxNShbhEAA2wcYNef/unwkVkOSSZ8/kGQHjcFv6dx7aMEUqNwiYg28l0II2p0qj9+K/1PNbQGOgeCR/+mN1nMe1eWOoIIbit2/3paGCkFzyXJWyPWnEf3pdhP/vn4rV1ySzfobPdbmSQMtXn+kUQBuRFzWQTBsMzMf34X8nGvSXZnXY2AzPa2Au6gWQyu2P37V5eogA/u5U+Oloqo1U7rP4PvjnACODRSOV2gy/btb2dF6waCRvavBbnfQ678I3AsudCn+Jd+Elt+qAV/F96H84WDRSrbPwvRamoc2epHL/D5/rcjnOswFOcSp4G7CHZ8El107F94F/P+qdyhqvgcrt6aRwoUjO7I3fdXmiZ8H/7FToVzwLLbn3AH431BpgfLhQJCFbYwOjvK6Le4NFInlTg/UieVyXf/AqdB3wjlOhL/YqtOTejvitsNUG/DhcKJKwi/G7LtqAceFCkZy5BJ9rci5On6fe7VTgNmAXjwJLIVyK33U5C20Hm2WDgTdR41DSZ3f8rsv9PAr8Y6fCTvUorBRCf6zF63UjnRMuFHHySfyuDy1cJtWYis916bKZnldhL/IorBSC5z7brxJpm01JVD9sirHXdXJcuFAkZ76HzzX5bNIFHetU0DZgp6QLK4VxDX7X5YcDxiG+zsXvOvlzwDgkX8bjd12OSbKgn3Iq5AtJFlIKpRHbBcvjupyF3v7zpD9+YwGWYDtQilTiRXyuy4m9OXhvlzU9opf/XV/d5pSv5N9x+C16cTnQ5JS3hLca+LlT3kOAo53ylvy73Snfw5PKqB+wGJ9WymFJFVIK5y/4XJPLgGEB45AwhuO3iulVAeOQfDkSn2tyAQlNBzzQqYDL0AhaqUwtftv+/iZgHBLWH/C5ZuaiTaKkMgPwa5j2uLleby7axLoSOrkb65oT6au9gE2c8v5fp3wlPq/fdmNsXrdIX63Cb1XJHuvumA0Aff+XSnl9c50CPOqUt8T3EPCSU94aByCV8qoLqx67NwQbDOXRPbF1tYWTwrofn2vymyGDkCi+g8+1c3fIICRXtsXnmlyNzZaq2FFOBdPqf1KpBmAFPtfljgHjkDh2xOfaWY5dmyKVeAWf6/LQ7g7a0yeAgyoKpWfq/pdK7YHPvOvnsDm5km8v4vMC0gjs6pCvFINXndhtHd5TA+A9CRakIzUApFIHOOV7q1O+kj5ec6+9rk3JvygNgO40Yt8Qku6SWIZNfRCphNfyv+8NGIPEdTg+19D/hQxCcmUgPp82V1LhdPtDHArTBtxSSWFESjw2pVqGlv4tkv7YgzHp6+j5kEFI7tyBT5377q4O2N0ngAOrCqVrDzrlK/k3ENjOId/H0NK/RbIa+82Ttj1a3Ewq51U3VtQA2M+hIKAGgFRuPAktb9mJrsniecghz37AOId8pRg8rknoZkXArhoANcDeDgVZAzzhkK8Ug9fW0Y845Svp9bBTvjs75Sv59yjQ7JDvvl39i64aANsDGzoU5Cns25tIJbwWj3rGKV9Jr2ed8tUCZ1Kp5fg8izYBxpb7F101AHrcRKBCXl0cUgxbOeQ5H5jtkK+k20xgkUO+agBINbzqyLK9AKEbAP92yleKYSuHPDVyu7g8fns1AKQaQccBdNUA8Pj+D+oBkOps6ZDnNIc8JRumO+TpcY1KcURvADQA73IowCvYHu4ilRrpkOcMhzwlG15zyNPjGpXimI3PdbkLZdY6KdcAGIfPXFZ1/0s1GvHZA2CGQ56SDTMc8hyEVjqV6nhMSx5Amc3OyjUAJjgcHDTXWqqzkVO+bzvlK+nn9duPcMpXisHrM8Bunf+iXANgvf8oIV7zbqUYPKalAixwylfSb75TvmoASDW8est37/wX5RoAezgceBk+W3BKcQxxyneeU76Sfu845TvYKV8phhfwWS+nxwZALT57Wj8LtDrkK8XR4JTvMqd8Jf2WOuWr/QCkGi34vDDvhq3y+x+dGwBb4dN6fcohTykWr4fqaqd8Jf28fns1AKRakx3yHAZs0fEvOjcAvNZaf9opXykOrx6ANU75Svp5NQC8rlUpjuec8l1nrwo1ACQrPHYBBOtuk2Ly2HgFysy3Fukjjx4AiNAAWIMNahCphtebuh7WxaVeJUkrrwbAOnV85waAx1aWL6MbQqrndQ2pu7a4vL7Vr3LKV4pjLj7rVHTZAKihzEpBCdD0P0mC1/dardpWXF6/vV54JAke4wB2psNMgI4NgFH4zACY4pCnFI/XQ3W4U76Sfl6/vWaWSBI8PgNsAGzW/j86NgC2czgY6Pu/JGOhU75ata24vJaX1uqSkgSvmQBj2/+httxfJkwNAEmC17KtXpWApJ9X408NAEmC10DAbdv/obbcXyaoGdsGWKRaC4A2h3y36Pk/kZwa5ZBnK369VVIsU/FZQTdYA2AmGhAjyWgGFjvku5VDnpINWzvkuRCtLSHJWIXPTICynwA8GgCvOuQpxTXbIc+tHPKUbNjKIc+3HPKU4nrNIc//jPfr2ADYxuFAagBIkmY45LmDQ56SDds75OnxwJbi8rie1usBGIHPFMBpDnlKcc1wyHMcWg2wiBrwafypASBJmuGQ51BsOuB/GgCjHQ4C6gGQZM1wyLM/Pm+Ckm7j8FkFcoZDnlJcM5zyHQNrGwAeo2FBrWFJlleDcg+nfCW9dnfKVy89kiSvOnQ0rG0AjHE6yOtO+UoxeS2McYBTvpJeXr+519we3s+XAAAgAElEQVRtKaYgDQCPTwBLgSUO+UpxTcOuq6SpAVA8BzrkuRib+iySlFn4bFu9TgPA4xOAbgRJWhs+e0vshJYELpKR+AwAfB6fxaqkuJqBNxzyXWcMwGbd/IeVmuWQp8gzDnnWAkc65CvpdCQddkRL0LMOeYp4fAbYDNY2ADZ1OIB6AMTDw075HuWUr6TP0U75/tspXym2GQ55joS1DYBNHA6gFbHEw0NO+R4F1DvlLenRDzjCKW+va1OKzeMTwCZgDYB6fL5/eqxhLDINn8blxsDBDvlKuhwObOiQ75toDQDxMcchz42ButrSP9T28B9XYq5DniLg19V6mlO+kh6nOuX7oFO+Ih51aR0wopbStwAHHq0WEYA7nfI9CRjglLfENxA40Slvr2tSxKsu3aS9B8CDGgDi5XanfDcETnbKW+I7FVsHPWltwB0O+YqAX126cS0w3ClzfQIQLzPxWQ8A4ONO+Up85zrl+xw2BkDEg1ddOrwWGOaQ8Rq0CqD4us0p34OAnZ3ylnjehc/qfwC3OuUrArAIn9UAh3n1ACx0yFOko7865VsDfMEpb4nnS/gs/gN+16II2CemxQ75Dq/F55vYIoc8RTp6DL9pV2fiszqmxLEFcLpT3tOBp5zyFmnnUacO8/oE4NFaEemoDbjeKe/+wAVOeUt4XwYanPK+Bq3/L/48etXdGgDqAZAQrnXM+zzUC5AHo4CJjvl7XoMi7Tzq1OG1wGCHjNUAkBCexG8DloHAV53ylnC+jt/aDk8Ak53yFunIo04dXAs0OmSsGQASyv865v1JYBfH/MXXOOAcx/x/45i3SEdLHfIcWIu96SRtpUOeIuX8GVjhlHc98Ev8Ro+Lr59im/94WA5c7ZS3SGcedaoaAJJ5i/H9DnsgcLZj/uLjeOBIx/yvQT2dEo7HS06j1ycArzcykXIuxXck9o/xWzFTkjcE+Llj/m1Y74JIKB516kA1ACQPngcmOeY/EvieY/6SrB8Cox3zvxW/pahFyvHoVW+sxWeErD4BSGg/cc7/k8AhzseQ6h2B/VaeLnXOX6Qztx6AeoeM1zjkKdKdSfiuyFYL/AXY1PEYUp3NgT9hv5WXx4C7HfMXKcejTq33agB4bFwg0p024NvOx9gUG/ld53wc6bta4CpgE+fjfNM5f5FyWhzyrKvF52HmUViRntwMPOJ8jPdii8tIulwEHOp8jIeAO52PIVKOx0t1PcAq7O0pyXSWQ2FFeuNwkr+eO6cW4LBQAUmPDsYekN6/+8GhAhLp5EMkfz2vAGhyyPiDPudApFduw78ymAfsGCog6dJ2wBz8f++bQgUkUsYZJH9NrwFodcj4NJ9zINIr47CL27tSmIXvdDPp3hbYltDev/NqYIcwIYmUdTrJX9ctXqNltXSqxDQV+HWA44zCehs2DHAsWddQ4BZgywDH+hnwUoDjiATn8aZ0ZtAIRNa3ITAX/7fDNuABfJbUlvIGAg8S5rd9C2tsiMR0Jslf22tq8Rmx7zG1UKQvFgCfD3SsA7H9CPoHOl6R9QeuAw4IdLzzsf0mRGJym66/nORbFp5bcIr0xT8J86bYBtyD3hY9DQbuINzveUuYsER6dC7JX99L1QMgefdpfPbSLue92OeAzQMdr0hGAvdjS/2GsBT4r0DHEumJx7bWzbU4LjAgkgIzgS8GPN67sO/T2wU8Zt5tjTWsdg94zPOxWR4iaeBRp7aoASBFcCVwQ8DjbY29re4Z8Jh5tRfwMGEbVH8Ffh/weCI9cRkDUIvPzn1qAEjafBx4M+DxNsV6Aj4V8Jh58xnszX9kwGPOAiYGPJ5Ib3jUqSu9GgCDHPIUqcZ84GzC7lPRH/gFcD0aHNgXw4C/YfPvQ86saMaWMV8Y8JgiveFRp6oBIIVyD/C1CMc9BXgW2DfCsbNmAvAEcFKEY38Z+3QjkjaDHfJcAbbDVdLTC/7HobAiSajBvvGGmkrWMa3CBiTqE9n66rEKeDVxfptr/EMUqdivSf6afwBgkkPGf/I5ByKJGAJMIU5F04a94e7mHmV27AE8RbzfYzI+b1giSfkLyV/3d3h9AtDNJGm2FDgWeDvS8ScAj2PfuIu8j8AI4JfAo4Sd4tfRW8D7gGWRji/SGx516spafC58NQAk7WYA76f0HSyCemyU+8ulPxsilSOG/sDngFeA84j3SWQZVvnPjHR8kd7yqFOXgX2vT7pr4WGHwop4OB4b/R2r+7k9vY5NVfRY8SstGrDV9WYR/3w3YZW/SBY8SvL3wM8BfuCQ8Qs+50DExYew6YGxK6U2rGfi89g4hbwYAlyAvWnHPr9t2G+tHUslS14k+fvge2Ajb5POeK7PORBx80mglfiVU3taCFwK7OQZtLOdgJ8Ci4h/PttTK/AJz6BFHLxD8vfCF8C6HZPOuBmodTkNIn4uIH4FVS49iK1Ot5Ff6InZGKtgPaYXJ5FCbREtkpR6fHooPwZwqkPGbWTjYSXS2adJV09Ax9QE3I71VmzlFH8ltsYG892BlTH2eSqXWtGyzJJNI/G5J04CONwp8x09zoRIAB8jHQMDe0pTsaWGzwBGu5yJ8sZg39B/ic+3yaRTM/ARjxMhEsDO+NwXB9cD85wKvTH2cBDJmt9hU2SuIuxa9H21Yym1v9m+DTyHLWzzAvBaKb1B33f9rMcaFVsB2wDjgF2w7Y43rbLcIa3C1vf/W+yCiFRoY6d859UDc5wy1ycAybLrsEVi/kF2FuvZtJQO7/T3bdhmSO1pBfZNcUnp328A1AGN2OI87anGv8iu3gFOwMYjiGSVVwNgTnsPQCvJD9rzKrRIKA8A+wO3AGMjl6UaNViDvEiN8lew1R5fiV0QkSp51KXNwPza9n9wOMDmDnmKhPYStovfXbELIr12J7AfqvwlHzzq0neA1va3fo/PACEHJYl4egc4EvgO1p0u6dQG/Ag4Bp+XGpEYPOrSt2Ftt78aACLdawEuwqbNLo5bFCljEXAi8BXstxLJi1EOec6DtQ2AtxwOoAaA5NHfsK18NbAsPe4HdgVujF0QEQcedelsWNsAmOVwADUAJK9mAO/B3jab4hal0JqxzzKHoB39JJ9q8OkBmAm+DYBBZGf6lEhftWDfm/cHnolcliJ6GtgH+yyjLn/JqxHAQId834C1DQCv1rN6ASTvngD2wva3Xx65LEWwEnvr3xd4KnJZRLyNccp3nTp/V3yWGny/U+FF0mg74GbiL32b13Qj2V6PQaSvTsDnXtoZ/HsAtnXKVySNXgHeBxwGPB+5LHnyEraoz/HAtMhlEQlpO6d81/vsv5TkWxm/diq8SNr1w3YWnE38N+espjexXQbr+3juRfLiSpK/rxaWO9AzDgf6VzLnQCSz+gMTsam2sSvUrKR5wIX4DH4SyZJ7Sf7+erzcgf7qcCBNzRExg4ELsHsidgWb1jQD+Dw2g0hErBcs6fvsmnIHusThQC2oFS/SUT/gTGwEe+wKNy3pSeCDqKtfpKPB2EZ9Sd9vF5c72McdDtQGjE/iTIjk0ATgCnzG36Q9rcS2XD6s6rMokk+743PvfbTcwd7rdLCTEjgRInm2ATZO4F6s1yx25eyVmoG7gXOBIUmcOJEcOw2f+/Dd5Q42yulg30riTIgUxObAZ4EHsQozdqWdRKX/APAZYLMEz5NI3n0Xn3uy7H1YAyxxONj1SZwJkQIage0+eAW2dGfsyry3aS7WvT8R2DTxsyJSDP8g+XtzMVbXl/WowwFfqvo0iEgNsCNwDvB77L7yGCDU19QKvAj8DvhYqYwiUr1pJH+//rvjATqPun0B2DvhIMYCjcCKhPMVKZI2rKJ9Efht6e+GAO8qpV2B7YGtsT04+iV8/CZs9bDXsMbH5FJ6HhvEKCLJGYLdy0mb0vF/lGsAJK0OW3e47OIDIlKxpViL/t+d/r4OG9MzBvuMMALYCBiODTiswxoIg0v//TKsgm8u5bkQeAeYX0ozsU8Q2nVPJIzxdNNVX4V16vgQDQCAXVADQCSUFuD1UhKR7NnVKd91egBqO/1LrwbAu5zyFRERyRuvOrPbBsDr+HzP28MhTxERkTza3SHPhdjSwt26n+RHHi5Hy3yKiIj0pB82aD7peviuzgfq3AMA8HSioZhGbCCgiIiIdG1XfPbQWa9uD9UAgOSnF4qIiOSNV12pBoCIiEiKedWVz/TmP6rHdupK+vvDs8nFISIikksvkHz9u4I+jMN73KEAzaxdeERERETWtQE+O4I+Wu5g5T4B0NV/XKU6YE+HfEVERPJgb7qul6sRvQEAcJBTviIiIln3Hqd8Hy73l101AB5xKoRXcCIiIlnn9ZLcpzq9BpiHz0CE/lWHIiIiki/98RmAP6erA3bVA9AGPFZtNGUMROMAREREOtsXGOCQb+fdQv+ju8EG+gwgIiIShlf3f5dj+rprADzoUBDQQEAREZHOvOrGByr5Pw0EVpH894ilQEPFoYiIiORLA7CMwOPuuusBWAk8UUVAXRkM7OeQr4iISBa9GxjkkO8jwOqu/mVPCw7cl2xZ/uNIp3xFRESyxqtOvL+7f9lTA6Db/3MV1AAQERExRznlW9VL/GCgieS/S7QCI6spmIiISA5sgdWJSdezq4HG7g7cUw/AMnzWA6gBjnDIV0REJEuOxOrEpD2MDQLsUm82HZiUTFnWo88AIiJSdF51YSJ19/4k3zXRBszFZ9cjERGRLKgHFuBTx+6dVAEXORXwwCQKKCIikkGH4FO3LgDqejp4b97Am4F7ex9Pn5zglK+IiEjaedWB/wJaevqPetsF7zUO4GSnfEVERNLuOKd8E62zt8Snm6INeFeSBRUREcmACfjVq1v2pgC97QF4HZjSy/+2r/QZQEREiuZ4p3yfwersHvVlFP7NlZWlR2oAiIhI0ZzolO9NHpkeiE9XRSu97K4QERHJgW3x6/7ft7eF6EsPwMPAO33473urBjjdIV8REZE0+oBTvnPxWb0XgKvwabE87VVgERGRlHken7r0d56FPtmp0G3AOM+Ci4iIpMAu+NWjrmPqGrENgjwK/h3PgouIiKTAD/GpQ5cCA70L/zenwr+Kz45IIiIiaVADTMenDr0mRABnOBW+DdgzRAAiIiIReG2u1wacGiKADYBVTgFcGiIAERGRCH6OT925AhgcKoibnIKYB/QPFYSIiEggDVgd51F3/r2SAvVlHYCOrqvw/9eTjYBjnfIWERGJ5SSsjvPgVSeXNQi/2QAuyxiKiIhEdAc+deYyrE4O6poECl4uNQOjA8YhIiLiaRRWt3nUmX+qtFD1lf4fgf/DZwnfOuAsbK6kSDkDgR2A7YGRWOt3GDYIZhARWsNSCMtLaRmwqPTPc4CXgJeBlfGKJin3Uaxu83B1pf/HaubdNwBvARtWkUdXXsEe8G0OeUu2DAUOAt4LjMeuizFozQhJlzZsC9aXgeeA+0ppScxCSSrUANOArR3yngdsATQ55N2jK/Dp0mjDHvhSPHXAocAlwKP4dZspKXmnZuARrDfzEPzeACXdDsPvGvtlwDjWc0AXhUoiXR8wDolvJ+Ai4DXiP7iVlDzSm8DlwO5IkfwDv2tq74BxrKcGeLFMoZJITdjACcmvRuBT2G6QsR/OSkoh05PAeQRYu12i2hK/XswpAePo0lfwu0m+GzAOCWcwcD72RhT7QaykFDPNxXq+hiF5dAl+184FAePo0ub4tXDexgYbSj4Mw3Z9XED8B6+SUprSfODb2FLrkg8DsAaex/WyBpsBlQq34HdjnBEwDvFzHDCL+A9aJaU0p7eAD6FZLnnwEfyuk3+EC6NnJ+MX6EMB45Dk7QTcQ/wHq5JSltJdwI5Ilj2G3/VxfMA4etQPa7l6BRt1pKNUpB64GOuqiv0wVVLKYlqNfTKrZsE2icNzhtwbpPCauBi/gDUlMFtGAQ8Q/wGqpJSHdB+22Itkx434XQ8XhQuj90bjNxiwGdg2XChShcOwwZuxH5pKSnlK84BjkCzYAWjB5zpIdHp8pdsBlzMLGwzooQ74vFPekowa4AfAnaRodKpITmwE3Ax8Dw0QTLsLSLZu7ehm7BNAKh2NXwt4BbBxuFCkD+qB3xL/LUlJqQjpKmzclaTPSGxTKK/f/ohwofRdLfAqfsFfFCwS6a1GfKeBKikprZ9uwu49SZfv4/ebv4Jfz0JiPoPfCZiHtnpNkw2BfxP/YaikVMT0ED67sUplhuC7yNl54UKpXCPwDn4nIRXLHwpDgCeI/xBUUipyehy7FyW+r+L3O88nQy+/nlMC30ZdX7E1ALcT/+GnpKRkiwb1R2IahN+yv23YehCZsQm+AyE0IyCeWuBa4j/0lJSU1qarycD34Ry7EL/fdhWwabhQkuE5KvwttI1mLD8n/sNOSUlp/XQZEoP32/+V4UJJzo74LYbQhm0nK2F9kPgPOSUlpa7T2UhoX8Lv92wFxnkV3HtBiVvwW71qNjAW6x4Rf+OwAUdpHIgyD5gJLAOWl5JI0gZj44+GYCufpnFdkmXAnsBLsQtSEI3AdPwWP/snKdv4py8Owbe1+4VwoRRaI/Ac8d9u2rDK/nrgU8C+wHDHuEW6syF2DX4a+Cu+s5/6kp5Fn0hD8fz23wYcFC4UH0/iWxkMDRdKYf2GuA+0+cD/APuhgU6SXrXA/sCv8J0P3puUye/GGTMc39/50XCh+DkD3wv9e+FCKaTDifcQewH4EJriJNnTH/gw8CLx7p9D3aMsth/i+/udGi4UP/XA6/idpGVkcIpERvTHviWGfnC9DJyC3vYl+2qB0/BdIr2r9CK2Zockb3NsrJHXbzcN2wQvFz6J74X+y3ChFMo3CfvAWoHt9zAgQGwiITVg34s910cpl74WIrgCugLf321iuFD8NQCv4Xey1gDbBoumGLbBKuRQD6qnge2DRCYSz47YIL1Q99VyYKsQgRXIdlid4/WbzSCHPTcfw/dCvzZcKIVwPeEeUr9Cb/1SHAPxf4PsmK4JE1ZheD8bPxEulHDq8B8Qk/kpEykxDt9FnNpTK5rKKcX1acLcZy3AzoFiyrsDsOeW1281kxy+/bc7C98L/Sk0cCwJf8L/obQa+ECogERS6iTCjAv4Q6B48qwW/x1Q/ytYNBHUAVPwPYEfDRZNPm0DNOH7GzUDJ4QKSCTlTsTuCc97rgnYOlRAOXUuvr/R6xRgyvOp+J7Et9D+2NXw/jbZit1IIrLWRHzvuzbg18GiyZ+h2Fb0nr/Px4JFE1EN8Ay+J/KHwaLJlw3wndvahhZuEunKD/C995ajl6NK/Te+v81UcjTvvyfH43syV2EbBUnfeM/UuIcCXeQifVQP3IfvPfiRUMHkyPbYmCXP3+WUYNGkQA3wGL4n9NZg0eTHPfj9HnOAzcKFIpJJW2B7nHjdh3eFCyU37sS3rnoc/515U+cofE9q4VpVVdoK3+ktZwWLRCTbPoLffdgCjAkWSfZ9AP966ohg0aTMJHxP7BvYd23p2Tfw+x3uoYAtXJEK1QAP4Hc/fjVcKJk2FJiNbx11W7BoUmg8/lPOLgsWTbY9jM/5b8F+ZxHpvd3w65F7MGAcWfYLfOumNdiia4XmfZKbgd2DRZNNQ/Bb2/r6gHGI5MkN+FU8gwPGkUUT8F+b4afBokmxEcB8fE/0o2iFwO4ci895bwX2CBiHSJ7sid8z8aiAcWRNHf4r/s0DhocKKO0+i+/JbgM+Hyya7Pl/+Jzzu0MGIZJDXtMCfxwyiIz5Ev710XnBosmAfvgvEbwcbRnclafwOecfCRiDSB6dg8+9+UTIIDJkB/z3ZpiMrfkgHRyKf6vrIfQpoLMGfAZiLkOrjolUy2t1zjXYi5esVYvv7Iv2VNhpfz25Cf+T/6lg0WTDOHzO899CBiGSYzfic4/uEDKIDPgc/vXPDcGiyaCx2DK+nj/AMrRMcEcnoIaWSJqdj889elzIIFJua2ApvnXPamC7UAH1Rtq6w6cBv3Q+xiBsxzstTGO83gLuccpXpGi8BtPu6JRv1tQCv8d/auRlwCvOx8i8ENsutmGtaoHfkfy5XYgaWCJJqQEWk/x9+puQQaTYF/Gvb2ajVWl7LcT6yyuBnUMFlGJ3kfy5fSRoBCL557F52qSgEaTTrvh/dm4jpfvSpO0TQLtrsIEvngYA15b+LDKPVumLDnmKFNlLDnkW/Y20P3BV6U9PNwN/dT5GRdLaAAD4DLDE+Rg7A991PkbaeXz3mu6Qp0iRTXPIs+jTdC8BdnE+xmLgE87HqFiaGwCzgK8FOM4FwCEBjpNWHg+BxQ55ihSZx8tQkRsAhxFmHNiF2Pd/qUAttnOV9/eZmRR3XeZFJH8+zwkagUj+nUvy9+mioBGkxwhsq3jveuU+Uj4YOs09AGCbyXwcmz/paTTwB1L+Yznx+ASwzCFPkSLzuKeKuCNgDfbdfwvn46wCJmINgdRKewMAYCrwgwDHeT/F3DCoziHPVoc8RYqsxSFPj3s/7b4MHBPgON/DZ+BmITUAz+HfZbMG2D9QTGnhcR5PDRqBSP6dis+9WiT7Ys9473pkMhnZZyELPQBgP9o5+LSCO+qHTUEc4XwcEREJZ0Ps2e5dMbdio/6bnI+TiKw0AMAWwvBeJhhsPMAfKeZ4ABGRvKnBlvrdMsCxLgMeDnCcQhqEfVfx7sJpA74UKKbY9AlAJP30CaByXydMnTEVaAwUU2Htgc0K8P4xW4CjAsUUkxoAIumnBkBlDgea8a8v1gB7BYqp8L5KmBbdfPK/dbAaACLppwZA320FvEOYuuKLYUISsLELHpvYlEvPYp8e8koNAJH0UwOgbwYTZuZYG3Av2RpP9x+ZLDQ20vLDwIIAx9oF+N8AxxERkerVAL8Fxgc41kLgQ2jtkyhOI0wLrw34QqCYQlMPgEj6qQeg9y4kXL1wUqCYpAu/J8wP3QwcFyimkNQAEEk/NQB65xjCDPprA64MFJN0I+TUwCX4bx8ZmhoAIumnBkDPdgOWEqYueIUc7KaY1TEAHS0HziTMyktDgFvx30hCRER6bzPgn4TZ4KgZOAtrbGRaHhoAAE8AFwc61hbAjWjBBxGRNBgI/ANbxTWEbwKPBjqW9FIdMIkw3T9twHXkY7lgfQIQST99AiivFriBcM/928jPi3PubATMINzFcEmQqHypASCSfmoAlPcTwj3vp2ObCkmK7QasINxF8fkwYblRA0Ak/dQAWN+nCPecXwlMCBOWVOtswl0YraXjZZUaACLppwbAuj6A7dcS6jn/0TBhSVKuINzFsQY4IkxYiVMDQCT91ABY6xBgFeGe7z8PE5YkqR/wIOEukiXYToVZowaASPqpAWAmYM/aUM/1h4GGIJFFkOfRjE3AB4G5gY43BLiF/O8eKCISw7bYMzbUAjxvAydjPby5lOcGAMAs7FtRc6DjbQrcg21DKSIiyRgN3AmMDHS8ZqzumB3oeFHkvQEAViF/NeDxRmPrEWwW8JgiInk1Eqv8tw54zC8C9wU8njiqAa4l3HejNmwv6o1CBFcljQEQSb+ijgHYGJhC2Gf3X4JEJkENBP5N2AvpGdK/cIQaACLpV8QGwFBsmfeQz+xHKdAy70X4BNBuJXACtppTKLsCNxNmgwoRkbzYAOv2D7n4zqvAsdhCcoVQpAYA2IyAI4F3Ah5zP+AO7IIWEZHuDQVuB/YOeMz5wPsIWzdEV7QGAFgr7yRgdcBj7g/cTfo/B4iIxDQMe2HaL+Ax12CfWF4KeEyJ7HRsGd+Q35eeBEaECK4PNAZAJP2KMAZgGPAYYZ/JrcBZIYKT9PkmYS+2NuBp0jU7QA0AkfTLewNgOPA44Z/HXwkRnKTX7wh/0T2DTW9JAzUARNIvzw2ATYDJhH8OXxkiOEm3ftho09AX31RgTID4eqIGgEj65bUBMAZ4kfDP39uB+gDxSQZsADxL+IvwTWB8gPi6owaASPrlsQGwIzATn7i6S89jMw0Kr4izAMpZAhxD2DUCADbHlpvcN/BxRURi2hO4H1s6PaRp2NbtiwMfVzJgDDCD8C3SpcDh/uGVpR4AkfTLUw/AwVgFHPo5O4uw+wlIBu0IzCH8xbkSODFAfJ2pASCSfnlpAJwCrKqivJWmt4HtA8QnObALtjJU6Iu0GfhsgPg6UgNAJP3y0AA4H2hJsOy9TQuB3QPEJzmyDzY2IPTF2gZcTrjxGWoAiKRflhsAdcDPnMrfU1oM7OUfouTRAcAy4ly4NxBmVyo1AETSL6sNgEHAP5zK3lNaAbzHP0TJs8OJ882qDduacqRzfGoAiKRfFhsAGwEPOZW7p7Qam9klUrWTgCbiXMjTgJ0cY1MDQCT9stYAGI9Nq47xzGzCtn4XScxZxBnA0oaNRTjOKS41AETSL0sNgOOJN36qBTjTKS4puA9gW0fGuLBbgUuAmoRjUgNAJP2y0ACoAS4k3otSM/DhhGMSWcdx2Jz9GBd4G3AtyQ4OVANAJP3S3gAYAPzJqYy9SauxT7Ui7g7GVu+LdbE/A2yVUCxqAIikX5obAKOIs5Vve1oOHJlQLCK98m7iLGfZnuaRzEWvBoBI+qW1AXAwtsperOfgUuCQBOIQ6bMJwDvEu/jbxwVUs2iQGgAi6Ze2BkD79/5mp3L1Ji1AG6lJZDsDs4l3E7QBdwGbVFh+NQBE0i9NDYARwG1O5eltehvYtcLyiyRqB2ynqZg3xExgvwrKrgaASPqlpQEwgXjz+9vTbOzFSyQ1tib+jbEa23CjL1MF1QAQSb/YDYAa4HPYMybmM+5VkhsALZKoUcBzxL1B2oBb6P0nATUARNIvZgNgJHCr0/H7kp4FNu9lmUWiGIxVwLFvljn0bi1sNQBE0i9WA+Aw4o9xagPuBIb2+myJRFQP/Ir4N00rtrVw/27KqgaASPqFbgD0Ay4i3qp+HdNvS+URyZSvY5Vw7BvoSWBcF2VUA0Ak/UI2AHYCnnY6Xl9SK/CVis6WSEqcQtylg9vTSmzebl2n8tQza6IAAAjvSURBVKkBIJJ+IRoAtcBEbGW92M+rVcAZ1ZwwkbTYD5hL/JuqDXgYm7bYTg0AkfTzbgBsA9zndIy+pvnAQdWeMJE0GQu8RPybqw1YgfUG1DrlrwaASLK8GgA12Ft/zL1NOqZprPuCIpIbG2Nv4LFvsvZ0t1O+agCIJMurAeD1DKgkPQRslNQJE0mjgcDVxL/ZPJMaACLJ8moApCX9BdtSWAKqZhMZqcxK4IPAJ4CmyGUREYmpGRvpfyY28E8CUgMgniuBQ7FNLUREiqZ9S/MfxS5IUakBENcDwJ7YuAARkaJ4Anv23R27IEWmBkB8b2JTXtQKFpEiuBI4ANvBVCJSAyAd2r+DnY1N0RMRyZtVwDnY+Kc1kcsiqAGQNn/GWsavxS6IiEiCZmI9nb+LXRBZSw2A9HkG2Au4I3ZBREQScDuwO/B47ILIutQASKf5wLHYZkKaKigiWdQEfBV7li2IXBaRTNqT9CwhrIWAROLI2kJA07E9UCTF1AOQfk8AuwE/i10QEZFe+BOwC5renHpqAGTDSuB84GTs84CISNoswlY5/RCwLHJZRHJpU+A24nfxdZdmYg2WgU7nQKQoGrDd+mYS/77uLt0FbOF0DkSkgxqsgl1N/Bu/uzQH23a40ec0iORWf6zif4P493F3aQ1wEepNFgluPDCZ+A+BntJc1BAQ6Y1BWOP+TeLftz2lqcAePqdBRHqjEfgptppg7AdCbxoC30Z7fot0tjH2Jj2P+PdpT6kZuBQ16EVSY3fgSeI/HHqTVgFXATu4nAmR7NgauBxYTvz7sjdpMrCPy5kQkar0A76BVbCxHxS9fZO4Flv5UKRI9gauIxs9d23YTKSvYc8YEUmxbbFtNmM/NPqSnsAGPWnmgORVA7agzyTi3299SQ8C4xzOh4g4qcHm484n/gOkL+lt4BJgTPKnRCSKTbFBsGkf0d85LcIGJGqEv0hGjQJuJP7DpK9pDfZ54FCsMSOSJbXAYVg3fxPx76e+phuAzRM/KyISxWnY23XsB0slaRq2MZIeSJJ2W2DjcKYT/76pJM0GTkn8rIhIdEOBy8jmG0kbNmDqn8D7gfqEz41IpfoBxwM3kZ1BfZ3TKuBHwJCEz42IpMwO2B7dsR861aT5wBXAgegTgcSxMzZeJas9a+3pJmBswudGRFLuOGAG8R9A1abXsQex1hUQb1thA/peJv51X22aChyd6NkRkUxpBL6F7d4V+4GURHoMe0Bvm+RJkkLbDvgKNlU19vWdRHoHOA99RhORks2wLvWsfsMsl6Zgy6tOSO40SUHsjDUkHyT+dZxUasLucS3FLSJl7Ur2FirpTZqKfSY4CL35yPrqgfdgA+FeJP71mnS6DS3mIyK9dCTZ2Vugr2kBcA22UNLGSZ0wyZxNgA9j600sJP516ZEeB45I6oSJSHHUYEuX5vGNqD21AI8AFwOHAAMSOXOSRgOxhaW+DzyK/faxrz+v9AJwMpohIyJVqgfOAWYS/8HmnVYC/8I2PtkXfS7IsnrsN/w6cBf228a+vrzT68BHgboEzp+IyH80YN3m04j/oAuVlmEDwS7Bpk2OqPosipch2LoQF2Jz2/ParV8uzcTW7VcPloi46g98EnvbiP3gC51agOeAXwMfwwZNaovU8PoBu2G/wRXYb5LnLv2u0gzgE1jjXKRP9H1IqtGAPYAvxBZIKapVwGTgqVJ6EpuCuDpmoXJkADYtbw9sSucewC5YQ7SopmMzFv6AbZwl0mdqAEgSaoFjsQWF9oxcljR5C2sIvNDhz6eB5TELlWL9gO2BnbAKv/3PHdA37XZPAZcD/4et2SFSMTUAJEk1wDFYj8C7I5clrVqwfeGndUjTO/zz4nhFC2Iotu5857QNMBrtPV9OK3Az8BPg/shlkRxRA0C87A98ATgBvb31xTJgFrYt65ul9BY2yGt+p9QSqYyd1WGDI9vTRlhlvhkwCtsid7PS3w2OVMYsWgX8CbgUm4orkig1AMTbVsBnsGmEQ+MWJXcWYuu6z8caDkuwqW7LsZ6ElcAKbCzCig7/v5bSf9vRBqzbUGvEvrEPwr7BDy3988DSfzuYtZX98ARjEvtNfwX8ApgbuSySY2oASChDsPnJn0Eb9YiU8yrwU2xg34ru/1OR6qkBIKHVYivuTQRORAvtSLG1AncDVwJ/Jz2fdaQA1ACQmDbDFhY6DxgTuSwiIb0FXIV19b8euSxSUGoASBrUA+/D1hQ4GvUKSD41Ybvy/Q64BU3jk8jUAJC02RQ4HRsvsGvksogk4UXsu/4fgDlRSyLSgRoAkmb7Yp8ITsVGm4tkxTzgeqyb/9HIZREpSw0AyYI64GCsMXACNqNAJG1WYgv2/Am4HevyF0ktNQAkawYBxwOnAUei3c8krpXAHcB1wI1o+p5kiBoAkmUDgcOwTwTqGZBQVgJ3YV38/2D9RZVEMkENAMmLgcBRWO/AMcDGcYsjOTMXuBV7y78DawSIZJoaAJJHtcDuwHHY9MI90LUuffcCcBPwL+BeNG1PckYPRSmCMVjvwBHYKoRau17KWYB17U/CBvHNilscEV9qAEjR1AF7AoeX0n7YPvRSPGuAh7EKfxLwJFqKVwpEDQApukbsE8EB2IDCA7DxBJI/TcBkrEv/IeA+NIBPCkwNAJF19Qf2Bt6NLUS0D7BJ1BJJpeZgi/A8AjwAPIa99YsIagCI9MZY1jYG9gF2QesPpM1K7O3+UdZW+tOjlkgk5dQAEOm7emAHYCdgZ2AC1jDQ1MMwlgDPYd/sp2Cj9R8HVscslEjWqAEgkpzhWINgpw5/7ooaBpVaAryCVfBTOvz5GtAWsVwiuaAGgIi/zYFtS2lsp38eGrFcabAImAa82uHP9vRWxHKJ5J4aACJxbQCMBrYERpX+eQy2LfJmWO/Bxtj0xSxpwXbEmwu8XUqvA29g8+tnltLSWAUUKTo1AETSrwZrBGxS+nN4KQ0rpfZ/Hog1KPpj0xsHAQ1YL0Nth/wGsP5Ux5XAqg7/uxVYjI2aX45tcrMa65ZfCSzE3t4XdfjnhViFP6+U1E0vkmL/H62JsLV304PoAAAAAElFTkSuQmCC" />
                                    </defs>
                                </svg>
                                <span style="padding-left:0.5vw"><?php echo $coment['autor']; ?></span>
                            </div>
                            <span class="forum-card-date"><?php echo date("d/m/Y", strtotime($coment['data_postagem'])); ?></span>
                        </div>
                        <div class="forum-card-title" id="titulo"></div>
                        <div class="forum-card-text" id="conteudo">
                            <?php echo $coment['conteudo']; ?>
                            <!--<?php $_SESSION['id_mensagemDenuncia'] = $coment['id_mensagem']; ?>-->
                        </div>
                        <div class="forum-card-footer">
                            <div class="forum-card-actions">
                                <span class="forum-like"  data-id="<?php echo $dado['id_mensagem']; ?>" onclick="curtirPost(<?php echo $dado['id_mensagem']; ?>, this)" style="cursor: pointer;">
									<svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg" >
                                        <path d="M15 10C15 10 15 10 14.05 8.75C12.95 7.3 11.325 6.25 9.375 6.25C6.2625 6.25 3.75 8.7625 3.75 11.875C3.75 13.0375 4.1 14.1125 4.7 15C5.7125 16.5125 15 26.25 15 26.25M15 10C15 10 15 10 15.95 8.75C17.05 7.3 18.675 6.25 20.625 6.25C23.7375 6.25 26.25 8.7625 26.25 11.875C26.25 13.0375 25.9 14.1125 25.3 15C24.2875 16.5125 15 26.25 15 26.25" stroke="#573280" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg> <span class="curtidas-count"><?php echo $coment['qtd_curtidas']; ?></span></span>
                                <span class="forum-comment">
    <a href="comment.php?id=<?php echo $coment['id_mensagem']; ?>" style="text-decoration: none; color: inherit; display: flex;text-align: center;justify-content: center;align-items: center;">
        <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M2.8125 5.625V24.375H11.7994L15 27.5756L18.2006 24.375H27.1875V5.625H2.8125ZM4.6875 7.5H25.3125V22.5H17.4244L15 24.9244L12.5756 22.5H4.6875V7.5ZM8.4375 10.3125V12.1875H21.5625V10.3125H8.4375ZM8.4375 14.0625V15.9375H21.5625V14.0625H8.4375ZM8.4375 17.8125V19.6875H17.8125V17.8125H8.4375Z" fill="#573280" />
        </svg>
        <?php echo $coment['qtd_comentarios']; ?>
    </a>
</span>
                            </div>
                            <span onclick="pop_denuncia(<?php echo $coment['id_mensagem']; ?>)" class="forum-card-more"><svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.5 22.875C13.5 22.3777 13.6975 21.9008 14.0492 21.5492C14.4008 21.1975 14.8777 21 15.375 21C15.8723 21 16.3492 21.1975 16.7008 21.5492C17.0525 21.9008 17.25 22.3777 17.25 22.875C17.25 23.3723 17.0525 23.8492 16.7008 24.2008C16.3492 24.5525 15.8723 24.75 15.375 24.75C14.8777 24.75 14.4008 24.5525 14.0492 24.2008C13.6975 23.8492 13.5 23.3723 13.5 22.875ZM13.5 15.375C13.5 14.8777 13.6975 14.4008 14.0492 14.0492C14.4008 13.6975 14.8777 13.5 15.375 13.5C15.8723 13.5 16.3492 13.6975 16.7008 14.0492C17.0525 14.4008 17.25 14.8777 17.25 15.375C17.25 15.8723 17.0525 16.3492 16.7008 16.7008C16.3492 17.0525 15.8723 17.25 15.375 17.25C14.8777 17.25 14.4008 17.0525 14.0492 16.7008C13.6975 16.3492 13.5 15.8723 13.5 15.375ZM13.5 7.875C13.5 7.37772 13.6975 6.90081 14.0492 6.54917C14.4008 6.19754 14.8777 6 15.375 6C15.8723 6 16.3492 6.19754 16.7008 6.54917C17.0525 6.90081 17.25 7.37772 17.25 7.875C17.25 8.37228 17.0525 8.84919 16.7008 9.20083C16.3492 9.55246 15.8723 9.75 15.375 9.75C14.8777 9.75 14.4008 9.55246 14.0492 9.20083C13.6975 8.84919 13.5 8.37228 13.5 7.875Z" fill="#A7A7A7" />
                                </svg></span>
                        </div>
						               <div style="background: linear-gradient(to top, #FEFEFF 10%, #6D6193 670%); height:45px; border:1px solid #6D6193; border-radius:100px; display:flex; align-items:center; padding:0 10px; margin-top: 1.5vw;">
    <input id="titulo_digitado2" name="titulo" type="text" placeholder="Digite seu comentário" style="flex:1; border:none; outline:none; background:transparent; font-size:16px;">
    <svg onclick="enviarComentario2();" xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 41 41" fill="none" style="cursor:pointer;">
        <path d="M35.4869 6.67969C35.8191 6.67969 36.1377 6.81164 36.3726 7.04653C36.6074 7.28142 36.7394 7.59999 36.7394 7.93217V18.787C36.7394 20.4479 36.0796 22.0408 34.9052 23.2152C33.7308 24.3896 32.1379 25.0494 30.477 25.0494H7.66014L13.8724 31.2617C14.0843 31.474 14.213 31.7552 14.235 32.0543C14.2571 32.3534 14.1711 32.6505 13.9927 32.8916L13.8724 33.0319C13.6603 33.2444 13.3788 33.3737 13.0793 33.396C12.7798 33.4184 12.4823 33.3324 12.2409 33.1538L12.1006 33.0319L3.75074 24.682C3.53862 24.4699 3.40965 24.1888 3.38728 23.8897C3.36491 23.5906 3.45062 23.2934 3.62883 23.0521L3.75074 22.9118L12.1006 14.562C12.3244 14.3399 12.6237 14.2104 12.9387 14.1993C13.2537 14.1883 13.5614 14.2964 13.8002 14.5021C14.0391 14.7079 14.1915 14.9961 14.2272 15.3093C14.2629 15.6225 14.1791 15.9377 13.9927 16.1919L13.8724 16.3321L7.66014 22.5444H30.4803C31.4321 22.5441 32.3484 22.1826 33.0439 21.5329C33.7395 20.8832 34.1626 19.9937 34.2278 19.0442L34.2378 18.787V7.93217C34.2378 7.59999 34.3697 7.28142 34.6046 7.04653C34.8395 6.81164 35.1581 6.67969 35.4903 6.67969" fill="#573280"/>
    </svg>
	
</div>
                    </div>
                <?php
                }
                ?>

            </div>
			 <div id="pop_denuncia">
                <p id="textDenuncia">Denunciar:</p>

                <form class="form-coluna" action="enviarDenuncia.php" method="post">
                    <div id="opcoesDenuncia">
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <input type="radio" id="opcao1" name="grupo_opcoes" value="spam" checked>
                            <label for="opcao1">Spam</label>
                        </div>

                        <div style="display: flex; align-items: center; gap: 8px;">
                            <input type="radio" id="opcao2" name="grupo_opcoes" value="conteúdo inadequado">
                            <label for="opcao2">Conteúdo inadequado</label>
                        </div>

                        <div style="display: flex; align-items: center; gap: 8px;">
                            <input type="radio" id="opcao3" name="grupo_opcoes" value="fora do tópico">
                            <label for="opcao3">Fora do tópico</label>
                        </div>

                        <div style="display: flex; align-items: center; gap: 8px;">
                            <input type="radio" id="opcao4" name="grupo_opcoes" value="linguagem ofensiva">
                            <label for="opcao4">Luinguagem ofensiva</label>
                        </div>

                        <div style="display: flex; align-items: center; gap: 8px;">
                            <input type="radio" id="opcao5" name="grupo_opcoes" value="Duplicado">
                            <label for="opcao5">Duplicado</label>
                        </div>
                    </div>

                    <input type="hidden" name="id_mensagem" id="id_mensagem_denuncia">


                    <div id="botaoDenuncia">

                        <div class="button" style="border:solid 1px #653a96; background: linear-gradient(to top,rgba(254, 254, 255,0.5)17%,rgba(109, 97, 147,0.5)200%)" onclick="pop_denuncia();">
                            <div class="icon" style="height:67%">
                                <svg width="30" height="30" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M8.33203 31.6668L19.9987 20.0002M19.9987 20.0002L31.6654 8.3335M19.9987 20.0002L8.33203 8.3335M19.9987 20.0002L31.6654 31.6668"
                                        stroke="#573280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                            <div class="separator" style="background-color:#653a96;  height:64%"></div>
                            <div class="textBox" style="height:66%">
                                <p class="textbtnSave2" class="textContent" style="color: #653a96;">Cancelar</p>
                            </div>
                        </div>

                        <button class="button" type="submit" name="submit" id="button-save2" style="border:solid 1px #653a96; background: linear-gradient(to top,rgba(254, 254, 255,0.5)17%,rgba(109, 97, 147,0.5)200%);"> <!---->
                            <div class="icon" style="height:60%">
                                <svg width="30" height="30" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M24.5987 20H11.3853C11.3853 19.5417 11.2903 19.0834 11.102 18.6534L7.14035 9.69003C5.87368 6.82337 8.90368 3.95337 11.697 5.3717L34.6653 17.0284C37.0987 18.2617 37.0987 21.7384 34.6653 22.9717L11.6987 34.6284C8.90368 36.0467 5.87368 33.175 7.14035 30.31L11.0987 21.3467C11.2858 20.9224 11.3823 20.4637 11.382 20"
                                        stroke="#573280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>

                            </div>
                            <div class="separator" style="background-color:#653a96; height:59%"></div>
                            <div class="textBox" style="height:66%">
                                <p class="textbtnSave2" class="textContent" style="color: #653a96; margin-left:20px; padding-right:15px">Enviar</p>
                            </div>
            </button>
                    </div>
                </form>
            </div>
			<div id="sombra"
        style="width: 100%; height: 100%;display: none; position: fixed; background-color: rgba(22, 22, 22, 0.3); z-index: 500; ">

    </div>
			
			
<script>
        function enviarComentario() {
    const titulo = document.getElementById('titulo_digitado').value.trim();
    if(titulo === "") {
        alert("Digite algo antes de enviar!");
        return;
    }
    // Passa o filtro e o id da mensagem pai
    const id = <?php echo $id ?? 0; ?>;
    window.location.href = 'comment.php?id=' + id + '&filtro=' + encodeURIComponent(titulo);
}
 function enviarComentario2() {
    const titulo = document.getElementById('titulo_digitado2').value.trim();
    if(titulo === "") {
        alert("Digite algo antes de enviar!");
        return;
    }
    // Passa o filtro e o id da mensagem pai
    const id = <?php echo $id ?? 0; ?>;
    window.location.href = 'comment.php?id=' + id + '&filtro=' + encodeURIComponent(titulo);
}



		function pop_denuncia(idMensagem = null) {
            var pop_denuncia = document.getElementById("pop_denuncia");
            var sombra = document.getElementById("sombra");

            if (idMensagem !== null) {
                document.getElementById("id_mensagem_denuncia").value = idMensagem;
            }
								

            if (sombra.style.display === "block") {
                sombra.style.display = "none";
                pop_denuncia.style.display = "none";
            } else {
                sombra.style.display = "block";
                pop_denuncia.style.display = "flex";
            }
			
        }
</script>

</body>

</html>